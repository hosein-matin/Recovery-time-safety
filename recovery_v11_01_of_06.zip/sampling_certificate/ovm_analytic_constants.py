#!/usr/bin/env python3
"""Outward interval verification of the analytic whole-episode OVM corollary.

All mathematical parameters are the exact decimal data in the paper.  This
script does not integrate a trajectory or use a numerical maximal profile.
It checks conservative coefficient bounds, an analytic ceiling-contact test,
and the early/tail/extension period formulas.  Every asserted comparison is
made on mpmath interval objects; displayed midpoint values are diagnostics.
"""
from __future__ import annotations

import json
from pathlib import Path
from mpmath import iv

iv.dps = 60
HERE = Path(__file__).resolve().parent


def I(x):
    return iv.mpf(str(x))


def tanh(x):
    e = iv.exp(2*x)
    return (e-1)/(e+1)


def midpoint(x):
    return float(x.mid)


def positive_part(x):
    if bool(x >= 0):
        return x
    if bool(x <= 0):
        return I(0)
    raise ArithmeticError('The sign needed for this analytic branch is unresolved')


def checked(name, condition, checks):
    if not bool(condition):
        raise AssertionError(name)
    checks.append(name)


def run():
    eps, U, M = I('.02'), I('5'), I('1.96')
    xext, xeta, d0rest = I('.002'), I('.01'), I('.82')
    # Cmin/Cmax bound C(d)=alpha*V(d)+U on the entire extended episode;
    # CT is a lower bound on C for d >= epsilon+xT.
    fixtures = [
        dict(name='C1', alpha='2.6', gamma='.2', LV='1', xT='.2',
             Cmin='2.55', Cmax='4.36', CT='3.05', Dmax='.479'),
        dict(name='C2', alpha='1', gamma='.3', LV='1', xT='.4',
             Cmin='4.05', Cmax='4.78', CT='4.43', Dmax='.253'),
        dict(name='C3', alpha='2.6', gamma='.35', LV='.8', xT='.45',
             Cmin='5', Cmax='6.79', CT='5.76', Dmax='.246'),
    ]
    rows, checks = [], []
    for p in fixtures:
        name = p['name']
        alpha, gamma, LV, xT = (I(p[k]) for k in ('alpha', 'gamma', 'LV', 'xT'))
        cmin, cmax, ct = (I(p[k]) for k in ('Cmin', 'Cmax', 'CT'))
        dT = eps+xT
        d0max = d0rest+gamma*I('.4')

        def V(d):
            if name != 'C3':
                return tanh(d)-tanh(I('2'))
            # The three evaluations below lie on known exact clipping branches.
            if bool(d <= I('.1')):
                return I('0')
            if bool(d >= I('1.975')):
                return I('1.5')
            return I('.8')*(d-I('.1'))

        def C(d):
            return U+alpha*V(d)

        checked(name+': coefficient lower bound', C(eps+xext) >= cmin, checks)
        checked(name+': coefficient upper bound', C(d0max) <= cmax, checks)
        checked(name+': contact authority lower bound', C(dT) >= ct, checks)
        checked(name+': alpha*gamma <= 1', alpha*gamma <= 1, checks)
        checked(name+': upper authority gives lower-floor feasibility', cmax <= 2*U, checks)
        checked(name+': upper-floor coefficient bound', alpha*M <= 2*cmin, checks)
        checked(name+': headway-face coefficient bound', cmax-2*U+(1/gamma-alpha)*M <= 0, checks)
        checked(name+': threshold on headway branch', xT <= gamma*M, checks)
        vt = xT/gamma
        checked(name+': constant authority exceeds target drag', ct > alpha*vt, checks)
        # Worst start is v0=0,d0=.82. Increasing v0 lowers the required distance,
        # whereas the actual d0=.82+gamma*v0 increases the available distance.
        D = ct/(alpha*alpha)*iv.ln(ct/(ct-alpha*vt))-vt/alpha
        checked(name+': rounded upper contact distance', D < I(p['Dmax']), checks)
        checked(name+': ceiling reached before threshold', D < d0rest-dT, checks)
        checked(name+': moving start below threshold speed', I('.4') < vt, checks)
        extension = gamma*(1-xext/xeta)
        checked(name+': requested .01 fits profile extension', I('.01') < extension, checks)

        for ths in ('.25', '.5'):
            theta = I(ths)
            r = iv.sqrt(theta)
            lower_budget = positive_part(2*U-(1-theta)*cmin)
            delta_pre = (1-theta)*vt/(2*(cmax+lower_budget+(alpha+1/gamma)*vt))
            kq = alpha*r/gamma-theta/(gamma*gamma)
            kb = alpha/gamma-1/(gamma*gamma)
            Lq = alpha*LV+abs(kq)
            LB = alpha*LV+abs(kb)
            A = gamma*gamma*(Lq+LB)/(1-theta)
            z = 1/(2+iv.sqrt(4+2*A))
            delta_tail = -gamma*iv.ln(1-z)
            checked(name+' theta='+ths+': requested .01 fits pre-tail bound', I('.01') < delta_pre, checks)
            checked(name+' theta='+ths+': requested .01 fits tail bound', I('.01') < delta_tail, checks)
            rows.append(dict(
                plant=name, theta=float(theta.mid),
                coefficient_bounds={k:p[k] for k in ('Cmin','Cmax','CT')},
                threshold_gap=float(dT.mid), threshold_clearance=float(xT.mid),
                contact_distance_interval=str(D),
                contact_available_distance_interval=str(d0rest-dT),
                early_period_interval=str(delta_pre),
                tail_period_interval=str(delta_tail),
                extension_period_interval=str(extension),
                early_period_midpoint=midpoint(delta_pre),
                tail_period_midpoint=midpoint(delta_tail),
                extension_period_midpoint=midpoint(extension),
                certified_common_period='0.01',
            ))
    result=dict(
        method='analytic coefficient/contact/period formulas checked using outward interval arithmetic',
        interval_decimal_precision=iv.dps,
        state_scope='every band state throughout each declared extended gap-recovery episode',
        initial_scope='h0=.8, v0 in {0,.4}, d0=.02+.8+gamma*v0',
        theta_scope=[.25,.5],
        target_scope='gap xeta=.01; tracking xeta=.21 is a pre-entry subset',
        exact_state_observations=True,
        new_trajectory_simulations=False,
        check_count=len(checks), all_checks_passed=True,
        checks=checks, rows=rows,
    )
    (HERE/'ovm_analytic_certificate.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('method','check_count','all_checks_passed')}, indent=2))
    for row in rows:
        print(row['plant'], row['theta'],
              'early=',row['early_period_midpoint'],
              'tail=',row['tail_period_midpoint'],
              'extension=',row['extension_period_midpoint'],
              'common=',row['certified_common_period'])


if __name__ == '__main__':
    run()
