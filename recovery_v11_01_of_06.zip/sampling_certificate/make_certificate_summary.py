"""Create compact reporting artifacts from the verified offline certificate."""
from __future__ import annotations
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'tmp'/'matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main():
    report=json.loads((ROOT/'certified_results_0025.json').read_text())
    assert report['all_certified'] and len(report['rows'])==12
    assert report['source_sha256']==hashlib.sha256((ROOT/'certify_balanced.py').read_bytes()).hexdigest()
    fields=['plant','v0','theta','delta','sample_location_cells','max_budget_ratio_upper',
            'ceiling_contact_certified_by_x','uncertain_phase_cells','profile_seconds','certificate_seconds']
    with (ROOT/'certificate_summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for row in report['rows']:writer.writerow({k:row[k] for k in fields})
    lines=[r'\begin{tabular}{lcc}',r'\toprule',
           r'Model & $\theta=.25$ & $\theta=.5$\\\midrule']
    for plant in ['C1','C2','C3']:
        vals=[]
        for th in ['.25','.5']:
            a=max(r['max_budget_ratio_upper'] for r in report['rows'] if r['plant']==plant and r['theta']==th)
            vals.append(math.ceil(a*10000)/10000)
        lines.append(f'{plant} & {vals[0]:.4f} & {vals[1]:.4f}'+r'\\')
    lines += [r'\bottomrule',r'\end{tabular}']
    (ROOT/'certificate_ratio_table.tex').write_text('\n'.join(lines)+'\n')
    plt.rcParams.update({'font.size':9,'axes.titlesize':10,'axes.labelsize':9,
                        'legend.fontsize':8,'pdf.fonttype':42,'ps.fonttype':42})
    fig,axes=plt.subplots(1,3,figsize=(10,3),sharey=True)
    colors={'.25':'#2366a2','.5':'#cf6523'}
    for ax,plant in zip(axes,['C1','C2','C3']):
        for th in ['.25','.5']:
            for v0 in ['0','.4']:
                row=next(r for r in report['rows'] if (r['plant'],r['theta'],r['v0'])==(plant,th,v0))
                path=ROOT/row['detail_file']
                assert row['detail_sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
                data=np.load(path);vals=data['values']
                ax.step(np.r_[vals[:,2],vals[-1,3]],np.r_[vals[:,9],vals[-1,9]],where='post',
                        color=colors[th],linestyle='-' if v0=='0' else '--',lw=1.35,
                        label=rf'$\theta={float(th):g},\ v_0={float(v0):g}$')
        ax.axhline(1,color='#555555',ls=':',lw=1)
        ax.set(title=plant,xlabel=r'Remaining gap $x=d-\epsilon$',xlim=(0,.96),ylim=(0,1.05))
        ax.grid(alpha=.18)
    axes[0].set_ylabel('Verified budget / available width')
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',ncol=4,frameon=False,bbox_to_anchor=(.5,1.02))
    fig.subplots_adjust(left=.065,right=.99,bottom=.18,top=.84,wspace=.15)
    fig.savefig(ROOT/'certificate_budget_profiles.pdf',bbox_inches='tight')
    fig.savefig(ROOT/'certificate_budget_profiles.png',dpi=170,bbox_inches='tight')
    plt.close(fig)

if __name__=='__main__':main()
