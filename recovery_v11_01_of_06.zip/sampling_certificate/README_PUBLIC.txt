A PRIORI SAMPLING-PERIOD CERTIFICATES
Recovery-Time Guarantees for Safety Filtering under Sampled Actuation
Hossein Nick Zinat Matin and Lipem Likwai Momnougui

PURPOSE
This directory reproduces the analytic and validated computational
sampling-period results in the paper and public technical notes. It is
separate from the closed-loop controller-performance experiments in
numerics_v7/. No new controller cost, comfort, or runtime comparison is
inferred from these certificates.

RESULTS AND EXACT SCOPE
  Analytic sufficient period:       Delta = 0.01.
  Offline interval-certified period: Delta = 0.025.

Both periods are in normalized model time. They are sufficient periods,
not maximum allowable periods. The numerical values concern exactly:

  epsilon = 0.02, M = 1.96, U = 5, h0 = 0.8;
  v0 in {0, 0.4}, with d0 = epsilon + h0 + gamma*v0;
  theta in {0.25, 0.5};
  C1: alpha = 2.6, gamma = 0.20, V(d) = tanh(d)-tanh(2);
  C2: alpha = 1.0, gamma = 0.30, V(d) = tanh(d)-tanh(2);
  C3: alpha = 2.6, gamma = 0.35, V(d) = clip(.8*(d-.1), 0, 1.5).

The declared decimals define the exact mathematical model. The gap entry
clearance d-epsilon is .01. Tracking entry at clearance .21 is a subset
of the same covered recovery episode. The reference profile is extended
to clearance .002. There are twelve model/start/theta certificates,
covering both target tasks: twenty-four combinations in total.

Each certificate covers every possible sample position in its covered
interval and every energy between q = theta*Eplus and the safety ceiling
B. Sampled nominal commands may be arbitrary; this is not certification
only along selected nominal trajectories. Positive no-wait launch is an
explicit guard for every accepted input at an initial rest state.

The assumptions include an autonomous stopped-leader model, the declared
parameters, and exact sampled state observations. Integration and rounding
enclosures do not represent unknown plant parameters or measurement error.
No uniform guarantee at Delta=.05 or real-time computation deadline is
claimed. The existing .05 performance study uses a separate trajectory-
specific whole-hold certificate.

FILES
  ovm_analytic_constants.py
      Evaluates the coefficient, ceiling-contact, floor/face, and period
      inequalities using outward interval arithmetic at 60 decimal digits.
      It does not integrate Eplus or candidate held-input trajectories.
  ovm_analytic_certificate.json
      The 51 passing checks and analytic bounds for the six model/theta
      combinations. Both initial speeds and both tasks are covered.
  certify_balanced.py
      Builds interval bounds for Eplus and its derivative, boundary-input
      witnesses, and clearance budgets. Decimal model data and spatial
      cell positions are represented exactly before outward enclosure.
  certified_results_0025.json
      Twelve complete-episode results at Delta=.025, with source and
      certificate-file SHA256 identities. Timing fields describe offline
      certificate construction, not online controller latency.
  certificate_*.npz
      Full arrays: profile bounds, derivative phases, boundary witnesses,
      clearance integrands, enlarged prefixes, and all position-cell tests.
  CERTIFICATE_METHOD.txt
      The computational proof, including contact cells, cap kinks,
      interval arithmetic, coverage, and interpretation of stored arrays.
  integrity_checks.json
      Stored source/array integrity and complete-position-coverage checks.
  make_certificate_summary.py
      Produces the table, CSV summary, and budget-ratio figure from the
      already certified data, checking source and detail-file identities.
  certificate_summary.csv, certificate_ratio_table.tex,
  certificate_budget_profiles.pdf, certificate_budget_profiles.png
      Derived summaries and figure.
  requirements.txt, runtime.json
      Dependency versions and the tested environment.

REPRODUCTION
Use Python 3.12 with NumPy, mpmath 1.3.0, and Matplotlib; exact tested
versions are in runtime.json and requirements.txt. Work in a copy because
the scripts replace generated reports, arrays, and figures in this folder.

From this directory:

  python3 ovm_analytic_constants.py
  python3 certify_balanced.py --delta .025 --out certified_results_0025.json
  python3 make_certificate_summary.py

The default interval run uses scale=10000 (cell width 1/10000), all three
models, both initial speeds, and both theta values. Its 101,600 complete
sample-position cells all satisfy the clearance-budget condition. The
largest certified ratio (H_B+H_q)/(B-q) is 0.7477265063542601.

A targeted reconstruction of the worst case is:

  python3 certify_balanced.py --plants C1 --v0 0 --theta .5 --delta .025 --out worst_case.json

This targeted command is a diagnostic and is not the complete matrix.
It also regenerates that case's NPZ. Use a separate working copy when
preserving a previously frozen complete report and its file hashes.

The report records the verification script's source hash and every detail
file hash. Recomputing a report can change its offline timing fields.
All numerical values and sufficient-condition checks, rather than runtime
or byte order of incidental outputs, are the mathematical evidence.

RELATION TO AN IMPLEMENTATION
The theorem gives a constructive held-input witness: use the
floor-preserving input if the available upper clearance exceeds its
certified upper-clearance budget; otherwise use the ceiling-preserving
input. The offline arrays support such a fallback by selecting the cell
containing the exact current sample position, without integrating candidate
trajectories online. Index selection must preserve the documented enlarged-
prefix coverage and the initial rest guard.

This directory does not replace the finite candidate-search controller
used for the saved numerics_v7 performance tables. There is no claim that
that finite search must discover these witnesses until they are explicitly
integrated. A changed controller would require fresh performance comparisons.

