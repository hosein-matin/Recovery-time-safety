"""Offline interval certificate for a fixed hold period, for all band states.

No simulated trajectories or unvalidated numerical reference profiles are used.
Exact decimal model parameters and exact rational spatial-cell endpoints are
enclosed with mpmath interval arithmetic. The scalar maximal energy is bounded
by constant-authority comparison flows; an elementary rigorous Euler enclosure
is sufficient. Commands and nonnegative Riemann-sum budgets are rounded outwards.

The theorem being verified is the balanced-boundary certificate in the separate
theory note. This program certifies all sample positions, not only grid nodes.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import time
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
import numpy as np
from mpmath import iv

ROOT=Path(__file__).resolve().parent
iv.dps=45
EPS_MACHINE=np.finfo(float).eps

def up(x): return math.nextafter(float(x), math.inf)
def down(x): return math.nextafter(float(x), -math.inf)
def lower(x): return down(float(x.a))
def upper(x): return up(float(x.b))
def point(x): return iv.mpf(float(x))
def hull(a,b): return iv.mpf([min(lower(a),lower(b)), max(upper(a),upper(b))])
def nonnegative(a): return iv.mpf([max(0.,lower(a)),max(0.,upper(a))])
def ivtanh(x):
    z=iv.exp(2*x)
    return (z-1)/(z+1)

@dataclass(frozen=True)
class Plant:
    name:str
    alpha:str
    gamma:str
    eps:str='0.02'
    M:str='1.96'
    U:str='5'
    def value(self,d):
        if self.name=='C3':
            raw=iv.mpf('.8')*(d-iv.mpf('.1'))
            return iv.mpf([max(0.,min(1.5,lower(raw))),max(0.,min(1.5,upper(raw)))])
        return ivtanh(d)-ivtanh(iv.mpf(2))
    def c(self,x):return iv.mpf(self.U)+iv.mpf(self.alpha)*self.value(iv.mpf(self.eps)+x)
    def ceiling(self,x):
        v=x/iv.mpf(self.gamma);M=iv.mpf(self.M)
        if upper(v)<lower(M):return v*v/2
        if lower(v)>upper(M):return M**2/2
        return iv.mpf([min(lower(M),max(0.,lower(v))),min(upper(M),upper(v))])**2/2
    def vbar(self,x):
        v=x/iv.mpf(self.gamma);M=iv.mpf(self.M)
        return iv.mpf([min(lower(M),max(0.,lower(v))),min(upper(M),upper(v))])
    def bprime(self,x):
        if upper(x)<lower(iv.mpf(self.gamma)*iv.mpf(self.M)):
            return -x/iv.mpf(self.gamma)**2
        if lower(x)>upper(iv.mpf(self.gamma)*iv.mpf(self.M)):
            return iv.mpf(0)
        return hull(iv.mpf(0),-x/iv.mpf(self.gamma)**2)

PLANTS=[Plant('C1','2.6','.2'),Plant('C2','1','.3'),Plant('C3','2.6','.35')]

def constant_flow(e0,C,alpha,h):
    """Enclose endpoint and range of y'=C-alpha sqrt(2y), y(0)=e0.

    e0 and C are exact binary64 points; alpha and h enclose exact positive
    real constants. Monotonicity toward C^2/(2alpha^2) bounds displacement
    by h*f(e0), then integrating the resulting derivative range gives the
    endpoint enclosure. Nonnegativity is known analytically because C>0.
    """
    e=point(e0); c=point(C)
    f=c-alpha*iv.sqrt(2*e)
    ra=max(0.,lower(e+h*min(0.,lower(f))))
    rb=upper(e+h*max(0.,upper(f)))
    frange=c-alpha*iv.sqrt(2*iv.mpf([ra,rb]))
    endpoint=e+h*frange
    return max(0.,lower(endpoint)),upper(endpoint),ra,rb

class CertifiedProfile:
    def __init__(self,p,v0,scale=10000):
        started=time.perf_counter(); self.p=p;self.v0=v0;self.scale=scale
        self.x0=Fraction('0.8')+Fraction(p.gamma)*Fraction(v0)
        self.xe=Fraction('.002')
        assert (self.x0*scale).denominator==1 and (self.xe*scale).denominator==1
        self.i0=int(self.x0*scale);self.ie=int(self.xe*scale);self.n=self.i0-self.ie
        self.h=iv.mpf(1)/scale;self.hhi=upper(self.h)
        self.xindex=np.arange(self.i0,self.ie-1,-1,dtype=np.int64)
        self.Elo=np.empty(self.n+1);self.Ehi=np.empty(self.n+1)
        self.Ecelllo=np.empty(self.n);self.Ecellhi=np.empty(self.n)
        self.Clo=np.empty(self.n);self.Chi=np.empty(self.n)
        self.Brightlo=np.empty(self.n);self.Blefthi=np.empty(self.n)
        self.tail=np.zeros(self.n,dtype=bool);self.phase=np.empty(self.n,dtype='U10')
        self.contact_proved_index=None
        alpha=iv.mpf(p.alpha)
        e0=iv.mpf(v0)**2/2
        self.Elo[0]=max(0.,lower(e0));self.Ehi[0]=upper(e0)
        # Model-level properties needed for constant-C min-flow comparisons
        # and permanent sticking after contact of the real maximal profile.
        assert upper(alpha*iv.mpf(p.gamma))<=1.
        assert lower(p.c(iv.mpf('.002')))>0
        capx=iv.mpf(p.gamma)*iv.mpf(p.M)
        if p.name=='C1':
            assert upper(p.c(iv.mpf(self.i0)/scale))<lower(alpha*iv.mpf(p.M))
            self.sticking_reason='cap unreachable; C>0 and alpha*gamma<=1 on headway branch'
        else:
            assert lower(p.c(capx))>upper(alpha*iv.mpf(p.M))
            self.sticking_reason='cap strictly inward; C>0 and alpha*gamma<=1 on headway branch'
        is_tail=False
        self.cap_cell_checks=0
        for j in range(self.n):
            xl=iv.mpf(int(self.xindex[j]))/scale
            xr=iv.mpf(int(self.xindex[j+1]))/scale
            Bleft=p.ceiling(xl);Bright=p.ceiling(xr)
            self.Brightlo[j]=lower(Bright);self.Blefthi[j]=upper(Bleft)
            clo=lower(p.c(xr));chi=upper(p.c(xl))
            self.Clo[j]=clo;self.Chi[j]=chi
            if lower(xr)<=upper(capx) and upper(xl)>=lower(capx):
                # This explicit check covers cells touching or crossing the
                # cap/headway kink, including interval endpoint uncertainty.
                if p.name=='C1':
                    assert self.Ehi[j]<lower(iv.mpf(p.M)**2/2)
                    assert chi<lower(alpha*iv.mpf(p.M))
                else:
                    assert clo>upper(alpha*iv.mpf(p.M))
                self.cap_cell_checks+=1
            if is_tail:
                self.Elo[j]=lower(Bleft);self.Ehi[j]=upper(Bleft)
                self.Elo[j+1]=lower(Bright);self.Ehi[j+1]=upper(Bright)
                self.Ecelllo[j]=lower(Bright);self.Ecellhi[j]=upper(Bleft)
                self.tail[j]=True;self.phase[j]='tail'
                continue
            low=constant_flow(float(self.Elo[j]),clo,alpha,self.h)
            high=constant_flow(float(self.Ehi[j]),chi,alpha,self.h)
            self.Elo[j+1]=min(low[0],lower(Bright))
            self.Ehi[j+1]=min(high[1],upper(Bright))
            self.Ecelllo[j]=min(low[2],lower(Bright))
            self.Ecellhi[j]=min(high[3],upper(Bleft))
            self.phase[j]='free' if self.Ecellhi[j]<self.Brightlo[j] else 'uncertain'
            if low[0]>upper(Bright):
                # The lower reflected comparison reaches the ceiling by the
                # endpoint. Since E+<=B, actual E+ equals B at the endpoint.
                self.contact_proved_index=j+1;is_tail=True
                self.Elo[j+1]=lower(Bright);self.Ehi[j+1]=upper(Bright)
        if self.contact_proved_index is None:raise ArithmeticError('Could not certify ceiling contact')
        self.seconds=time.perf_counter()-started

    def boundary_arrays(self,theta):
        p=self.p; alpha=iv.mpf(p.alpha);th=iv.mpf(theta);r=iv.sqrt(th);U=iv.mpf(p.U)
        Rqhi=np.empty(self.n);RBlo=np.empty(self.n)
        zBhi=np.empty(self.n);zqhi=np.empty(self.n);widthlo=np.empty(self.n)
        for j in range(self.n):
            xl=iv.mpf(int(self.xindex[j]))/self.scale
            xr=iv.mpf(int(self.xindex[j+1]))/self.scale
            x=iv.mpf([lower(xr),upper(xl)])
            C=iv.mpf([self.Clo[j],self.Chi[j]])
            E=iv.mpf([self.Ecelllo[j],self.Ecellhi[j]])
            v=iv.sqrt(2*E);vb=p.vbar(x);bp=p.bprime(x)
            rq_free=U-(1-th)*C+alpha*(r-th)*v
            rq_tail=th*bp-C+U+alpha*r*vb
            zq_free=U-(1-th)*C-alpha*th*v+alpha*vb
            zq_tail=th*bp-C+U+alpha*vb
            if self.phase[j]=='free': rq=rq_free;zq=zq_free
            elif self.phase[j]=='tail':rq=rq_tail;zq=zq_tail
            else:rq=hull(rq_free,rq_tail);zq=hull(zq_free,zq_tail)
            Rqhi[j]=upper(rq)
            RBlo[j]=lower(bp-C+U+alpha*vb)
            zBhi[j]=upper(C-U-alpha*r*v-bp)
            zqhi[j]=upper(zq)
            widthlo[j]=lower(point(self.Brightlo[j])-th*point(self.Ecellhi[j]))
        return Rqhi,RBlo,zBhi,zqhi,widthlo

    def prefix_end(self,j,delta):
        """Enclose prefixes of EVERY starting position in cell j.

        Ceiling-flow terminal position is monotone in its initial position.
        Use the right endpoint (smallest x) of the starting cell, then round
        its ceiling-flow terminal x downward to a rational mesh node.
        """
        p=self.p;g=iv.mpf(p.gamma);M=iv.mpf(p.M);dt=iv.mpf(delta)
        x=iv.mpf(int(self.xindex[j+1]))/self.scale;cap=g*M
        # Conservative headway-only comparison also valid above speed cap,
        # but using the cap exactly makes prefixes substantially shorter.
        if upper(x)<=lower(cap): end=x*iv.exp(-dt/g)
        elif lower(x-M*dt)>=upper(cap):end=x-M*dt
        else:
            # If x is below cap by interval-rounding ambiguity, setting the
            # cap-phase duration to zero only enlarges the travel bound.
            cap_time=(x-cap)/M
            rem=iv.mpf([max(0.,lower(dt-cap_time)),max(0.,upper(dt-cap_time))])
            end=cap*iv.exp(-rem/g)
            if lower(x)<=upper(cap):
                end=hull(end,x*iv.exp(-dt/g))
        k=math.floor(lower(end*self.scale))
        return self.i0-k

def positive_sum_upper(values):
    """IEEE binary64 sum upper bound; interval inputs already rounded up.

    For nonnegative terms and n sequential-or-pairwise additions, the usual
    gamma_n error bound applies. eps (rather than eps/2) is conservative.
    Terms are normal in these calculations. Division is enlarged once.
    """
    a=np.asarray(values,float)
    assert np.all(a>=0.) and np.all(np.isfinite(a))
    n=len(a);s=float(np.sum(a,dtype=np.float64))
    if s==0.:return 0.
    return up(s/(1.-n*EPS_MACHINE))

def certify(P,theta,delta,target='.01',boundary=None):
    started=time.perf_counter()
    Rqhi,RBlo,zBhi,zqhi,widthlo=P.boundary_arrays(theta) if boundary is None else boundary
    target_index=P.i0-int(Fraction(target)*P.scale)
    rows=[];maxratio=-math.inf;worst=None;failures=[];launch_data=None
    for j in range(target_index):
        k=P.prefix_end(j,delta)
        if k>P.n:
            failures.append({'cell':j,'reason':'extension','end':k});continue
        uq=max(-float(P.p.U),float(np.max(Rqhi[j:k])))
        uB=min(float(P.p.U),float(np.min(RBlo[j:k])))
        if j==0 and Fraction(P.v0)==0:
            # Explicit no-waiting launch guard, independent of the limit of
            # the a.e. floor-tangent inequalities used by the general proof.
            C0=P.p.c(iv.mpf(P.i0)/P.scale)
            required=iv.mpf(P.p.U)-(1-iv.mpf(theta))*C0
            uq=max(uq,upper(required))
            launch_margin=lower(point(uq)-required)
            assert launch_margin>=0.
            assert lower(iv.mpf(theta)*C0)>0.
            launch_data={'required_input_upper':upper(required),
                'chosen_floor_input':uq,'guard_margin_lower':launch_margin,
                'theta_g0_lower':lower(iv.mpf(theta)*C0)}
        if uq>float(P.p.U) or uB < -float(P.p.U):
            failures.append({'cell':j,'reason':'input_bounds','uq':uq,'uB':uB});continue
        CB=np.maximum(0.,np.nextafter(uq+zBhi[j:k],np.inf))
        Cq=np.maximum(0.,np.nextafter(zqhi[j:k]-uB,np.inf))
        HB=up(P.hhi*positive_sum_upper(CB))
        Hq=up(P.hhi*positive_sum_upper(Cq))
        if j==0 and Fraction(P.v0)==0:
            # The rest state's upper clearance chooses the floor witness;
            # a nonempty tangent interval also permits choosing this witness.
            assert uq<=uB or HB<=lower(P.p.ceiling(iv.mpf(P.i0)/P.scale))
        width=float(widthlo[j])
        ratio=up(up(HB+Hq)/width) if width>0 else math.inf
        # If the constant tangent interval is nonempty, choose its element;
        # otherwise the clearance-budget test supplies one of uq,uB.
        accepted=uq<=uB or ratio<=1.
        if not accepted:failures.append({'cell':j,'reason':'budget','ratio':ratio})
        r={'j':j,'k':k,'x_left':float(Fraction(int(P.xindex[j]),P.scale)),
           'x_right':float(Fraction(int(P.xindex[j+1]),P.scale)),
           'uq':uq,'uB':uB,'H_B_upper':HB,'H_q_upper':Hq,'width_lower':width,'ratio_upper':ratio,
           'interval_overlap':bool(uq<=uB)}
        rows.append(r)
        effective=0. if uq<=uB else ratio
        if effective>maxratio:maxratio=effective;worst=r
    detail=ROOT/f'certificate_{P.p.name}_v{P.v0}_theta{theta}_delta{delta}.npz'
    columns=['j','k','x_left','x_right','uq','uB','H_B_upper','H_q_upper','width_lower','ratio_upper','interval_overlap']
    np.savez_compressed(detail,columns=np.array(columns),values=np.array([[r[k] for k in columns] for r in rows]),
        E_lower=P.Elo,E_upper=P.Ehi,E_cell_lower=P.Ecelllo,E_cell_upper=P.Ecellhi,
        phase=P.phase,contact_proved_index=P.contact_proved_index,
        Rq_upper=Rqhi,RB_lower=RBlo,zB_upper=zBhi,zq_upper=zqhi,width_lower=widthlo)
    result={'plant':P.p.name,'v0':P.v0,'theta':theta,'delta':delta,'target_x':target,
        'certified':not failures,'sample_location_cells':target_index,'cell_width':f'1/{P.scale}',
        'max_budget_ratio_upper':maxratio,'worst_cell':worst,'failure_count':len(failures),'first_failures':failures[:10],
        'ceiling_contact_certified_by_x':float(Fraction(int(P.xindex[P.contact_proved_index]),P.scale)),
        'free_cells':int(np.sum(P.phase=='free')),'uncertain_phase_cells':int(np.sum(P.phase=='uncertain')),
        'profile_seconds':P.seconds,'certificate_seconds':time.perf_counter()-started,
        'cap_kink_cells_checked':P.cap_cell_checks,'launch_guard':launch_data,
        'detail_file':detail.name,'detail_sha256':hashlib.sha256(detail.read_bytes()).hexdigest()}
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scale',type=int,default=10000)
    ap.add_argument('--delta',default='.025');ap.add_argument('--plants',nargs='+',default=['C1','C2','C3'])
    ap.add_argument('--v0',nargs='+',default=['0','.4']);ap.add_argument('--theta',nargs='+',default=['.25','.5'])
    ap.add_argument('--out',default='certified_results.json');a=ap.parse_args()
    rows=[]
    for p in PLANTS:
        if p.name not in a.plants:continue
        for v0 in a.v0:
            P=CertifiedProfile(p,v0,a.scale)
            print(json.dumps({'event':'profile','plant':p.name,'v0':v0,'seconds':P.seconds,
                'contact_x':float(Fraction(int(P.xindex[P.contact_proved_index]),P.scale)),
                'uncertain_cells':int(np.sum(P.phase=='uncertain'))}),flush=True)
            for theta in a.theta:
                row=certify(P,theta,a.delta);rows.append(row);print(json.dumps(row),flush=True)
    report={'status':'interval-enclosed complete sample-position coverage; exact decimal model data',
        'method':'constant-authority comparison, interval energy bounds, enlarged spatial prefixes, outward nonnegative Riemann sums',
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'interval_precision_dps':iv.dps,
        'all_certified':all(r['certified'] for r in rows),'rows':rows,
        'scope':'Gap target x=.01, extension x=.002; tracking target x=.21 is covered as a subset; arbitrary band energy and sampled nominal'}
    (ROOT/a.out).write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
