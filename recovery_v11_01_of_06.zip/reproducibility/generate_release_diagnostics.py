#!/usr/bin/env python3
"""Derived binary64 displays and descriptive strata; never a rigorous certificate."""
from pathlib import Path
import csv
import hashlib
import json
import math
import statistics

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'reproducibility'
METRICS = ['T', 'J10', 'I10_L1', 'I10_L2', 'I1_sampled10', 'I2_sampled10',
           'RMS_acc10', 'TV_acc10', 'max_acc_jump']
THRESHOLD = 1e-10


def write(name, rows):
    with (OUT / name).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    constants = []
    for plant, alpha, gamma in [('C1', 2.6, .2), ('C2', 1., .3), ('C3', 2.6, .35)]:
        def V(d):
            return min(max(.8 * (d - .1), 0.), 1.5) if plant == 'C3' else math.tanh(d) - math.tanh(2.)
        eps, M, U = .02, 1.96, 5.
        for v0 in [0., .4]:
            d0 = eps + .8 + gamma * v0
            P = alpha * (max(abs(V(eps)), abs(V(d0))) + M) + U
            LB = M / gamma
            for theta in [.25, .5]:
                K = P + max(theta * max(P, LB), LB)
                g = (1 - theta) * .5 * (.002 / gamma) ** 2
                for task, target in [('gap', .01), ('tracking', .21)]:
                    Se = d0 - eps - .002
                    S = d0 - eps - target
                    delta0 = min(Se - S, g / (4 * K)) / M
                    constants.append(dict(plant=plant, v0=v0, theta=theta, target=task,
                        target_x=target, alpha=alpha, gamma=gamma, epsilon=eps, M=M, U=U,
                        d0=d0, P=P, L_B=LB, K=K, S_e=Se, S=S, g=g, delta_0=delta0,
                        interpretation='binary64_display_of_theorem_formula_not_interval_certificate'))
    assert len(constants) == 24
    write('generic_period_constants.csv', constants)
    source = ROOT / 'numerics_v7/data/episodes.csv'
    with source.open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    def key(r):
        return (r['plant'], r['task'], float(r['v0']), r['nominal'], float(r['theta']), float(r['dt']))
    band = {key(r): r for r in rows if r['group'] == 'base' and r['method'] == 'band'}
    progress = {key(r): r for r in rows if r['group'] == 'base' and r['method'] == 'progress'}
    assert len(band) == 96 and set(band) == set(progress)
    partitions = [('all', 'all', sorted(band))]
    dimensions = [('plant', 0), ('task', 1), ('start_v0', 2), ('nominal', 3), ('theta', 4)]
    for label, position in dimensions:
        for value in sorted({k[position] for k in band}):
            partitions.append((label, str(value), [k for k in sorted(band) if k[position] == value]))
    strata = []
    for dimension, value, keys in partitions:
        for metric in METRICS:
            differences = [float(band[k][metric]) - float(progress[k][metric]) for k in keys]
            assert all(math.isfinite(x) for x in differences)
            strata.append(dict(stratification=dimension, stratum=value, metric=metric, n=len(keys),
                band_lower=sum(x < -THRESHOLD for x in differences),
                progress_lower=sum(x > THRESHOLD for x in differences),
                ties=sum(abs(x) <= THRESHOLD for x in differences),
                median_band_minus_progress=statistics.median(differences), raw_difference_threshold=THRESHOLD,
                group='base', requested_period=.05))
    totals = {r['metric']: r for r in strata if r['stratification'] == 'all'}
    for dimension, _ in dimensions:
        for metric in METRICS:
            selected = [r for r in strata if r['stratification'] == dimension and r['metric'] == metric]
            for field in ['n', 'band_lower', 'progress_lower', 'ties']:
                assert sum(r[field] for r in selected) == totals[metric][field]
    supplied_summary = json.loads((ROOT / 'numerics_v7/summary.json').read_text())['paired_counts']
    for metric, row in totals.items():
        for field in ['n', 'band_lower', 'progress_lower', 'ties']:
            assert row[field] == supplied_summary[metric][field], (metric, field)
    write('historical_paired_strata.csv', strata)
    report = {'scope': 'Descriptive reanalysis of the retained base matrix only; no simulations or inferential confidence intervals.',
              'input': 'numerics_v7/data/episodes.csv',
              'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'historical_records': len(rows), 'historical_holds': sum(int(float(r.get('holds') or 0)) for r in rows),
              'base_matched_pairs': len(band), 'raw_difference_threshold': THRESHOLD,
              'strata_sum_to_global_counts': True, 'counts_match_supplied_summary': True,
              'strata_rows': len(strata), 'generic_period_rows': len(constants),
              'generic_period_min_binary64': min(r['delta_0'] for r in constants),
              'generic_period_max_binary64': max(r['delta_0'] for r in constants),
              'generic_period_scope': '24 binary64 evaluations of the theorem formula; not new rigorous certificates.',
              'randomness': 'No RNG, iid model, or sampling-based uncertainty estimate is used.'}
    (OUT / 'release_diagnostics.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
