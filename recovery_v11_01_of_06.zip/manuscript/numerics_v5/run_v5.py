#!/usr/bin/env python3
"""Revision 5 structural experiments; fixed legacy controllers, no retuning.

Run: python run_v5.py --legacy ../numerics
The --legacy folder is the frozen Revision 4 numerical package.
All outputs are written beside this script. No external data are downloaded.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, platform, time
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import solve_ivp, quad
os.environ.setdefault('MPLCONFIGDIR','/tmp/ecc_v5_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from pypdf import PdfReader

R=Path(__file__).resolve().parent
for x in ['data','figures','tables']:(R/x).mkdir(exist_ok=True)
@dataclass(frozen=True)
class Plant:
    name:str; alpha:float=2.6; gamma:float=.35; eps:float=.02
    M:float=1.96; U:float=5.; kind:str='C3'
    def a(self,d,v):
        if self.kind=='partial':return -1.-v
        if self.kind=='unit':return 0.*np.asarray(v)
        V=np.clip(.8*(np.asarray(d)-.1),0.,1.5) if self.kind=='C3' else np.tanh(d)-np.tanh(2.)
        return self.alpha*(V-v)
    def upper(self,d,v):return self.a(d,v)+self.U
    def ceiling(self,d):return .5*np.minimum((np.asarray(d)-self.eps)/self.gamma,self.M)**2
PLANTS={
 'C1':Plant('C1',2.6,.2,kind='C1'),
 'C2':Plant('C2',1.,.3,kind='C2'),
 'C3':Plant('C3')}
COLORS={'gap_product':'#d06436','cbf_gap':'#087d8b','standard_cbf':'#7c59a6',
        'max_input':'#172f4b','cbf_gain1':'#457b3b','cbf_gain2':'#7c59a6'}
LABELS={'gap_product':'Recovery blend','cbf_gap':'Recovery CBF','standard_cbf':'Ordinary CBF',
        'old_product':'Midpoint blend','max_input':'Maximum input','cbf_gain1':'Recovery CBF, $\\kappa_v=1$',
        'cbf_gain2':'Recovery CBF, $\\kappa_v=2$'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,
 'axes.labelsize':8,'legend.fontsize':7,'xtick.labelsize':7,'ytick.labelsize':7,
 'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})

def csvwrite(name,rows):
    with (R/'data'/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def readcsv(path):return list(csv.DictReader(path.open()))
def typedcsv(path):
    result=readcsv(path)
    for row in result:
        for key,value in row.items():
            if value in ['True','False']:row[key]=(value=='True')
            else:
                try:row[key]=float(value)
                except ValueError:pass
    return result
def clean_json(x):
    if isinstance(x,dict):return {k:clean_json(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean_json(v) for v in x]
    if isinstance(x,np.generic):return clean_json(x.item())
    if isinstance(x,float) and not math.isfinite(x):return None
    return x
def jwrite(name,obj):(R/name).write_text(json.dumps(clean_json(obj),indent=2))
def export_figure(fig,name):
    """Install only a complete, readable PDF so manuscript builds cannot race it."""
    pdf=R/'figures'/f'{name}.pdf';tmp=R/'figures'/f'{name}.building.pdf'
    fig.savefig(tmp,format='pdf')
    if tmp.stat().st_size<1000 or len(PdfReader(tmp).pages)!=1:
        raise RuntimeError(f'Invalid generated figure: {tmp}')
    tmp.replace(pdf)
    png=R/'figures'/f'{name}.png';ptmp=R/'figures'/f'{name}.building.png'
    fig.savefig(ptmp,format='png',dpi=180);ptmp.replace(png)

def ceiling_time(p,dhit,dtarg):
    """Exact travel time on v=min(M,(d-eps)/gamma), dhit>=dtarg>eps."""
    dc=p.eps+p.gamma*p.M
    result=max(0.,dhit-max(dtarg,dc))/p.M
    high=min(dhit,dc)
    if high>dtarg:result+=p.gamma*math.log((high-p.eps)/(dtarg-p.eps))
    return result

def spatial_oracle(p,d0,v0,dtarg,rtol=1e-10,atol=1e-12,subdiv=256):
    """Exact characterization evaluated numerically for the stated OVM fixtures.

    For these fixtures, a ceiling reached by the full-throttle solution can
    subsequently be followed. C1 cannot reach the speed cap under full throttle;
    C2/C3 have positive cap acceleration on its domain. All three have strictly
    positive A_+ + v/gamma on the headway ceiling. This specialization avoids
    silently clipping an unconstrained trajectory for a general nonlinear plant.
    """
    S=d0-dtarg
    if S<=1e-12:return {'T':0.,'hit_s':0.,'ceiling_time':0.,'moving_time':0.,'nfev':0}
    if v0==0 and p.upper(d0,0)<=0:return {'T':math.inf,'hit_s':None,'ceiling_time':0.,'moving_time':math.inf,'nfev':0}
    def rhs(s,y):return [float(p.upper(d0-s,math.sqrt(2*max(0.,y[0]))))]
    def event(s,y):return y[0]-float(p.ceiling(d0-s))
    event.direction=1;event.terminal=True
    sol=solve_ivp(rhs,[0,S],[v0*v0/2],method='DOP853',rtol=rtol,atol=atol,
                  max_step=S/subdiv,dense_output=True,events=event)
    if not sol.success:raise RuntimeError(sol.message)
    end=float(sol.t[-1]);hit=len(sol.t_events[0])>0
    if v0==0:
        launch=math.sqrt(2/float(p.upper(d0,0)))
        def integ(x):
            if x==0:return launch
            E=float(sol.sol(x*x)[0]);return 2*x/math.sqrt(2*max(E,1e-300))
        tm,qe=quad(integ,0,math.sqrt(end),epsabs=atol*30,epsrel=rtol*30,limit=200)
    else:
        tm,qe=quad(lambda s:1/math.sqrt(2*max(float(sol.sol(s)[0]),1e-300)),0,end,
                   epsabs=atol*30,epsrel=rtol*30,limit=200)
    tc=ceiling_time(p,d0-end,dtarg) if hit else 0.
    return {'T':tm+tc,'hit_s':end if hit else None,'moving_time':tm,'ceiling_time':tc,
            'quad_error_estimate':qe,'nfev':sol.nfev}

def time_oracle(p,d0,v0,dtarg):
    """Independent time-domain maximum-throttle integration to first active face."""
    if d0<=dtarg+1e-12:return 0.
    def rhs(t,y):return [-y[1],float(p.upper(*y))]
    def target(t,y):return y[0]-dtarg
    def headway(t,y):return y[0]-p.gamma*y[1]-p.eps
    def speedcap(t,y):return p.M-y[1]
    for ev in [target,headway,speedcap]:ev.terminal=True;ev.direction=-1
    sol=solve_ivp(rhs,[0,100],[d0,v0],method='DOP853',rtol=2e-12,atol=2e-14,
                  max_step=.002,events=[target,headway,speedcap])
    if len(sol.t_events[0]):return float(sol.t[-1])
    if len(sol.t_events[1]) or len(sol.t_events[2]):
        return float(sol.t[-1])+ceiling_time(p,float(sol.y[0,-1]),dtarg)
    raise RuntimeError('Time oracle did not reach target or active face')

def acceleration(p,t,d,v,w,method,hg=.2,lam=.1,nominal='zero_input',kv=10.):
    a=p.a(d,v);h=d-p.gamma*v-p.eps
    if nominal=='zero_input':k=0.*np.asarray(v)
    else:k=np.clip(float(nominal)-a,-p.U,p.U)
    rho=np.maximum(h-hg,0.)/(.2+np.maximum(h-hg,0.))
    ref=(w/2-v+lam*rho*(p.M-v))/p.gamma
    ub=np.clip(ref-a,-p.U,p.U)
    beta=np.tanh(50*np.maximum(v,0.)/p.M)
    sigma=np.tanh(50*np.maximum(h,0.))*np.tanh(50*np.maximum(p.M-v,0.)/p.M)
    rec=beta*k+(1-beta)*ub
    if method=='max_input':u=0.*np.asarray(v)+p.U
    elif method=='gap_product':u=sigma*rec+(1-sigma)*ub
    else:
        L=np.maximum(a-p.U,-kv*v)
        upper=np.minimum(np.minimum(a+p.U,(w-v+10*h)/p.gamma),10*(p.M-v))
        if np.any(L>upper+1e-9):raise RuntimeError('Infeasible CBF interval')
        q=a+(k if method=='standard_cbf' else rec)
        pc=np.minimum(np.maximum(q,L),upper);u=pc-a
    return a+u,u,k

def simulate(p,h0,v0,method,T=60.,nominal='zero_input',leader_kind='stopped',kv=10.,fine=False):
    h0=np.atleast_1d(h0).astype(float);v0=np.broadcast_to(v0,h0.shape).astype(float);n=len(h0)
    d0=p.eps+p.gamma*v0+h0
    def head(t):
        if leader_kind=='pulse':return 1.2*math.sin(math.pi*t/4)**2 if 0<t<4 else 0.
        if leader_kind=='exponential':return 1.2*math.exp(-t/2)
        return 0.
    def rhs(t,y):
        d=y[:n];v=y[n:];w=np.r_[head(t),v[:-1]]
        pp,_,_=acceleration(p,t,d,v,w,method,nominal=nominal,kv=kv)
        return np.r_[w-v,pp]
    step=.005 if fine else .01
    ts=np.arange(int(round(T/step))+1)*step
    sol=solve_ivp(rhs,[0,T],np.r_[d0,v0],method='DOP853',rtol=2e-11 if fine else 2e-9,
                  atol=2e-13 if fine else 2e-11,max_step=.01 if fine else .02,dense_output=True)
    if not sol.success:raise RuntimeError(sol.message)
    y=sol.sol(ts);d=y[:n];v=y[n:];w=np.vstack([np.array([head(t) for t in ts]),v[:-1]])
    pp,u,k=acceleration(p,ts,d,v,w,method,nominal=nominal,kv=kv)
    h=d-p.gamma*v-p.eps
    st=sol.y;sd=st[:n];sv=st[n:];sh=sd-p.gamma*sv-p.eps
    result={'t':ts,'d':d,'v':v,'w':w,'h':h,'a':pp,'u':u,'k':k,
       'h0':h0,'v0':v0,'nfev':sol.nfev,'solver_node_min_h':float(sh.min()),
       'solver_node_min_v':float(sv.min()),'solver_node_min_upper':float((p.M-sv).min())}
    return result

def event_time(t,x,threshold,direction=-1):
    ok=x<=threshold if direction<0 else x>=threshold
    ix=np.flatnonzero(ok)
    if not len(ix):return -1.
    i=int(ix[0])
    if i==0:return 0.
    return float(t[i-1]+(threshold-x[i-1])/(x[i]-x[i-1])*(t[i]-t[i-1]))
def trajectory_metrics(p,z,method,panel,nominal='',kv=10.):
    t=z['t'];T=t[-1];h=z['h'];v=z['v'];d=z['d'];a=z['a'];u=z['u']
    rows=[]
    for i in range(len(v)):
        jerk=np.diff(a[i])/np.diff(t)
        rows.append({'panel':panel,'method':method,'nominal':nominal,'kappa_v':kv,'vehicle':i+1,
          'h0':float(z['h0'][i]),'v0':float(z['v0'][i]),'T':T,'dt_output':float(t[1]-t[0]),
          'first_v001':event_time(t,v[i],.001,1),
          'first_gap_eta001':event_time(t,d[i],p.eps+.2+.01),
          'min_h':float(h[i].min()),'min_v':float(v[i].min()),'min_upper':float((p.M-v[i]).min()),
          'max_input_excess':float(np.maximum(np.abs(u[i])-p.U,0).max()),
          'terminal_h':float(h[i,-1]),'terminal_d':float(d[i,-1]),'terminal_v':float(v[i,-1]),
          'terminal_excess':float(max(0,d[i,-1]-p.eps-.2)),'peak_v':float(v[i].max()),
          'distance_travelled':float(np.trapezoid(v[i],t)),
          'acceleration_RMS':float(math.sqrt(np.trapezoid(a[i]**2,t)/T)),
          'jerk_RMS_fd':float(math.sqrt(np.mean(jerk**2))),
          'control_effort':float(np.trapezoid(u[i]**2,t)),
          'solver_node_min_h':z['solver_node_min_h'],'solver_node_min_v':z['solver_node_min_v'],
          'solver_node_min_upper':z['solver_node_min_upper']})
    return rows
def save_trace(name,z):np.savez_compressed(R/'data'/f'{name}.npz',**z)

def run_oracles(legacy):
    rows=readcsv(legacy/'data/long_horizon.csv');details=[];oracles=[];summaries=[]
    for obj in ['gap','tracking']:
        hg=0. if obj=='gap' else .2
        for fixture,p in PLANTS.items():
            for h0 in [0.,.05,.2,.25,.4,.8,1.4]:
                for eta in [.01,.05]:
                    d0=p.eps+h0;dtarg=p.eps+hg+eta
                    if d0<=dtarg+1e-12:continue
                    base=spatial_oracle(p,d0,0,dtarg,rtol=1e-8,atol=1e-10,subdiv=128)
                    best=spatial_oracle(p,d0,0,dtarg,rtol=1e-11,atol=1e-13,subdiv=512)
                    independent=time_oracle(p,d0,0,dtarg)
                    oq={'objective':obj,'fixture':fixture,'h0':h0,'eta':eta,'T_star':best['T'],
                      'T_star_coarse':base['T'],'T_time_domain':independent,
                      'spatial_refinement_error':abs(best['T']-base['T']),
                      'independent_time_error':abs(best['T']-independent),'ceiling_time':best['ceiling_time'],
                      'ceiling_hit_distance':best['hit_s'],'nfev':best['nfev']}
                    oracles.append(oq)
                    matched=[r for r in rows if r['objective']==obj and r['fixture']==fixture and abs(float(r['h0'])-h0)<1e-12]
                    assert len(matched)==4
                    for r in matched:
                        ent=float(r['first_d_goal001' if eta==.01 else 'first_d_goal005'])
                        details.append(oq|{'method':r['method'],'entry_time':ent,'entered_by_60':ent>=0,
                                        'entry_ratio':ent/best['T'] if ent>=0 else math.nan,
                                        'legacy_scenario':r['scenario_id']})
        for eta in [.01,.05]:
            for method in ['old_product','standard_cbf','gap_product','cbf_gap']:
                rr=[r for r in details if r['objective']==obj and r['eta']==eta and r['method']==method]
                good=[r for r in rr if r['entered_by_60']]
                summaries.append({'objective':obj,'eta':eta,'method':method,'eligible':len(rr),'entered_by_60':len(good),
                  'median_T_star':float(np.median([r['T_star'] for r in rr])),
                  'median_entry_ratio_among_entered':float(np.median([r['entry_ratio'] for r in good])) if good else math.nan,
                  'max_entry_ratio_among_entered':max([r['entry_ratio'] for r in good],default=math.nan),
                  'median_entry_time_among_entered':float(np.median([r['entry_time'] for r in good])) if good else math.nan})
    csvwrite('oracles.csv',oracles);csvwrite('oracle_comparisons.csv',details);csvwrite('oracle_summary.csv',summaries)
    print('Spatial oracles:',len(oracles),'paired comparisons:',len(details),flush=True)
    return details,oracles,summaries

def run_partial():
    p=Plant('P',1,1,M=1,U=1,kind='partial');traces={};rows=[]
    for meth,kv in [('max_input',1),('gap_product',1),('cbf_gain1',1),('cbf_gain2',2)]:
        z=simulate(p,[.2],0.6,meth,T=25,kv=kv);traces[meth]=z
        save_trace('partial_'+meth,z);rows+=trajectory_metrics(p,z,meth,'partial_boundary',kv=kv)
    refined=[]
    for meth,kv in [('max_input',1),('gap_product',1),('cbf_gain1',1),('cbf_gain2',2)]:
        z=simulate(p,[.2],.6,meth,T=25,kv=kv,fine=True)
        refined+=trajectory_metrics(p,z,meth,'partial_boundary_refined',kv=kv)
    grid=[]
    # The map is an exact analytic classification, not finite-horizon inference.
    for v0 in np.linspace(0,1,51):
        for h0 in np.linspace(0,.6,61):
            d0=p.eps+v0+h0;S=d0-(p.eps+.2+.01)
            exact=0. if S<=0 else (-math.log1p(-S/v0) if v0>0 and S<v0 else math.inf)
            grid.append({'h0':h0,'v0':v0,'d0':d0,'asymptotically_recoverable':h0<=.2+1e-12,
                         'T_eta001_exact':exact})
    csvwrite('partial_basin_exact.csv',grid);csvwrite('partial_boundary.csv',rows);csvwrite('partial_boundary_refined.csv',refined)
    return traces,rows,refined

def run_finite_and_sign():
    p=PLANTS['C3'];traces={};rows=[];refined=[]
    for panel,h0,leader in [('finite_leader',[.8],'exponential'),('platoon',[.8,.6,.4,.8,.6],'pulse')]:
        for meth in ['gap_product','cbf_gap']:
            z=simulate(p,h0,0,meth,T=60,leader_kind=leader);traces[panel+'_'+meth]=z
            save_trace(panel+'_'+meth,z);rows+=trajectory_metrics(p,z,meth,panel)
            zz=simulate(p,h0,0,meth,T=60,leader_kind=leader,fine=True)
            refined+=trajectory_metrics(p,zz,meth,panel+'_refined')
    sign=[];signfine=[]
    for nominal in [-.5,0.,.5]:
        for meth in ['standard_cbf','gap_product','cbf_gap']:
            z=simulate(p,[.4],0,meth,T=60,nominal=nominal)
            traces[f'sign_{nominal}_{meth}']=z;save_trace(f'sign_{nominal}_{meth}',z)
            sign+=trajectory_metrics(p,z,meth,'nominal_sign',nominal=nominal)
            zz=simulate(p,[.4],0,meth,T=60,nominal=nominal,fine=True)
            signfine+=trajectory_metrics(p,zz,meth,'nominal_sign_refined',nominal=nominal)
    csvwrite('finite_travel.csv',rows);csvwrite('finite_travel_refined.csv',refined)
    csvwrite('nominal_sign.csv',sign);csvwrite('nominal_sign_refined.csv',signfine)
    return traces,rows,refined,sign,signfine

def figures(details,partial,traces):
    fig,ax=plt.subplots(1,2,figsize=(7.1,2.6),layout='constrained')
    methods=['standard_cbf','gap_product','cbf_gap']
    for j,obj in enumerate(['gap','tracking']):
        for i,meth in enumerate(methods):
            rr=[r for r in details if r['objective']==obj and r['eta']==.01 and r['method']==meth]
            vals=[r['entry_ratio'] for r in rr if r['entered_by_60']]
            x=i+3.7*j
            offsets=np.linspace(-.17,.17,len(vals))
            ax[0].scatter(x+offsets,vals,s=13,color=COLORS[meth],alpha=.8,edgecolors='none')
            ax[0].plot([x-.2,x+.2],[np.median(vals)]*2,color='#162c40',lw=1)
            ax[0].text(x,.79,f'{len(vals)}/{len(rr)}',ha='center',fontsize=6.5)
    ax[0].axhline(1,color='.45',ls='--',lw=.7);ax[0].set_yscale('log')
    ax[0].set_xticks([0,1,2,3.7,4.7,5.7],['CBF','Blend','R-CBF','CBF','Blend','R-CBF'])
    ax[0].set_ylabel(r'Observed entry time / $T^*_{0.01}$')
    ax[0].set_title('(a) Optimal-entry benchmark')
    ax[0].text(1,.64,'Gap',ha='center',transform=ax[0].get_xaxis_transform()) if False else None
    ax[0].set_xlabel('Gap task                       Tracking task')
    ax[0].set_ylim(.65,130);ax[0].grid(axis='y',which='major',alpha=.18)
    # Analytic safe domain and exact capture band.
    ax[1].add_patch(Polygon([[0,0],[1.1,0],[1.1,.82],[.82,.82]],closed=True,facecolor='#eeeeee',edgecolor='none'))
    poly=Polygon([[0,0],[.2,0],[1.2,1],[1,1]],closed=True,facecolor='#dcecf0',edgecolor='none')
    ax[1].add_patch(poly)
    ax[1].plot([0,1],[0,1],color='.5',lw=.6)
    ax[1].plot([.2,1.2],[0,1],color='#356778',ls='--',lw=.9)
    for meth in ['max_input','gap_product','cbf_gain2']:
        z=partial[meth];ax[1].plot(z['d'][0]-.02,z['v'][0],color=COLORS[meth],lw=1.4,label=LABELS[meth])
        ax[1].scatter(z['d'][0,-1]-.02,z['v'][0,-1],s=16,color=COLORS[meth],zorder=5)
    ax[1].scatter([.8],[.6],s=25,facecolor='white',edgecolor='#162c40',zorder=6)
    ax[1].plot([0,.2],[0,0],color='#172f4b',lw=3)
    ax[1].set(xlim=(0,1.1),ylim=(-.025,.82),xlabel=r'Physical clearance $d-\epsilon$',ylabel='Speed $v$')
    ax[1].set_title('(b) Exact partial recoverability set')
    ax[1].text(.50,.43,r'$h\leq h_g$',color='#356778',rotation=32,fontsize=8)
    ax[1].legend(loc='upper left',frameon=False,fontsize=6.6)
    export_figure(fig,'v5_spatial_summary');plt.close(fig)

    fig,ax=plt.subplots(2,2,figsize=(7.1,4.2),layout='constrained')
    colors=plt.cm.viridis(np.linspace(.12,.88,5))
    for col,meth in enumerate(['gap_product','cbf_gap']):
        z=traces['platoon_'+meth]
        for i,c in enumerate(colors):
            ax[0,col].plot(z['t'],z['d'][i]-.02,color=c,lw=1,label=f'Follower {i+1}')
            ax[1,col].plot(z['t'],z['v'][i],color=c,lw=1)
        ax[0,col].axhline(.2,ls='--',color='.3',lw=.7)
        ax[1,col].plot(z['t'],z['w'][0],color='black',ls=':',lw=1.2,label='Head vehicle')
        ax[0,col].set_title(LABELS[meth]);ax[1,col].set_xlabel('Time')
        ax[0,col].set_ylabel(r'$d_i-\epsilon$');ax[1,col].set_ylabel('Speed')
        ax[0,col].set_xlim(0,20);ax[1,col].set_xlim(0,20)
        ax[0,col].grid(alpha=.15);ax[1,col].grid(alpha=.15)
    ax[0,0].legend(ncol=2,loc='upper right',fontsize=6.5,frameon=False)
    ax[1,1].legend(loc='upper right',frameon=False)
    export_figure(fig,'v5_platoon');plt.close(fig)

    fig,ax=plt.subplots(2,1,figsize=(3.4,2.55),sharex=True,layout='constrained')
    z=traces['platoon_cbf_gap']
    for i,c in enumerate(colors):
        ax[0].plot(z['t'],z['d'][i]-.02,color=c,lw=1,label=str(i+1))
        ax[1].plot(z['t'],z['v'][i],color=c,lw=1)
    ax[0].axhline(.2,ls='--',color='.3',lw=.7)
    ax[1].plot(z['t'],z['w'][0],color='black',ls=':',lw=1.1,label='Head')
    ax[0].set_ylabel(r'$d_i-\epsilon$');ax[1].set_ylabel('Speed');ax[1].set_xlabel('Time')
    ax[0].set_xlim(0,15);ax[0].set_ylim(0,1.45);ax[0].legend(ncol=5,title='Follower',title_fontsize=6,fontsize=6,frameon=False,loc='upper right',columnspacing=.7,handlelength=1)
    ax[1].legend(frameon=False,loc='upper right',fontsize=6)
    for a in ax:a.grid(alpha=.15)
    export_figure(fig,'v5_platoon_compact');plt.close(fig)

    fig,ax=plt.subplots(1,3,figsize=(7.1,2.25),layout='constrained')
    for j,nom in enumerate([-.5,0.,.5]):
        for meth in methods:
            z=traces[f'sign_{nom}_{meth}'];ax[j].plot(z['t'],z['d'][0]-.02,color=COLORS[meth],lw=1.2,label=LABELS[meth])
        ax[j].axhline(.21,color='.5',ls='--',lw=.7)
        ax[j].set(title=rf'$p_{{\rm nom}}(d_0,0)={nom:g}$',xlabel='Time',xlim=(0,60),ylim=(0,.43))
        ax[j].grid(alpha=.15)
    ax[0].set_ylabel(r'Physical clearance $d-\epsilon$');ax[1].legend(loc='lower right',frameon=False,fontsize=6)
    export_figure(fig,'v5_nominal_sign');plt.close(fig)

def tables(summaries,rows,sign):
    table=['\\begin{tabular}{llrcccc}','\\toprule',
      'Task & $\\eta$ & $n$ & med. $T^*_\\eta$ & CBF & Blend & R-CBF\\\\','\\midrule']
    for obj in ['gap','tracking']:
        for eta in [.01,.05]:
            rr=[r for r in summaries if r['objective']==obj and r['eta']==eta]
            by={r['method']:r for r in rr};ref=by['cbf_gap']
            cells=[]
            for m in ['standard_cbf','gap_product','cbf_gap']:
                r=by[m];cells.append(f"{r['entered_by_60']:.0f}/{r['eligible']:.0f}; {r['median_entry_ratio_among_entered']:.2f}")
            table.append(f"{'Gap' if obj=='gap' else 'Tracking'} & {eta:.2f} & {ref['eligible']:.0f} & {ref['median_T_star']:.3f} & "+' & '.join(cells)+r'\\')
    table+=['\\bottomrule','\\end{tabular}']
    (R/'tables/oracle_summary.tex').write_text('\n'.join(table)+'\n')
    table=['\\begin{tabular}{llrrrr}','\\toprule','Panel & Method & max. $v(60)$ & max. excess & min. $h$ & mean $a_{\\rm rms}$\\\\','\\midrule']
    for panel in ['finite_leader','platoon']:
        for method in ['gap_product','cbf_gap']:
            rr=[r for r in rows if r['panel']==panel and r['method']==method]
            table.append(f"{panel.replace('_',' ')} & {'Blend' if method=='gap_product' else 'R-CBF'} & {max(r['terminal_v'] for r in rr):.2e} & {max(r['terminal_excess'] for r in rr):.2e} & {min(r['min_h'] for r in rr):.3f} & {np.mean([r['acceleration_RMS'] for r in rr]):.3f}"+r'\\')
    table+=['\\bottomrule','\\end{tabular}'];(R/'tables/finite_travel.tex').write_text('\n'.join(table)+'\n')
    table=['\\begin{tabular}{lrrr}','\\toprule','$p_0$ & Ordinary CBF & Recovery blend & Recovery CBF\\\\','\\midrule']
    for nom in [-.5,0.,.5]:
        cells=[]
        for method in ['standard_cbf','gap_product','cbf_gap']:
            r=next(r for r in sign if r['nominal']==nom and r['method']==method)
            cells.append(f"{r['first_gap_eta001']:.3f}" if r['first_gap_eta001']>=0 else r'$>60$')
        table.append(f'{nom:+.1f} & '+' & '.join(cells)+r'\\')
    table+=['\\bottomrule','\\end{tabular}'];(R/'tables/nominal_sign.tex').write_text('\n'.join(table)+'\n')

def validation(oracles,partial,pfine,rows,refined,sign,signfine):
    unit=Plant('unit',1,1,eps=1,M=1,U=1,kind='unit')
    tests=[]
    for d0,dtarg in [(2.25,2.),(3.,2.),(2.25,1.01)]:
        s=spatial_oracle(unit,d0,0,dtarg,rtol=1e-11,atol=1e-13,subdiv=512)['T']
        tt=time_oracle(unit,d0,0,dtarg)
        tests.append({'d0':d0,'target':dtarg,'spatial':s,'time_domain':tt,'error':abs(s-tt)})
    # Full-throttle analytic partial example: s=v0(1-exp(-t)).
    partial_entries=[]
    for v0,S in [(.6,.2),(.6,.59),(.2,.19)]:
        exact=-math.log1p(-S/v0)
        val=quad(lambda x:1/(v0-x),0,S,epsabs=1e-12)[0]
        partial_entries.append({'v0':v0,'S':S,'exact':exact,'quadrature':val,'error':abs(exact-val)})
    pairs=[]
    for base,fine in [(partial,pfine),(rows,refined),(sign,signfine)]:
        for a,b in zip(base,fine):
            assert a['method']==b['method'] and a['vehicle']==b['vehicle']
            pairs.append({'panel':a['panel'],'method':a['method'],'vehicle':a['vehicle'],'nominal':a['nominal'],
                'terminal_d_difference':abs(a['terminal_d']-b['terminal_d']),
                'terminal_v_difference':abs(a['terminal_v']-b['terminal_v']),
                'entry_difference':abs(a['first_gap_eta001']-b['first_gap_eta001']) if min(a['first_gap_eta001'],b['first_gap_eta001'])>=0 else 0.,
                'entry_classification_changed':(a['first_gap_eta001']>=0)!=(b['first_gap_eta001']>=0),
                'accel_RMS_difference':abs(a['acceleration_RMS']-b['acceleration_RMS'])})
    csvwrite('integration_refinement.csv',pairs)
    allrows=partial+pfine+rows+refined+sign+signfine
    v={'oracle_cases':len(oracles),'legacy_paired_observations':4*len(oracles),
       'max_spatial_refinement_error':max(r['spatial_refinement_error'] for r in oracles),
       'max_independent_time_error':max(r['independent_time_error'] for r in oracles),
       'unit_integrator_tests':tests,'unit_analytic_error':abs(tests[0]['spatial']-1/math.sqrt(2)),
       'partial_exact_tests':partial_entries,
       'max_terminal_d_refinement':max(r['terminal_d_difference'] for r in pairs),
       'max_terminal_v_refinement':max(r['terminal_v_difference'] for r in pairs),
       'max_event_time_refinement':max(r['entry_difference'] for r in pairs),
       'entry_classification_changes':sum(r['entry_classification_changed'] for r in pairs),
       'accepted_grid_min_h':min(r['min_h'] for r in allrows),
       'accepted_grid_min_v':min(r['min_v'] for r in allrows),
       'accepted_grid_min_upper':min(r['min_upper'] for r in allrows),
       'solver_node_min_h':min(r['solver_node_min_h'] for r in allrows),
       'solver_node_min_v':min(r['solver_node_min_v'] for r in allrows),
       'max_input_excess':max(r['max_input_excess'] for r in allrows),
       'new_independent_ODE_system_solves':34,'scalar_vehicle_records_both_resolutions':len(allrows),
       'note':'Adaptive solver nodes and reported grids checked; internal RK stages are not logged. Numerical checks are not continuous-time safety certificates. No state projection or interval widening.',
       'lower_bound_status':'Exact theorem, numerically evaluated. Observed agreement and refinement are accuracy checks, not interval-certified lower bounds.'}
    assert v['max_independent_time_error']<1e-5
    assert v['unit_analytic_error']<1e-7
    assert v['accepted_grid_min_h']>-1e-7 and v['accepted_grid_min_v']>-1e-7
    assert v['max_input_excess']<1e-8 and v['entry_classification_changes']==0
    jwrite('validation.json',v);return v

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--legacy',type=Path,required=True);ap.add_argument('--render-only',action='store_true');args=ap.parse_args()
    start=time.perf_counter()
    if args.render_only:
        details=typedcsv(R/'data/oracle_comparisons.csv');oracles=typedcsv(R/'data/oracles.csv');summaries=typedcsv(R/'data/oracle_summary.csv')
        partial={m:dict(np.load(R/'data'/f'partial_{m}.npz')) for m in ['max_input','gap_product','cbf_gain1','cbf_gain2']}
        traces={p.stem:dict(np.load(p)) for p in (R/'data').glob('*.npz') if not p.stem.startswith('partial_')}
        pr=typedcsv(R/'data/partial_boundary.csv');pfine=typedcsv(R/'data/partial_boundary_refined.csv')
        rr=typedcsv(R/'data/finite_travel.csv');rref=typedcsv(R/'data/finite_travel_refined.csv')
        sr=typedcsv(R/'data/nominal_sign.csv');sref=typedcsv(R/'data/nominal_sign_refined.csv')
    else:
        details,oracles,summaries=run_oracles(args.legacy)
        partial,pr,pfine=run_partial();print('Partial basin experiment complete',flush=True)
        traces,rr,rref,sr,sref=run_finite_and_sign();print('Finite travel and nominal sign experiments complete',flush=True)
    val=validation(oracles,pr,pfine,rr,rref,sr,sref)
    figures(details,partial,traces);tables(summaries,rr,sr)
    protocol={'legacy_input':str(args.legacy),'legacy_csv_sha256':hashlib.sha256((args.legacy/'data/long_horizon.csv').read_bytes()).hexdigest(),
      'units':'Normalized illustrative fixtures; no vehicle calibration','no_retuning':True,
      'inherited_parameters':{'N':50,'h_s':.2,'s_h':1,'s_v':'M','lambda_tracking':.1,'h_g_tracking':.2,'CBF_gains':[10,10,10]},
      'new_fixture_parameters':{'partial':'a=-1-v, b=U=M=gamma=1, epsilon=.02, h_g=.2; initial h=.2,v=.6; k=0; kappa_v=1 and 2 explicitly varied as a structural diagnostic'},
      'finite_leader':'C3, k=0, h0=.8,v0=0; w=1.2 exp(-t/2), total travel2.4',
      'platoon':'C3 all five followers, k=0, initial h=[.8,.6,.4,.8,.6],v=0; head w=1.2 sin^2(pi*t/4) for 0<t<4 and0 otherwise; totaltravel2.4',
      'sign_ablation':'C3,h0=.4,v0=0,w=0; nominal k=clip(p0-a,-U,U),p0 in[-.5,0,.5]; pnom equals p0 at all initial states',
      'integrator':'DOP853 base rtol2e-9,atol2e-11,maxstep.02; refinement2e-11,2e-13,maxstep.01; output grids .01/.005; no state projection',
      'event':'first physical d<=epsilon+h_g+.01 with linear interpolation on output grids; nonentryby60 is censored, not proof of noncapture',
      'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
      'wall_seconds_this_run':time.perf_counter()-start,'render_only':args.render_only,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    jwrite('protocol.json',protocol)
    print(json.dumps(clean_json(val),indent=2),flush=True)
    print('Finished in',protocol['wall_seconds_this_run'],'seconds',flush=True)
if __name__=='__main__':main()
