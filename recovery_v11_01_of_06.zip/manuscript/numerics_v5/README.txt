REVISION 5 STRUCTURAL NUMERICAL EXPERIMENTS

Run from this directory:
  python3 run_v5.py --legacy ../numerics
  python3 gain_sensitivity.py --legacy ../numerics

Dependencies: Python 3, NumPy, SciPy, Matplotlib, pypdf; a C++17 compiler for
gain_sensitivity.py. The legacy directory is the unchanged Revision 4
numerical package. No external downloads or optimization packages are used.

run_v5.py computes 54 positive-tolerance spatial optimal-entry cases,
pairs them with 216 frozen long-horizon observations, creates the exact
partial recoverability map, and runs 34 new adaptive feedback-system
integrations (50 scalar-vehicle trajectory records, because a platoon
system contains five vehicles). Half use tighter tolerances and reporting
grids. It also checks analytic special cases and independently reconstructs
the oracle via time-domain integration. These are numerical error checks,
not interval-certified lower bounds. The --render-only option regenerates
figures and tables from the retained numerical records.

gain_sensitivity.py declares lambda={0.1,0.3,1,2} before running a fixed
tracking scenario h0=.8,v0=0 in all three fixtures for both recovery filters.
Every result is retained. T10 cost/variation and T60 entry events are
calculated at steps .005 and .0025, for 96 integrations across 24 settings.
No winning gain is selected and the prior benchmark is not retuned.
The lambda=.1 event times exactly reproduce the frozen legacy rows.

The main comparison joins objective, fixture, h0, and tolerance. The oracle
optimizes first physical-gap entry and has no terminal rest, jerk, or
quadratic-cost condition. Nonentries by T60 remain censored; conditional
medians for differing success sets must not be treated as paired rankings.

The partial recoverability map is exact analytic classification, not a
finite-horizon estimate. Its test plant has A_+(d,0)=0 everywhere, so it
does not satisfy the global recovery assumption used by the existing
filters. The simulations explicitly demonstrate loss of capture under
some safe filters, while maximum input and one structural CBF gain retain
the exact basin. This limitation must be retained in interpretation.

The finite-travel tests use the original C3 fixture and controller
parameters, with k=0, and add an exponential leader and a five-follower
finite-pulse platoon. No string-stability claim is inferred. The nominal
sign ablation sets k=clip(p0-a,-U,U), not k=p0, so the requested net
acceleration at the chosen rest state is actually negative, zero, or
positive as indicated.

All quantities are normalized illustrations; no new vehicle calibration,
physical ride-comfort guarantee, sampled-data safety, or universal method
dominance is asserted. Adaptive closed-loop integration has no physical
state projection, interval widening, or safety slack. Reporting-grid and
solver-node minima are retained; unlogged internal adaptive stages are
not claimed to have been exhaustively checked.

FILES
  data/oracles.csv                  one row per spatial benchmark
  data/oracle_comparisons.csv       all paired legacy events, with censoring
  data/oracle_summary.csv           conditional medians and entry denominators
  data/partial_basin_exact.csv      3111 exact analytic classifications
  data/partial_boundary*.csv/npz    boundary capture-loss diagnostic
  data/finite_travel*.csv/npz       single follower and five-follower tests
  data/nominal_sign*.csv/npz        autonomous net-acceleration sign tests
  data/integration_refinement.csv  matched adaptive-resolution comparison
  data/gain_sensitivity*.csv        all 24 settings and 96 integrations
  figures/                         vector PDF and PNG plots
  tables/                          generated LaTeX tables
  validation.json                  oracle and adaptive checks
  gain_validation.json             fixed-step checks and legacy identity
  protocol.json / gain_protocol.json
                                   exact settings and source identities
  legacy_adapter/                  unchanged legacy engine/kernel copy;
                                   compiled binary can be regenerated
