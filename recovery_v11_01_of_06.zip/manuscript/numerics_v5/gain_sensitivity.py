#!/usr/bin/env python3
"""Declared lambda sensitivity grid, retaining every result; no selection step.

python gain_sensitivity.py --legacy ../numerics
Reuses the frozen medium HJB actions and unchanged Revision 4 C++ kernel.
"""
from __future__ import annotations
import argparse, csv, hashlib, importlib.util, json, math, os, shutil, time
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/ecc_v5_mpl')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent

def readcsv(p):return list(csv.DictReader(p.open()))
def writecsv(p,rows):
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--legacy',required=True,type=Path);args=ap.parse_args()
 start=time.perf_counter();adapter=R/'legacy_adapter';adapter.mkdir(exist_ok=True)
 for name in ['engine.py','kernel.cpp']:shutil.copy2(args.legacy/name,adapter/name)
 spec=importlib.util.spec_from_file_location('v5legacy',adapter/'engine.py');E=importlib.util.module_from_spec(spec)
 import sys
 sys.modules['v5legacy']=E;spec.loader.exec_module(E)
 lib,compiler=E.compile_kernel();raw=[]
 lambdas=[.1,.3,1.,2.]
 # Parameters and scenarios are declared before any simulation in this script.
 (R/'gain_protocol.json').write_text(json.dumps({'lambda_grid':lambdas,'fixtures':['C1','C2','C3'],
  'methods':['gap_product','cbf_gap'],'h0':.8,'v0':0,'h_g':.2,'nominal':'unchanged frozen ten-unit HJB tracking policy, zero extension after t10',
  'horizons':[10,60],'dt':[.005,.0025],'all_results_retained':True,'selection':'none',
  'no_other_parameter_changes':True,'kernel_sha256':hashlib.sha256((adapter/'kernel.cpp').read_bytes()).hexdigest()},indent=2))
 for model in E.MODELS:
  ident=f'{model.name}__w5_stopped__tracking__medium';z=np.load(args.legacy/'policies'/f'{ident}.npz')
  pol={'u':np.ascontiguousarray(z['u'],dtype=np.float32),'t':z['t'],'d':z['d'],'v':z['v'],
   'dt':.05,'dd':.1,'dv':float(z['v'][1]-z['v'][0]),'level':'medium','id':ident,
   'model':model,'profile':'w5_stopped','objective':'tracking'}
  states=[{'scenario_id':f'{model.name}_lambda_h08','split':'lambda_sensitivity','h0':.8,'v0':0.}]
  methods=[]
  for lam in lambdas:
   methods += [
    {'name':f'blend_lambda_{lam:g}','family':'gap_product','pars':[2,50,0,0,lam,.2,.2,0]},
    {'name':f'cbf_lambda_{lam:g}','family':'cbf_gap','pars':[5,10,10,10,lam,.2,.2,50]}]
  for T in [10.,60.]:
   E.T=T
   for dt in [.005,.0025]:
    rows=E.simulate(lib,pol,states,methods,dt=dt,trace_index=-1,save_trace=False,tag=f'lambda_T{T:g}')
    for r in rows:r['T']=T;r['lambda']=float(r['method'].split('_')[-1])
    raw.extend(rows)
 writecsv(R/'data/gain_sensitivity_raw.csv',raw)
 oracles=readcsv(R/'data/oracles.csv');summary=[]
 for model in ['C1','C2','C3']:
  Ts={float(q['eta']):float(q['T_star']) for q in oracles if q['fixture']==model and q['objective']=='tracking' and float(q['h0'])==.8}
  for family in ['gap_product','cbf_gap']:
   for lam in lambdas:
    select=lambda T,dt:next(r for r in raw if r['fixture']==model and r['family']==family and r['lambda']==lam and r['T']==T and r['dt']==dt)
    short=select(10.,.005);long=select(60.,.005);shortfine=select(10.,.0025);longfine=select(60.,.0025)
    t01=long['first_d_goal001'];t05=long['first_d_goal005']
    summary.append({'fixture':model,'method':family,'lambda':lam,'T_star001':Ts[.01],'T_star005':Ts[.05],
     'entry001':t01,'entry005':t05,'ratio001':t01/Ts[.01] if t01>=0 else math.nan,
     'ratio005':t05/Ts[.05] if t05>=0 else math.nan,'J10':short['J'],
     'acceleration_RMS10':short['acceleration_RMS'],'jerk_RMS_fd10':short['jerk_RMS_fd'],
     'J10_refinement_relative':abs(short['J']-shortfine['J'])/max(abs(shortfine['J']),1e-14),
     'event001_refinement_absolute':abs(t01-longfine['first_d_goal001']) if min(t01,longfine['first_d_goal001'])>=0 else 0.,
     'event_classification_changed':(t01>=0)!=(longfine['first_d_goal001']>=0),
     'min_h':min(short['min_h'],long['min_h'],shortfine['min_h'],longfine['min_h']),
     'min_stage_h':min(short['min_stage_h'],long['min_stage_h'],shortfine['min_stage_h'],longfine['min_stage_h'])})
 writecsv(R/'data/gain_sensitivity_summary.csv',summary)
 baseline=readcsv(args.legacy/'data/long_horizon.csv');identity=[]
 for r in summary:
  if r['lambda']!=.1:continue
  old=next(q for q in baseline if q['fixture']==r['fixture'] and q['objective']=='tracking' and q['method']==r['method'] and float(q['h0'])==.8)
  identity.append({'fixture':r['fixture'],'method':r['method'],'entry_difference':abs(float(old['first_d_goal001'])-r['entry001'])})
 plt.rcParams.update({'font.size':8,'axes.titlesize':9,'legend.fontsize':7,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
 fig,ax=plt.subplots(2,3,figsize=(7.1,4),layout='constrained')
 for j,model in enumerate(['C1','C2','C3']):
  for family,color,marker,label in [('gap_product','#d06436','o','Recovery blend'),('cbf_gap','#087d8b','s','Recovery CBF')]:
   rr=[r for r in summary if r['fixture']==model and r['method']==family]
   xx=[r['lambda'] for r in rr]
   ax[0,j].plot(xx,[r['ratio001'] for r in rr],color=color,marker=marker,ms=3,lw=1,label=label)
   ax[1,j].plot(xx,[r['J10']/rr[0]['J10'] for r in rr],color=color,marker=marker,ms=3,lw=1)
  ax[0,j].set_title(model);ax[0,j].set_yscale('log');ax[0,j].axhline(1,color='.5',ls='--',lw=.7)
  for q in ax[:,j]:q.set_xscale('log');q.set_xticks(lambdas,['0.1','0.3','1','2']);q.grid(alpha=.15)
  ax[1,j].set_xlabel(r'Recovery gain $\lambda$');ax[1,j].axhline(1,color='.5',ls='--',lw=.7)
 ax[0,0].set_ylabel(r'$T_{0.01}/T^*_{0.01}$');ax[1,0].set_ylabel(r'$J_{10}(\lambda)/J_{10}(0.1)$');ax[0,1].legend(frameon=False)
 fig.savefig(R/'figures/v5_gain_sensitivity.pdf');fig.savefig(R/'figures/v5_gain_sensitivity.png',dpi=180);plt.close(fig)
 lines=['\\begin{longtable}{llrrrrrr}','\\toprule','Fixture & Method & $\\lambda$ & $T_{.01}/T^*_{.01}$ & $T_{.01}$ & $J_{10}$ & $a_{\\rm rms}$ & $j_{\\rm fd,rms}$\\\\','\\midrule','\\endhead']
 for r in summary:
  lines.append(f"{r['fixture']} & {'Blend' if r['method']=='gap_product' else 'R-CBF'} & {r['lambda']:g} & {r['ratio001']:.2f} & {r['entry001']:.3f} & {r['J10']:.4f} & {r['acceleration_RMS10']:.4f} & {r['jerk_RMS_fd10']:.4f}"+r'\\')
 lines+=['\\bottomrule','\\end{longtable}'];(R/'tables/gain_sensitivity.tex').write_text('\n'.join(lines)+'\n')
 val={'settings':len(summary),'integrations':len(raw),'identity_to_frozen_lambda01':identity,
  'max_J10_relative_refinement':max(r['J10_refinement_relative'] for r in summary),
  'max_event001_absolute_refinement':max(r['event001_refinement_absolute'] for r in summary),
  'entry_classification_changes':sum(r['event_classification_changed'] for r in summary),
  'safety_violations':sum(r['safety_status']=='violation' for r in raw),'failed_integrations':sum(r['status']!='completed' for r in raw),
  'min_stage_h':min(r['min_stage_h'] for r in raw),'wall_seconds':time.perf_counter()-start,
  'compiler':compiler,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 assert max(r['entry_difference'] for r in identity)<1e-12
 assert val['safety_violations']==0 and val['failed_integrations']==0 and val['entry_classification_changes']==0
 (R/'gain_validation.json').write_text(json.dumps(val,indent=2,default=lambda x:x.item()));print(json.dumps(val,indent=2,default=lambda x:x.item()),flush=True)
if __name__=='__main__':main()
