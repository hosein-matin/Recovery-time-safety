"""Copy verified V6 numerical assets and generate the compact paper tables."""
from pathlib import Path
import argparse
import csv
import json
import math
import shutil

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, default=ROOT.parent / 'numerics_v6')
args = parser.parse_args()
source = args.source.resolve()


def normalize_table_labels(text):
    """Standardize manuscript notation without changing numerical table cells."""
    replacements = [
        ('I_H^{(2)}', 'I_{2,H}'), ('I_{10}^{(2)}', 'I_{2,10}'),
        ('I_H', 'I_{1,H}'), ('I_{10}', 'I_{1,10}'),
        (r'I_{\rm ent}', r'I_{1,\rm ent}'),
        ('Opposing', 'Braking'), ('opposing', 'braking'),
    ]
    for old, new in replacements:
        text = text.replace(old, new)
    return text

for kind, pattern in [('figures', '*.pdf'), ('tables', '*.tex')]:
    destination = ROOT / kind / 'v6'
    destination.mkdir(parents=True, exist_ok=True)
    for item in (source / kind).glob(pattern):
        target = destination / item.name
        if kind == 'tables':
            target.write_text(normalize_table_labels(item.read_text()))
        else:
            shutil.copyfile(item, target)

labels = {
    'ordinary_cbf': 'Ordinary CBF', 'recovery_blend': 'Recovery blend',
    'recovery_cbf': 'Recovery CBF', 'progress_r0316': r'Progress $r=\sqrt{.1}$',
    'progress_r0500': r'Progress $r=.5$', 'progress_r0707': r'Progress $r=\sqrt{.5}$',
    'progress_r1000': r'Progress $r=1$', 'progress_c2': r'Progress $r=.5,c=2$',
    'progress_c10': r'Progress $r=.5,c=10$', 'rate_010': r'Reflected $\theta=.1$',
    'rate_025': r'Reflected $\theta=.25$', 'rate_050': r'Reflected $\theta=.5$',
    'rate_100': r'Optimal profile ($\theta=1$)',
}
summary = json.loads((source / 'summary.json').read_text())
lines = [r'\begin{tabular}{lrrrrrr}', r'\toprule',
         r'Method & Entry & Median $T/T^*$ & Max. $T/T^*$ & Median $I_{1,10}$ & Median $A_{10}$ & Median $\widehat{\mathrm{TV}}_{10}$ \\',
         r'\midrule']
for row in summary['methods']:
    lines.append('{} & {}/{} & {:.2f} & {:.2f} & {:.2f} & {:.3f} & {:.2f} \\\\'.format(
        labels[row['method']], row['entered'], row['n'], row['entry_ratio_median'],
        row['entry_ratio_max'], row['L1_intervention10_median'],
        row['accel_RMS10_median'], row['accel_TV10_grid_median']))
lines += [r'\bottomrule', r'\end{tabular}']
(ROOT / 'tables/v6/main_methods.tex').write_text('\n'.join(lines) + '\n')

episodes = list(csv.DictReader((source / 'data/episodes.csv').open()))
selected = {row['method']: row for row in episodes if row['plant'] == 'C2'
            and row['task'] == 'tracking' and float(row['h0']) == .8
            and float(row['v0']) == 0 and row['nominal'] == 'opposing'}
lines = [r'\begin{tabular}{lrrrrr}', r'\toprule',
         r'Method & Entry $T$ & $J_{10}$ & $I_{1,10}$ & $A_{10}$ & $\widehat{\mathrm{TV}}_{10}$ \\',
         r'\midrule']
for method in ['ordinary_cbf','recovery_cbf','progress_r0500','rate_025','rate_050','rate_100']:
    row = selected[method]
    t = float(row['entry_time'])
    entry = f'{t:.3f}' if math.isfinite(t) else r'$>600$'
    lines.append('{} & {} & {:.3f} & {:.2f} & {:.3f} & {:.2f} \\\\'.format(
        labels[method], entry, float(row['J10']), float(row['L1_intervention10']),
        float(row['accel_RMS10']), float(row['accel_TV10_grid'])))
lines += [r'\bottomrule', r'\end{tabular}']
(ROOT / 'tables/v6/selected_case.tex').write_text('\n'.join(lines) + '\n')
print('Copied V6 figures/tables; generated two compact paper tables from verified rows.')
