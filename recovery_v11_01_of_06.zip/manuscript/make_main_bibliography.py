"""Regenerate the main-only bibliography using conventional venue abbreviations.
Run after any shared references.bib change; the technical notes use that full file.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPLACEMENTS = {'IEEE Transactions on Automatic Control': 'IEEE Trans. Autom. Control', 'IEEE Transactions on Robotics': 'IEEE Trans. Robot.', 'IEEE Control Systems Letters': 'IEEE Control Syst. Lett.', 'The International Journal of Robotics Research': 'Int. J. Robot. Res.', 'International Journal of Robotics Research': 'Int. J. Robot. Res.', 'Stochastic Processes and their Applications': 'Stoch. Process. Appl.', 'Acta Numerica': 'Acta Numer.', 'Systems \\& Control: Foundations \\& Applications': 'Syst. Control: Found. Appl.', 'Systems & Control: Foundations & Applications': 'Syst. Control: Found. Appl.', 'University of British Columbia': 'Univ. British Columbia', '53rd IEEE Conference on Decision and Control': 'Proc. IEEE CDC', '2021 60th IEEE Conference on Decision and Control (CDC)': 'Proc. IEEE CDC', '2020 59th IEEE Conference on Decision and Control (CDC)': 'Proc. IEEE CDC', '2021 American Control Conference (ACC)': 'Proc. Amer. Control Conf. (ACC)', '2019 IEEE 58th Conference on Decision and Control (CDC)': 'Proc. IEEE CDC', '2022 IEEE 61st Conference on Decision and Control (CDC)': 'Proc. IEEE CDC', '2019 American Control Conference (ACC)': 'Proc. Amer. Control Conf. (ACC)', '2025 American Control Conference (ACC)': 'Proc. Amer. Control Conf. (ACC)', '2026 12th International Conference on Control, Automation and Robotics (ICCAR)': 'Proc. ICCAR'}

if __name__ == '__main__':
    text = (ROOT / 'references.bib').read_text()
    for full, short in REPLACEMENTS.items():
        text = text.replace(full, short)
    (ROOT / 'references_main.bib').write_text(
        '% Main-paper venue abbreviations; full metadata is in references.bib.\n' + text)
