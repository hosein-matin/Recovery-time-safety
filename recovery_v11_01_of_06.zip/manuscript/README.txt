CONFERENCE PAPER AND PUBLIC TECHNICAL NOTES
8 November 2026 -- conference revision 11; technical notes version 1.2

main.tex             Conference manuscript.
companion.tex        Complete public technical notes.
author_info.tex      Shared affiliation and funding.
repository_link.tex  Shared public repository URL and notes version/date.
references.bib       Full bibliography used by the technical notes.
references_main.bib  Generated conference bibliography with abbreviated venues.
make_main_bibliography.py  Regenerates it; called automatically by build.sh.
sections/            Active mathematical and numerical sections.
figures/, tables/    Prepared assets; no simulation required for compilation.

Build with bash build.sh (optional target main or companion), or select the
appropriate main document on Overleaf. The main paper uses standard 10-point
IEEE conference text and margins; the notes use an 11-point article format.

The complete package's root README describes numerical reproduction and the
distinction between analytic .01, offline uniform .025, and trajectory-certified
.05. The new .01/.025 experiments are separate from the preserved .05 study.
From that root, python3 reproduce.py --render-only builds both documents in an
isolated working copy. The source-only archive can use bash build.sh directly.

Repository: https://github.com/hosein-matin/Recovery-time-safety
The URL is included in both documents and the numbered technical-notes reference.
This prepared snapshot does not assert that a public upload has been completed.
