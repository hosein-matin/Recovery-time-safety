SHARED RECOVERY SEED: MATCHED PRODUCT / CBF COMPARISON
1 November 2026

This is a standalone numerical companion. It does not modify Revision 3.
The results were generated before the report and figure were written.
No controller parameters were tuned in this study.

READ FIRST
  report.txt                          Findings and limitations in plain text
  figures/shared_recovery_comparison.png
  metadata/protocol.json               Fixed protocol saved before simulations
  metadata/analysis_summary.json       Machine-readable findings

REPRODUCE
Requirements: Python 3.12, numpy, scipy, pandas, matplotlib, and a C++17 g++.
Exact versions and compiler are recorded in metadata/environment.json.
From this directory, run:

  python3 run_comparison.py
  python3 validate_comparison.py
  python3 analyze_comparison.py

The first command compiles kernel.cpp, rebuilds 24 moving-profile nominal
policies with two independent workers, reuses the six included stopped-leader
policy tables, and performs 12,504 integrations. In the supplied environment
the production command took about 69 seconds. The validation command compiles
a separate probe library; it does not replace the production library. Analysis
reads the completed CSV files and generates summaries, a PNG, and report.txt.
The engine.py file is a support module; it is not a second study entry point.

Files are written relative to these scripts, not an external workspace path.
The absolute source path in source_provenance.json is historical metadata and
is not needed to reproduce the study. Runtime-generated .so files can be
deleted; the commands compile them automatically. Moving nominal policy tables
are reconstructed deterministically and need not be distributed. The six
stopped-leader policy tables in policies/ must remain in place.

CONTROLLERS
  old_product:  product taper N=50 with lambda=0 backup
  gap_product:  same taper with task-aware backup
  standard_cbf: exact scalar projection of common nominal, gains (10,10,10)
  cbf_gap:      same feasible CBF interval, projection of shared recovery seed

For both augmented controllers:
  beta(v) = tanh(50*max(v,0)/M)
  u_rec = beta*k + (1-beta)*backup_lambda
  sigma = tanh(50*max(h,0))*tanh(50*max(M-v,0)/M)
  product = sigma*u_rec + (1-sigma)*backup_lambda

The task-aware backup has reference acceleration
  r = (w/2-v + lambda*rho(max(h-h_goal,0))*(M-v))/gamma,
  rho(x) = x/(.2+x),
  backup_lambda = clip((r-A)/B,[-U,U]).
The gap task uses lambda=2,h_goal=0; tracking uses lambda=.1,h_goal=.2.
All choices, objectives, model fixtures, and scenario definitions are recorded
in protocol.json and the source. The product headway normalization is 1; it
must not be confused with the backup's activation scale .2.

OBJECTIVES AND MODEL SCOPE
With zero terminal cost and APPLIED control u, the two objectives are:
  J_gap = integral_0^10 [.2*u(t)^2 + 50*d(t)^2] dt,
  J_tracking = integral_0^10 [.2*u(t)^2 + (v(t)-w(t))^2
                              + 5*(h(t)-.2)^2] dt.
The plant is d_dot=w-v, v_dot=alpha*(V(d)-v)+u, and
  h=d-gamma*v-.02, U=5, M=1.96.
C1 uses alpha=2.6,gamma=.2; C2 uses alpha=1,gamma=.3. Both use
  V(d)=tanh(d)-tanh(2),
which is negative for d<2. These are analytical feasibility fixtures, not
calibrated physical desired-speed models. C3 uses alpha=2.6,gamma=.35 and
the nonnegative law V(d)=clip(.8*(d-.1),0,1.5). All three are normalized
illustrative benchmarks, not calibrated vehicle tests. Their performance
numbers must be interpreted within that scope.

CBF RECORD FORMAT
Each controller has eight entries:
  [kind, p1, p2, p3, lambda, activation_scale, h_goal, reserved_N].
Kind 5 is CBF+gap. p1,p2,p3 are the headway, lower-speed and upper-speed gains;
reserved_N is the recovery-seed speed taper. Kinds 4 and 5 use exactly the
same feasible physical acceleration interval. Infeasibility is recorded as a
failure rather than silently repaired. The default model fixture has B=1;
the kernel retains general positive B expressions.

DATA MAP
  evaluation.csv:           750 cases/task x 2 tasks x 4 methods = 6,000
  half_step.csv:            the same 6,000, integration step .0025
  standstill.csv:           7 rest gaps x 3 fixtures x 2 tasks x 4 = 168
  standstill_half_step.csv: the same 168 at step .0025
  long_horizon.csv:         the same 168 integrated to T=60

Primary and long-horizon step is .005. Every trajectory in these CSVs is new.
Long-horizon nominal: same ten-unit HJB action table, continuously extended
by zero beyond T=10. This is not a 60-unit optimal control solution.

Six derived CSV summaries:
  main_summary.csv          Per-task mean cost, paired ratio, smoothness
  paired_comparisons.csv    Matched controller differences and win/tie counts
  paired_subgroups.csv      Strict stopped excess / intentional rest / remaining
  recovery_summary.csv      Strict excess, tolerance eligibility and arrivals
  refinement_summary.csv    Whole-case half-step changes and event agreement
  safety_summary.csv        Completion, margins, stages and applied input

Trace archives retain selected representatives and all four controllers.
They include a 'fields' array naming each column, 'methods', and scenario ID.
Evaluation traces use the inherited final near-headway anchor; standstill and
long traces use the common h0=.8,v0=0 start. All trace files are npz containers
readable with numpy.load. The kind-5 theta column stores beta, not the overall
product factor; do not interpret it as a full product taper.

EVENTS AND LIMITATIONS
first_v001 and first_v005 denote first reaching speed .001 and .05.
first_d_goal005 / first_d_goal001 denote physical distance satisfying
  d <= epsilon + h_goal + .05 / .01.
They are linearly interpolated between accepted integration steps. A negative
event time means the event was not reached in the finite horizon. A zero event
time means the initial state already satisfied it. Recovery summary denominators
exclude starts already inside each physical distance tolerance.

Strict excess is h0>h_goal, giving 18 gap and 12 tracking cases in the rest
panel. This differs from starts outside the .05 tolerance (15 and 9 cases).
The no-excess-gap goal does not enforce h>=h_goal or exact target convergence;
the long C3 tracking example illustrates undershoot. At/below-goal stationarity
describes starting at rest, not the behavior of an approaching vehicle.

J is the integral task cost with applied control. Cost ratios are per-case
ratios averaged arithmetically, not ratios of aggregate averages. All quantities
are normalized illustrative units. Jerk is a finite difference of physical
acceleration and depends on output/integration resolution. No comfort, energy,
global optimality, universal dominance, or sampled-data safety claim is implied.

No state projection, safety slack, or feasible-interval widening is used.
Safety classification uses tolerances documented in protocol.json. Actual
accepted and RK4 stage minima are retained. At step .005, two CBF methods have
very small negative internal-stage headway values; this is stated in report.txt.

PROVENANCE
  metadata/source_provenance.json      Original source and six policy file hashes
  metadata/environment.json            Production source hashes and run settings
  metadata/artifact_manifest.json      Current scripts, inputs and raw CSV hashes
  metadata/direct_checks.json          6,048 independent formula probe results
  metadata/policy_identity_checks.json All 30 action arrays match Revision 3 hashes
  metadata/<policy-id>.json             Policy construction / reused-table hashes

This package is intended for a fixed matched mechanism comparison. It does
not replace the theoretical proof, a literature novelty review, or hardware
validation. The parent manuscript should distinguish the common recovery
contribution from the choice of product blending versus CBF projection.
