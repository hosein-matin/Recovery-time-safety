#!/usr/bin/env python3
"""Full matched benchmark; no external solver/model is required.

python run_benchmark.py --all   (tuning, locked selection, evaluation, checks)
python run_benchmark.py --smoke (one model/profile, a few states)
"""
from __future__ import annotations
import argparse,csv,ctypes,hashlib,itertools,json,math,os,platform,subprocess,sys,time
from dataclasses import dataclass,asdict
from pathlib import Path
import numpy as np
import scipy
from scipy.interpolate import RegularGridInterpolator
from scipy.integrate import solve_ivp

ROOT=Path(__file__).resolve().parent
OLD=ROOT/'scenario_manifest.csv'
for name in ('data','metadata','figures','policies'):(ROOT/name).mkdir(exist_ok=True)
T=10.; DT=.005
PROFILES=['w1_sinusoidal','w2_slow','w3_braking','w4_restart','w5_stopped','design_constant03','design_constant12','design_shifted']
OBJECTIVES=['gap','tracking']
STATUS={0:'completed',1:'outside_policy_rectangle',2:'cbf_interval_infeasible',3:'nonfinite'}
@dataclass(frozen=True)
class Model:
    name:str; alpha:float; gamma:float; epsilon:float=.02; M:float=1.96; U:float=5.; law:int=0; drag:float=0.; rho:float=0.
    def array(self):return np.array([self.alpha,self.gamma,self.epsilon,self.M,self.U,self.law,self.drag,self.rho],dtype=float)
    def velocity(self,d):
        if self.law==0:return np.tanh(d)-np.tanh(2.)
        if self.law==1:return np.clip(.8*(np.asarray(d)-.1),0,1.5)
        return np.tanh(np.asarray(d)-2)+np.tanh(2)
    def ab(self,d,v):return self.alpha*(self.velocity(d)-v)-self.drag*v*abs(v)/(1+abs(v)),1+self.rho*np.tanh(d)**2
    def speed_box(self):
        lo,hi=((-1-np.tanh(2),1-np.tanh(2)) if self.law==0 else ((0.,1.5) if self.law==1 else (-1+np.tanh(2),1+np.tanh(2))))
        return min(0.,lo-(1+self.rho)*self.U/self.alpha),max(self.M,hi+(1+self.rho)*self.U/self.alpha)
MODELS=[Model('C1',2.6,.2),Model('C2',1.,.3),Model('C3',2.6,.35,law=1)]
LEVELS={'coarse':{'dd':.2,'nv':65,'dt':.1},'medium':{'dd':.1,'nv':129,'dt':.05},'fine':{'dd':.05,'nv':257,'dt':.025}}
METHODS=[{'name':'nominal','family':'nominal','pars':[0,0,0,0]}, {'name':'backup','family':'backup','pars':[1,0,0,0]}]
METHODS += [{'name':f'product_{n}','family':'product','pars':[2,n,0,0]} for n in [2,5,10,20,50]]
METHODS += [{'name':f'cutoff_{w:g}','family':'cutoff','pars':[3,w,0,0]} for w in [.02,.05,.1,.2,.4]]
METHODS += [{'name':f'cbf_{h}_{v}_{m}','family':'cbf','pars':[4,h,v,m]} for h,v,m in itertools.product([1,5,10],[5,10],[3,5,10])]
REFERENCE='cbf_5_5_5'

def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def leader(t,p):
    if isinstance(p,str):p=PROFILES.index(p)
    if p==0:return .8-.7*np.cos(t)
    if p==1:return .1+0*np.asarray(t)
    if p==2:return 1.5*(1-smooth((np.asarray(t)-2)/2))
    if p==3:return 1.5*(1-smooth((np.asarray(t)-2)/2))+1.5*smooth((np.asarray(t)-6)/2)
    if p==4:return 0*np.asarray(t)
    if p==5:return .3+0*np.asarray(t)
    if p==6:return 1.2+0*np.asarray(t)
    return .8-.7*np.cos(np.asarray(t)+.3)

def write_csv(path,rows):
    if not rows:return
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    tmp.replace(path)

def compile_kernel():
    binary=ROOT/'kernel.so'
    cmd=['g++','-O3','-std=c++17','-fPIC','-shared',str(ROOT/'kernel.cpp'),'-o',str(binary)]
    subprocess.run(cmd,check=True,capture_output=True,text=True)
    lib=ctypes.CDLL(str(binary));ad=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS');af=np.ctypeslib.ndpointer(dtype=np.float32,flags='C_CONTIGUOUS');ai=np.ctypeslib.ndpointer(dtype=np.int64,flags='C_CONTIGUOUS')
    lib.bellman_step.argtypes=[ad,ad,af,ctypes.c_int,ctypes.c_int]+[ctypes.c_double]*6+[ad,ctypes.c_int,ai]
    lib.bellman_step.restype=ctypes.c_int
    lib.simulate.argtypes=[af]+[ctypes.c_int]*3+[ctypes.c_double]*5+[ad,ctypes.c_int,ctypes.c_int,ad,ctypes.c_int,ad,ctypes.c_int]+[ctypes.c_double]*3+[ctypes.c_int]*2+[ad,ad]
    lib.simulate.restype=ctypes.c_int
    return lib,{'compile_command':cmd,'compiler':subprocess.run(['g++','--version'],capture_output=True,text=True).stdout.splitlines()[0]}

def solve_dp(lib,model,profile,objective,level='medium',box=None,save_policy=False):
    t0=time.perf_counter();cfg=LEVELS[level];dd,nv,pdt=cfg['dd'],cfg['nv'],cfg['dt'];vlo,vhi=model.speed_box()
    if box is None:
        p=PROFILES.index(profile);wlo,whi=[(.1,1.5),(.1,.1),(0,1.5),(0,1.5),(0,0),(.3,.3),(1.2,1.2),(.1,1.5)][p]
        # Every bilinear dependency can add at most one d-cell of padding per
        # step; this is additional to the full all-control drift envelope.
        pad=int(round(T/pdt))*dd+3*dd
        dlo=math.floor((-5+T*min(0,wlo-vhi)-pad)/dd)*dd
        dhi=math.ceil((25+T*max(0,whi-vlo)+pad)/dd)*dd
        box=(dlo,dhi)
    else:dlo,dhi=box
    ds=np.linspace(dlo,dhi,int(round((dhi-dlo)/dd))+1);vs=np.linspace(vlo,vhi,nv);dv=vs[1]-vs[0]
    ts=np.linspace(0,T,int(round(T/pdt))+1);take=(ds>=-5.00000001)&(ds<=25.00000001);ret=ds[take]
    actions=np.zeros((len(ts),len(ret),nv),dtype=np.float32);nxt=np.zeros((len(ds),nv));cur=np.empty_like(nxt);opt=np.empty(nxt.shape,dtype=np.float32)
    records=[];probes={};pd,pv=np.meshgrid(np.linspace(.02,3.,17),np.linspace(0,model.M,17),indexing='ij');points=np.column_stack([pd.ravel(),pv.ravel()]);probe_times=[0.,2.5,5.,7.5]
    for n in range(len(ts)-2,-1,-1):
        counts=np.zeros(3,dtype=np.int64)
        lib.bellman_step(nxt,cur,opt,len(ds),nv,dlo,vlo,dd,dv,pdt,float(leader(ts[n],profile)),model.array(),OBJECTIVES.index(objective),counts)
        if not np.isfinite(cur[take]).all():
            bad=np.argwhere(~np.isfinite(cur[take]));raise RuntimeError(f'Invalid retained Bellman dependency: {model.name} {profile} {objective} {level} t={ts[n]} first={bad[0].tolist()}')
        actions[n]=opt[take]
        records.append([float(ts[n]),*map(int,counts)])
        if any(abs(ts[n]-q)<1e-9 for q in probe_times):probes[str(round(float(ts[n]),6))]=RegularGridInterpolator((ret,vs),cur[take],bounds_error=True)(points).tolist()
        nxt,cur=cur,nxt
    ident=f'{model.name}__{profile}__{objective}__{level}'
    pol={'u':actions,'t':ts,'d':ret,'v':vs,'dt':pdt,'dd':dd,'dv':dv,'level':level,'id':ident,'model':model,'profile':profile,'objective':objective}
    meta={'id':ident,'model':asdict(model),'profile':profile,'objective':objective,'level':level,'configuration':cfg,'full_box':[dlo,dhi,vlo,vhi],'full_shape':[len(ts),len(ds),nv],'policy_shape':list(actions.shape),'policy_gap_rectangle':[float(ret[0]),float(ret[-1])],'invalid_mask_rule':'reject any action with out-of-box characteristic or any nonfinite interpolation node; propagate all-action invalidity','counts_columns':['t','invalid_direct','invalid_dependency','machine_epsilon_endpoint_snap'],'validity_counts':records,'elapsed_seconds':time.perf_counter()-t0,'policy_sha256':hashlib.sha256(actions.tobytes()).hexdigest(),'policy_storage':'float32 exact discrete minimizer at nodes, double computations; multilinear bounded reconstruction','probe_grid':{'d':pd[:,0].tolist(),'v':pv[0].tolist(),'times':probe_times},'value_probes':probes}
    (ROOT/'metadata'/f'{ident}.json').write_text(json.dumps(meta,indent=2))
    if save_policy:np.savez_compressed(ROOT/'policies'/f'{ident}.npz',u=actions,t=ts,d=ret,v=vs)
    print(f'DP {ident} {meta["full_shape"]}: {meta["elapsed_seconds"]:.2f}s',flush=True)
    return pol,meta

def scenarios(model,profile,split):
    rows=list(csv.DictReader(OLD.open()))
    return [r for r in rows if r['fixture']==model.name and r['leader_profile']==profile and r['split']==split]

def simulate(lib,pol,states,methods=METHODS,dt=DT,sample_period=0.,trace_index=-1,trace_stride=10,tag='primary',save_trace=True):
    if any(len(method['pars'])!=8 for method in methods):
        raise ValueError('This study requires eight-entry controller records; use run_comparison.py methods.')
    model,profile,obj=pol['model'],pol['profile'],pol['objective'];ni,nm=len(states),len(methods);raw=np.zeros((ni,nm,37));initials=np.array([[float(s['h0']),float(s['v0'])] for s in states]);pars=np.array([m['pars'] for m in methods],dtype=float)
    ntout=int(round(T/dt))//trace_stride+1 if trace_index>=0 else 1
    traces=np.full((nm,ntout,13),np.nan);start=time.perf_counter()
    lib.simulate(pol['u'],*pol['u'].shape,pol['dt'],float(pol['d'][0]),pol['dd'],float(pol['v'][0]),pol['dv'],model.array(),PROFILES.index(profile),OBJECTIVES.index(obj),initials,ni,pars,nm,dt,T,sample_period,trace_index,trace_stride if trace_index>=0 else 0,raw,traces)
    elapsed=time.perf_counter()-start;rows=[]
    for i,state in enumerate(states):
        for j,method in enumerate(methods):
            q=raw[i,j];status=int(q[0]);bad=min(q[14],q[15]/model.M,q[16]/model.M)<-1e-7 or q[17]>1e-8
            safety='violation' if bad else ('incomplete' if status else ('boundary_or_numerically_unresolved' if min(q[14],q[15]/model.M,q[16]/model.M)<=1e-7 else 'positive_margin'))
            rows.append({'scenario_id':state['scenario_id'],'split':state['split'],'fixture':model.name,'profile':profile,'objective':obj,'method':method['name'],'family':method['family'],'policy_level':pol['level'],'dt':dt,'sample_period':sample_period,'tag':tag,'h0':float(state['h0']),'v0':float(state['v0']),'status':STATUS[status],'failure_time':q[1],'safety_status':safety,'J':q[2] if not status else float('nan'),'partial_J':q[2],'J_u':q[3],'J_state':q[4],'speed_RMSE':math.sqrt(max(0,q[5])/T) if not status else float('nan'),'headway_RMSE':math.sqrt(max(0,q[6])/T) if not status else float('nan'),'acceleration_RMS':math.sqrt(max(0,q[7])/T) if not status else float('nan'),'L1_intervention':q[8],'L2_intervention_squared':q[9],'control_TV':q[10],'jerk_RMS_fd':math.sqrt(max(0,q[11])/T) if not status else float('nan'),'acceleration_peak_abs':q[12],'jerk_peak_abs_fd':q[13],'min_h':q[14],'min_v':q[15],'min_upper_margin':q[16],'max_input_excess':q[17],'intervention_fraction':q[18],'saturation_fraction':q[19],'terminal_h':q[20],'terminal_v':q[21],'terminal_d':q[22],'min_stage_h':q[23],'min_stage_v':q[24],'min_stage_upper_margin':q[25],'first_detected_violation':q[26],'first_v001':q[28],'first_v005':q[29],'peak_v':q[30],'stopped_excess_lock_time':q[31],'distance_travelled':q[32],'post_restart_v005':q[33],'terminal_acceleration':q[34],'first_d_goal005':q[35],'first_d_goal001':q[36]})
    if trace_index>=0 and save_trace:
        ident=f'{pol["id"]}__{tag}__dt{dt:g}'
        np.savez_compressed(ROOT/'data'/f'trace__{ident}.npz',trace=traces,methods=np.array([m['name'] for m in methods]),fields=np.array(['t','h','v','d','w','u_nom','u','acceleration','J_cumulative','J_u_cumulative','L1_intervention_cumulative','acceleration_squared_integral','theta']),scenario_id=states[trace_index]['scenario_id'])
    print(f'SIM {pol["id"]} {tag}: {ni*nm} trajectories dt={dt:g} in {elapsed:.2f}s; failures={sum(r["status"]!="completed" for r in rows)} violations={sum(r["safety_status"]=="violation" for r in rows)}',flush=True)
    return rows

def freeze_selection(tuning):
    choices={};scores=[]
    for obj in OBJECTIVES:
        rr=[r for r in tuning if r['objective']==obj];refs={r['scenario_id']:r for r in rr if r['method']==REFERENCE}
        assert len(refs)==144 and all(r['status']=='completed' and r['safety_status']!='violation' for r in refs.values()),'Reference CBF failed tuning'
        choices[obj]={}
        for family in ['product','cutoff','cbf']:
            candidates=[]
            for method in [m for m in METHODS if m['family']==family]:
                x=[r for r in rr if r['method']==method['name']]
                failed=sum(r['status']!='completed' or r['safety_status']=='violation' for r in x)
                ratios=[r['J']/max(refs[r['scenario_id']]['J'],1e-12) for r in x] if not failed else []
                score=float(np.mean(ratios)) if ratios else float('inf')
                row={'objective':obj,'family':family,'method':method['name'],'n':len(x),'failed_or_violating':failed,'mean_cost_ratio_to_fixed_cbf':score}
                scores.append(row);candidates.append((failed,score,method['name']))
            winner=min(candidates);choices[obj][family]=winner[2]
    payload={'rule':'Safety and feasibility on all 144 held-out tuning cases first; then minimize equal-case mean J/J_fixed_CBF, separately for each objective; deterministic name tie break. Same chosen configuration for all three fixtures and all evaluation scenarios. Comfort metrics never used in selection.','reference':REFERENCE,'selected':choices,'tuning_scenarios_sha256':hashlib.sha256('\n'.join(sorted({r['scenario_id'] for r in tuning})).encode()).hexdigest(),'locked_before_evaluation':True,'scores':scores}
    (ROOT/'metadata/selected_configs.json').write_text(json.dumps(payload,indent=2));write_csv(ROOT/'data/tuning_scores.csv',scores)
    return choices

def probe_policy(pol,times=[0.,2.5,5.,7.5]):
    model=pol['model'];dd,vv=np.meshgrid(np.linspace(.02,3,17),np.linspace(0,model.M,17),indexing='ij')
    pts=np.array([[t,d,v] for t in times for d,v in zip(dd.ravel(),vv.ravel())])
    return RegularGridInterpolator((pol['t'],pol['d'],pol['v']),pol['u'],bounds_error=True)(pts)

def refinement(lib,pol,base_rows,states,choices,base_meta):
    obj=pol['objective'];names=['nominal','backup',REFERENCE]+[choices[obj][f] for f in ['product','cutoff','cbf']]
    names=list(dict.fromkeys(names));methods=[m for m in METHODS if m['name'] in names]
    refout=[];allrows=[];previous=None;previous_meta=None;previous_rows=None
    levels={}
    for level in ['coarse','medium','fine']:
        if level=='medium':p,meta=pol,base_meta;rr=[r for r in base_rows if r['method'] in names]
        else:p,meta=solve_dp(lib,pol['model'],pol['profile'],obj,level);rr=simulate(lib,p,states,methods,tag='hjb_refinement',trace_index=len(states)-1)
        levels[level]=(p,meta,rr);allrows.extend(rr)
        if previous is not None:
            values=np.array([meta['value_probes'][str(t)] for t in [0.,2.5,5.,7.5]])-np.array([previous_meta['value_probes'][str(t)] for t in [0.,2.5,5.,7.5]])
            acts=probe_policy(p)-probe_policy(previous)
            mapping={(r['scenario_id'],r['method']):r for r in previous_rows};cd=[]
            for r in rr:
                old=mapping[(r['scenario_id'],r['method'])]
                if np.isfinite(r['J']) and np.isfinite(old['J']):cd.append(abs(r['J']-old['J']))
            refout.append({'fixture':pol['model'].name,'profile':pol['profile'],'objective':obj,'coarser':previous['level'],'finer':level,'max_value_difference_common_probe':float(np.max(np.abs(values))),'max_action_difference_common_probe':float(np.max(np.abs(acts))),'rms_action_difference_common_probe':float(np.sqrt(np.mean(acts**2))),'max_abs_cost_difference':max(cd) if cd else float('nan'),'median_abs_cost_difference':float(np.median(cd)) if cd else float('nan'),'n_paired_costs':len(cd)})
        previous,previous_meta,previous_rows=p,meta,rr
    return refout,allrows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--all',action='store_true');ap.add_argument('--smoke',action='store_true');ap.add_argument('--resume',action='store_true');args=ap.parse_args()
    start=time.perf_counter();lib,compiler=compile_kernel()
    manifest={'T':T,'main_ode_dt':DT,'models':[asdict(m) for m in MODELS],'objectives':{'gap':'.2*u_applied^2+50*d^2','tracking':'(v-w(t))^2+5*(h-.2)^2+.2*u_applied^2'},'terminal_cost':0,'profiles':dict(zip(PROFILES,['.8-.7*cos(t)', '.1','1.5*(1-S((t-2)/2))','1.5*(1-S((t-2)/2))+1.5*S((t-6)/2)','0','.3','1.2','.8-.7*cos(t+.3)'])),'smoothstep':'S(r)=0 for r<=0, 3r²-2r³ on[0,1],1 forr>=1','methods':METHODS,'reference_cbf':REFERENCE,'levels':LEVELS,'units':'nondimensional illustrative parameters; no calibrated energy model','jerk_definition':'RMS and peak of (a(t_n)-a(t_(n-1)))/dt on common step grid; no analytic jerk or calibrated comfort interpretation','safety_classification':'numerical grid/stage estimates; h tolerance1e-7 and speed tolerance1.96e-7; no state projection or silent interval widening','policy_reconstruction':'float32 action-table values; double multilinear interpolation in space and time, including a zero terminal action; globally bounded regular extension exists but every queried state must stay inside retained rectangle','counts_planned':{'tuning_per_objective':144*len(METHODS),'evaluation_per_objective':750*len(METHODS)},'selection_rule':'equal-weight per-case cost ratio to fixed CBF(5,5,5); safety/feasibility first; selected before evaluation; no comfort tuning'}
    (ROOT/'metadata/manifest.json').write_text(json.dumps(manifest,indent=2))
    if args.smoke:
        p,meta=solve_dp(lib,MODELS[2],PROFILES[2],'tracking','medium')
        states=scenarios(MODELS[2],PROFILES[2],'evaluation')[:3]+scenarios(MODELS[2],PROFILES[2],'evaluation')[-1:]
        rr=simulate(lib,p,states,trace_index=len(states)-1,tag='smoke');write_csv(ROOT/'data/smoke.csv',rr);return
    tuning=[]
    tuning_file=ROOT/'data/tuning.csv'
    if args.resume and tuning_file.exists():
        tuning=list(csv.DictReader(tuning_file.open()))
        for r in tuning:
            for k in ['J','partial_J']:r[k]=float(r[k])
    else:
        for obj in OBJECTIVES:
            for model in MODELS:
                for profile in PROFILES[5:]:
                    pol,meta=solve_dp(lib,model,profile,obj)
                    rr=simulate(lib,pol,scenarios(model,profile,'tuning'),tag='tuning')
                    tuning.extend(rr);write_csv(tuning_file,tuning)
    choices=freeze_selection(tuning);print('LOCKED SELECTION '+json.dumps(choices),flush=True)
    evaluation=[];ode_rows=[];refrows=[];refsummary=[];sample_rows=[]
    for obj in OBJECTIVES:
        for model in MODELS:
            for profile in PROFILES[:5]:
                pol,meta=solve_dp(lib,model,profile,obj)
                states=scenarios(model,profile,'evaluation')
                rr=simulate(lib,pol,states,trace_index=len(states)-1)
                evaluation.extend(rr);write_csv(ROOT/'data/evaluation.csv',evaluation)
                names=list(dict.fromkeys([REFERENCE]+[choices[obj][f] for f in ['product','cutoff','cbf']]))
                selected=[m for m in METHODS if m['name'] in names]
                # Full-case ODE step refinement of deployed comparison methods.
                tight=simulate(lib,pol,states,selected,dt=DT/2,tag='ode_refinement',trace_index=len(states)-1)
                ode_rows.extend(tight);write_csv(ROOT/'data/ode_refinement.csv',ode_rows)
                if profile==PROFILES[2]:
                    rs,ar=refinement(lib,pol,rr,states,choices,meta);refsummary.extend(rs);refrows.extend(ar)
                    write_csv(ROOT/'data/hjb_refinement.csv',refrows);write_csv(ROOT/'data/refinement_summary.csv',refsummary)
                if profile in [PROFILES[2],PROFILES[3]] and obj=='tracking':
                    for hold in [.01,.05,.1,.2]:
                        sr=simulate(lib,pol,states,selected,dt=.0025,sample_period=hold,tag=f'held_{hold:g}',trace_index=-1)
                        sample_rows.extend(sr)
                    write_csv(ROOT/'data/sample_hold.csv',sample_rows)
    env={'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'compiler':compiler,'wall_seconds':time.perf_counter()-start,'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'run_benchmark.py',ROOT/'kernel.cpp']},'counts':{'tuning':len(tuning),'evaluation':len(evaluation),'ode_refinement':len(ode_rows),'hjb_refinement_rows_including_reused_medium':len(refrows),'sample_hold':len(sample_rows)}}
    (ROOT/'metadata/environment.json').write_text(json.dumps(env,indent=2))
    print('BENCHMARK COMPLETE '+json.dumps(env['counts'])+f' wall={env["wall_seconds"]:.1f}s',flush=True)

if __name__=='__main__':
    raise SystemExit('engine.py is a support module. Run: python3 run_comparison.py')
