#include "kernel.cpp"
extern "C" int eval_probe(const double* m,int profile,const double* method,double nominal,double t,double h,double v,double* out){float tab[8];for(int i=0;i<8;i++)tab[i]=(float)nominal;Policy p{tab,2,2,2,100,-10,110,-1,4};Eval e=control(p,m,profile,method,t,h,v,false,0);out[0]=e.dh;out[1]=e.dv;out[2]=e.u;return e.status;}
