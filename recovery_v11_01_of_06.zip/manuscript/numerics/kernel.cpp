// Reproducible normalized car-following benchmark. All computations double
// except stored action tables (float32); interpolated actions remain bounded.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>

namespace {
constexpr int NS=37, NF=13;
inline double clip(double x,double lo,double hi){return std::min(hi,std::max(lo,x));}
inline double smooth(double x){x=clip(x,0,1);return x*x*(3-2*x);}
inline double leader(double t,int p){
 if(p==0)return .8-.7*std::cos(t);
 if(p==1)return .1;
 if(p==2)return 1.5*(1-smooth((t-2)/2));
 if(p==3)return 1.5*(1-smooth((t-2)/2))+1.5*smooth((t-6)/2);
 if(p==4)return 0;
 if(p==5)return .3;
 if(p==6)return 1.2;
 if(p==7)return .8-.7*std::cos(t+.3);
 return 0;
}
inline double velocity(double d,int law){
 if(law==0)return std::tanh(d)-std::tanh(2.);
 if(law==1)return clip(.8*(d-.1),0.,1.5);
 return std::tanh(d-2.)+std::tanh(2.);
}
inline void drift(const double* m,double d,double v,double& a,double& b){
 a=m[0]*(velocity(d,(int)m[5])-v);
 if(m[6]!=0)a-=m[6]*v*std::abs(v)/(1+std::abs(v));
 b=1;if(m[7]!=0)b+=m[7]*std::pow(std::tanh(d),2);
}
inline double state_cost(int objective,const double* m,double w,double d,double v){
 if(objective==0)return 50*d*d;
 const double h=d-m[1]*v-m[2];
 return (v-w)*(v-w)+5*(h-.2)*(h-.2);
}
struct Policy {
 const float* tab; int nt,nd,nv; double dt,dlo,dd,vlo,dv;
 bool query(double t,double d,double v,double& u)const{
  const double dhi=dlo+(nd-1)*dd, vhi=vlo+(nv-1)*dv;
  const double ed=64*std::numeric_limits<double>::epsilon()*(1+std::max(std::abs(dlo),std::abs(dhi)));
  const double ev=64*std::numeric_limits<double>::epsilon()*(1+std::max(std::abs(vlo),std::abs(vhi)));
  if(d<dlo-ed || d>dhi+ed || v<vlo-ev || v>vhi+ev || !std::isfinite(d+v))return false;
  double ti=clip(t/dt,0.,nt-1.);int kt=std::min(nt-2,(int)std::floor(ti));double ft=ti-kt;
  // Clamp only a roundoff-scale interpolation index; the simulated state is
  // untouched. True queries outside the declared rectangle still fail.
  double di=clip((d-dlo)/dd,0.,nd-1.);int kd=std::min(nd-2,std::max(0,(int)std::floor(di)));double fd=di-kd;
  double vi=clip((v-vlo)/dv,0.,nv-1.);int kv=std::min(nv-2,std::max(0,(int)std::floor(vi)));double fv=vi-kv;
  auto val=[&](int k){const long long off=((long long)k*nd+kd)*nv+kv;
   double x0=tab[off]*(1-fv)+tab[off+1]*fv;
   double x1=tab[off+nv]*(1-fv)+tab[off+nv+1]*fv;
   return x0*(1-fd)+x1*fd;};
  u=val(kt)*(1-ft)+val(kt+1)*ft;return std::isfinite(u);
 }
};
struct Eval {double dh,dv,u,un,a,w,d,theta;int status;};
Eval control(const Policy& pol,const double* m,int p,const double* method,double t,double h,double v,bool held,double held_u){
 Eval e{};e.status=0;e.d=h+m[1]*v+m[2];e.w=leader(t,p);e.theta=1;
 if(!pol.query(t,e.d,v,e.un)){e.status=1;return e;}
 double A,B;drift(m,e.d,v,A,B);const double U=m[4],M=m[3],gamma=m[1];
 if(held)e.u=held_u;
 else {
  int kind=(int)method[0];
  if(kind==0)e.u=e.un;
  else if(kind==4 || kind==5){
   // Work in acceleration coordinates and use long double at corners.
   const long double aa=A,bb=B,hh=h,vv=v,ww=e.w;
   const long double speed_lo=-(long double)method[2]*vv;
   const long double head_hi=(ww-vv+(long double)method[1]*hh)/(long double)gamma;
   long double lo=std::max(aa-bb*U,speed_lo);
   long double hi=std::min({aa+bb*U,head_hi,(long double)method[3]*((long double)M-vv)});
   if(lo>hi){e.status=2;return e;}
   long double desired=aa+bb*(long double)e.un;
   if(kind==5){
    // Shared low-speed recovery seed; identical beta factor to product filter.
    double excess=std::max(h-method[6],0.);
    double rho=excess/(method[5]+excess);
    double r=(e.w/2-v+method[4]*rho*(M-v))/gamma;
    double q=(r-A)/B,ub=clip(q,-U,U);
    double ab=(q>=-U&&q<=U)?r:A+B*ub;
    double beta=std::tanh(method[7]*std::max(v,0.)/M);
    desired=(long double)beta*(aa+bb*(long double)e.un)+(1-(long double)beta)*(long double)ab;
    e.theta=beta;
   }
   long double ac=std::min(hi,std::max(lo,desired));
   e.u=(double)((ac-aa)/bb);
   // For the unit gain base fixtures use the projected acceleration itself
   // below; this avoids an extra cancellation at an exact zero-speed corner.
   e.a=(double)ac;e.dv=e.a;
   // Algebraically identical active-face formulas avoid artificial drift of
   // exactly invariant faces; no state or interval endpoint is projected.
   if(ac==head_hi)e.dh=-method[1]*h;
   else if(ac==speed_lo)e.dh=e.w+(gamma*method[2]-1)*v;
   else e.dh=e.w-v-gamma*e.a;
   return e;
  } else {
   double excess=std::max(h-method[6],0.);
   double activation=excess/(method[5]+excess);
   double boost=method[4]*activation*(M-v);
   double r=(e.w/2-v+boost)/gamma,q=(r-A)/B,ub=clip(q,-U,U);
   double ab=(q>=-U&&q<=U)?r:A+B*ub;
   double hb=(q>=-U&&q<=U)?e.w/2-boost:e.w-v-gamma*ab;
   if(kind==1){e.u=ub;e.theta=0;e.a=ab;e.dv=ab;e.dh=hb;return e;}
   else {
    double x=std::max(h,0.),y=std::max(v/M,0.),z=std::max((M-v)/M,0.);
    if(kind==2)e.theta=std::tanh(method[1]*x)*std::tanh(method[1]*y)*std::tanh(method[1]*z);
    else e.theta=smooth(std::min({x,y,z})/method[1]);
    e.u=e.theta*e.un+(1-e.theta)*ub;
    double an=A+B*e.un;
    e.a=e.theta*an+(1-e.theta)*ab;e.dv=e.a;
    e.dh=e.theta*(e.w-v-gamma*an)+(1-e.theta)*hb;
    return e;
   }
  }
 }
 e.a=A+B*e.u;e.dv=e.a;e.dh=e.w-v-gamma*e.a;
 if(!std::isfinite(e.dh+e.dv+e.u))e.status=3;
 return e;
}
void rates(const Eval& e,const double* m,int obj,double h,double v,double* f){
 f[0]=.2*e.u*e.u+state_cost(obj,m,e.w,e.d,v);
 f[1]=.2*e.u*e.u;f[2]=state_cost(obj,m,e.w,e.d,v);
 f[3]=(v-e.w)*(v-e.w);f[4]=(h-.2)*(h-.2);f[5]=e.a*e.a;
 f[6]=std::abs(e.u-e.un);f[7]=(e.u-e.un)*(e.u-e.un);
}
}

extern "C" int bellman_step(const double* wn,double* wc,float* uc,int nd,int nv,
 double dlo,double vlo,double dd,double dv,double dt,double w,const double* m,int objective,long long* counts){
 const double nan=std::numeric_limits<double>::quiet_NaN(),dhi=dlo+(nd-1)*dd,vhi=vlo+(nv-1)*dv,U=m[4];
 long long rejected=0,contaminated=0,snaps=0;
 for(int i=0;i<nd;i++){
  const double d=dlo+i*dd,V=velocity(d,(int)m[5]);
  const double B=m[7]==0?1:1+m[7]*std::pow(std::tanh(d),2);
  for(int j=0;j<nv;j++){
  const int ix=i*nv+j;wc[ix]=nan;uc[ix]=std::numeric_limits<float>::quiet_NaN();
  double v=vlo+j*dv,A=m[0]*(V-v);
  if(m[6]!=0)A-=m[6]*v*std::abs(v)/(1+std::abs(v));
  const double running=state_cost(objective,m,w,d,v);
  double dn=d+dt*(w-v);if(dn<dlo||dn>dhi){rejected++;continue;}
  double ri=(dn-dlo)/dd;int id=std::min(nd-2,std::max(0,(int)std::floor(ri)));double fd=ri-id;
  double vb=v+dt*A,vl=vb-dt*B*U,vh=vb+dt*B*U;
  double eps=64*std::numeric_limits<double>::epsilon()*(1+std::max(std::abs(vlo),std::abs(vhi)));
  if(vl<vlo-eps||vh>vhi+eps){rejected++;continue;}
  if(vl<vlo){vl=vlo;snaps++;}if(vh>vhi){vh=vhi;snaps++;}
  int jl=std::min(nv-2,std::max(0,(int)std::floor((vl-vlo)/dv)));
  int jh=std::min(nv-2,std::max(0,(int)std::floor((vh-vlo)/dv)));
  double best=std::numeric_limits<double>::infinity(),bestu=0;bool bad=false;
  for(int k=jl;k<=jh;k++){
   double vg=vlo+k*dv,ul=std::max(-U,(vg-vb)/(dt*B)),ur=std::min(U,(vg+dv-vb)/(dt*B));
   if(ul>ur)continue;
   double a=wn[id*nv+k],b=wn[id*nv+k+1],c=wn[(id+1)*nv+k],e=wn[(id+1)*nv+k+1];
   if(!(std::isfinite(a)&&std::isfinite(b)&&std::isfinite(c)&&std::isfinite(e))){bad=true;break;}
   double f0=a+fd*(c-a),f1=b+fd*(e-b),slope=(f1-f0)/dv;
   double u=clip(-B*slope/.4,ul,ur);
   double val=dt*(.2*u*u+running)+f0+slope*(vb+dt*B*u-vg);
   if(val<best){best=val;bestu=u;}
  }
  if(bad||!std::isfinite(best)){contaminated++;continue;}
  wc[ix]=best;uc[ix]=(float)bestu;
 }}
 counts[0]=rejected;counts[1]=contaminated;counts[2]=snaps;return 0;
}

extern "C" int simulate(const float* tab,int nt,int nd,int nv,double pdt,double dlo,double dd,double vlo,double dv,
 const double* m,int profile,int objective,const double* initials,int ni,const double* methods,int nm,
 double dt,double T,double sample_period,int trace_initial,int trace_stride,double* out,double* traces){
 Policy pol{tab,nt,nd,nv,pdt,dlo,dd,vlo,dv};
 int steps=(int)std::llround(T/dt),ntrace=trace_stride>0?steps/trace_stride+1:0;
 int holdsteps=sample_period>0?std::max(1,(int)std::llround(sample_period/dt)):0;
 for(int ii=0;ii<ni;ii++)for(int mm=0;mm<nm;mm++){
  double h=initials[2*ii],v=initials[2*ii+1],integ[8]={};
  double min_h=h,min_v=v,min_up=m[3]-v,max_input_excess=0,max_a=0,max_jerk=0,TV=0,Jerk=0;
  double intervention=0,saturation=0,min_stage_h=h,min_stage_v=v,min_stage_up=m[3]-v;
  double first_small=v>=.001?0:-1,first_speed=v>=.05?0:-1,peak_speed=v,lock_time=0,distance=0,post_restart=-1;
  const double goal=objective==1?.2:0.;
  const double dstart=h+m[1]*v+m[2];
  double entry005=dstart<=m[2]+goal+.05?0:-1;
  double entry001=dstart<=m[2]+goal+.01?0:-1;
  double held_u=0,prev_u=0,prev_a=0,first_violation=-1,failed_t=-1;int status=0;
  const double* method=methods+8*mm;
  auto check=[&](const Eval& e,double hh,double vv){
   min_stage_h=std::min(min_stage_h,hh);min_stage_v=std::min(min_stage_v,vv);min_stage_up=std::min(min_stage_up,m[3]-vv);
   max_input_excess=std::max(max_input_excess,std::abs(e.u)-m[4]);
  };
  auto trace=[&](int st,const Eval& e){
   if(ii!=trace_initial||trace_stride<=0||st%trace_stride)return;
   double* r=traces+((long long)mm*ntrace+st/trace_stride)*NF;
   r[0]=st*dt;r[1]=h;r[2]=v;r[3]=e.d;r[4]=e.w;r[5]=e.un;r[6]=e.u;r[7]=e.a;
   r[8]=integ[0];r[9]=integ[1];r[10]=integ[6];r[11]=integ[5];r[12]=e.theta;
  };
  for(int st=0;st<steps;st++){
   double t=st*dt;
   if(holdsteps&&st%holdsteps==0){Eval q=control(pol,m,profile,method,t,h,v,false,0);if(q.status){status=q.status;failed_t=t;break;}held_u=q.u;}
   Eval e1=control(pol,m,profile,method,t,h,v,holdsteps,held_u);
   if(e1.status){status=e1.status;failed_t=t;break;}
   if(st==0){prev_u=e1.u;prev_a=e1.a;}
   else {double jerk=(e1.a-prev_a)/dt;Jerk+=jerk*jerk*dt;max_jerk=std::max(max_jerk,std::abs(jerk));TV+=std::abs(e1.u-prev_u);prev_u=e1.u;prev_a=e1.a;}
   max_a=std::max(max_a,std::abs(e1.a));
   if(e1.w<=1e-10 && v<.001 && h>goal+.05)lock_time+=dt;
   if(t>=6 && v>=.05 && post_restart<0)post_restart=t-6;
   intervention+=(std::abs(e1.u-e1.un)>1e-3*m[4])*dt;saturation+=(std::abs(e1.u)>=m[4]-1e-8)*dt;
   trace(st,e1);check(e1,h,v);
   double h2=h+dt*e1.dh/2,v2=v+dt*e1.dv/2;
   Eval e2=control(pol,m,profile,method,t+dt/2,h2,v2,holdsteps,held_u);if(e2.status){status=e2.status;failed_t=t+dt/2;break;}check(e2,h2,v2);
   double h3=h+dt*e2.dh/2,v3=v+dt*e2.dv/2;
   Eval e3=control(pol,m,profile,method,t+dt/2,h3,v3,holdsteps,held_u);if(e3.status){status=e3.status;failed_t=t+dt/2;break;}check(e3,h3,v3);
   double h4=h+dt*e3.dh,v4=v+dt*e3.dv;
   Eval e4=control(pol,m,profile,method,t+dt,h4,v4,holdsteps,held_u);if(e4.status){status=e4.status;failed_t=t+dt;break;}check(e4,h4,v4);
   double f1[8],f2[8],f3[8],f4[8];rates(e1,m,objective,h,v,f1);rates(e2,m,objective,h2,v2,f2);rates(e3,m,objective,h3,v3,f3);rates(e4,m,objective,h4,v4,f4);
   for(int k=0;k<8;k++)integ[k]+=dt*(f1[k]+2*f2[k]+2*f3[k]+f4[k])/6;
   double old_v=v,old_d=h+m[1]*v+m[2];
   distance+=dt*(v+2*v2+2*v3+v4)/6;
   h+=dt*(e1.dh+2*e2.dh+2*e3.dh+e4.dh)/6;v+=dt*(e1.dv+2*e2.dv+2*e3.dv+e4.dv)/6;
   peak_speed=std::max(peak_speed,v);
   double new_d=h+m[1]*v+m[2];
   if(entry005<0 && new_d<=m[2]+goal+.05)entry005=t+dt*(old_d-m[2]-goal-.05)/(old_d-new_d);
   if(entry001<0 && new_d<=m[2]+goal+.01)entry001=t+dt*(old_d-m[2]-goal-.01)/(old_d-new_d);
   if(first_small<0 && v>=.001)first_small=t+dt*(.001-old_v)/(v-old_v);
   if(first_speed<0 && v>=.05)first_speed=t+dt*(.05-old_v)/(v-old_v);
   min_h=std::min(min_h,h);min_v=std::min(min_v,v);min_up=std::min(min_up,m[3]-v);
   if(first_violation<0&&(h< -1e-7 || v< -1.96e-7 || v>m[3]+1.96e-7))first_violation=t+dt;
  }
  Eval end{};if(!status){end=control(pol,m,profile,method,T,h,v,holdsteps,held_u);status=end.status;if(status)failed_t=T;}
  if(!status){double jerk=(end.a-prev_a)/dt;Jerk+=jerk*jerk*dt;max_jerk=std::max(max_jerk,std::abs(jerk));TV+=std::abs(end.u-prev_u);max_a=std::max(max_a,std::abs(end.a));trace(steps,end);}
  double* r=out+((long long)ii*nm+mm)*NS;
  r[0]=status;r[1]=failed_t;
  for(int k=0;k<8;k++)r[2+k]=integ[k];
  r[10]=TV;r[11]=Jerk;r[12]=max_a;r[13]=max_jerk;r[14]=min_h;r[15]=min_v;r[16]=min_up;r[17]=std::max(0.,max_input_excess);
  r[18]=intervention/T;r[19]=saturation/T;r[20]=h;r[21]=v;r[22]=h+m[1]*v+m[2];r[23]=min_stage_h;r[24]=min_stage_v;r[25]=min_stage_up;r[26]=first_violation;r[27]=T;
  r[28]=first_small;r[29]=first_speed;r[30]=peak_speed;r[31]=lock_time;r[32]=distance;r[33]=post_restart;r[34]=end.a;r[35]=entry005;r[36]=entry001;
 }
 return 0;
}
