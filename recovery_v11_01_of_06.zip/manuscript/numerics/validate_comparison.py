#!/usr/bin/env python3
"""Independent physical-formula and exact shared-seed factorization checks."""
from pathlib import Path
import ctypes,json,subprocess
import numpy as np
import engine as E
import run_comparison as S
R=Path(__file__).resolve().parent

def direct(model,method,t,h,v,profile,nominal):
 d=h+model.gamma*v+model.epsilon;w=float(E.leader(t,profile));a,b=model.ab(d,v);U=model.U;M=model.M;gamma=model.gamma
 kind,p1,p2,p3,lam,scale,goal,N=method['pars'];ex=max(h-goal,0.);rho=ex/(scale+ex)
 ref=(w/2-v+lam*rho*(M-v))/gamma;ub=float(np.clip((ref-a)/b,-U,U))
 beta=float(np.tanh(50*max(v,0.)/M));sigma=float(np.tanh(50*max(h,0.))*np.tanh(50*max(M-v,0.)/M));seed=beta*nominal+(1-beta)*ub
 if kind==2:u=beta*sigma*nominal+(1-beta*sigma)*ub
 else:
  lo=max(a-b*U,-p2*v);hi=min(a+b*U,(w-v+p1*h)/gamma,p3*(M-v))
  if lo>hi:raise ValueError('Direct interval infeasible')
  ac=min(hi,max(lo,a+b*(seed if kind==5 else nominal)));u=(ac-a)/b
 accel=a+b*u
 return np.array([w-v-gamma*accel,accel,u]),abs((sigma*seed+(1-sigma)*ub)-(beta*sigma*nominal+(1-beta*sigma)*ub))

def main():
 source='#include "kernel.cpp"\nextern "C" int eval_probe(const double* m,int profile,const double* method,double nominal,double t,double h,double v,double* out){float tab[8];for(int i=0;i<8;i++)tab[i]=(float)nominal;Policy p{tab,2,2,2,100,-10,110,-1,4};Eval e=control(p,m,profile,method,t,h,v,false,0);out[0]=e.dh;out[1]=e.dv;out[2]=e.u;return e.status;}\n'
 (R/'validation_probe.cpp').write_text(source);subprocess.run(['g++','-O3','-std=c++17','-fPIC','-shared',str(R/'validation_probe.cpp'),'-o',str(R/'validation_probe.so')],check=True)
 lib=ctypes.CDLL(str(R/'validation_probe.so'));ad=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS');lib.eval_probe.argtypes=[ad,ctypes.c_int,ad]+[ctypes.c_double]*4+[ad];lib.eval_probe.restype=ctypes.c_int
 n=0;bad=0;maxerr=0.;factor=0.;maxinput=0.;groups={}
 for obj in E.OBJECTIVES:
  for model in E.MODELS:
   for method in S.methods(obj):
    for h in [0.,1e-12,.05,.2,.25,.8,1.4]:
     for v in [0.,1e-12,.05,model.M/2,model.M-1e-12,model.M]:
      for un in [-5.,0.,5.]:
       for prof in [0,4]:
        out=np.zeros(3);status=lib.eval_probe(model.array(),prof,np.array(method['pars'],float),un,1.,h,v,out)
        if status:bad+=1;continue
        expected,fac=direct(model,method,1.,h,v,E.PROFILES[prof],un)
        err=float(np.max(np.abs(out-expected)));maxerr=max(maxerr,err);factor=max(factor,float(fac));maxinput=max(maxinput,abs(float(out[2]))-model.U);n+=1;groups[method['name']]=max(groups.get(method['name'],0.),err)
 result={'probes':n,'failures':bad,'max_absolute_physical_vs_stabilized_error':maxerr,'max_input_excess':max(0.,maxinput),'max_shared_seed_factorization_error':factor,'by_controller_max_error':groups,'passed':bool(bad==0 and maxerr<2e-12 and factor<2e-12 and maxinput<2e-12),'scope':'Independent formulas at faces,corners,near-rest,target,interior and saturation; no projection of tested physical state.'}
 (R/'metadata/direct_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
