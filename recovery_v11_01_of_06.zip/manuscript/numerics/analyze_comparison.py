#!/usr/bin/env python3
"""Rebuild tables, figure, and factual report from the fixed-setting study."""
from __future__ import annotations
import hashlib
import json
import os
import tempfile
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir()) / 'unified_recovery_mpl_cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

R = Path(__file__).resolve().parent
METHODS = ['old_product', 'gap_product', 'standard_cbf', 'cbf_gap']
LABELS = {'old_product': 'Old product', 'gap_product': 'Gap product',
          'standard_cbf': 'Standard CBF', 'cbf_gap': 'CBF + gap'}
COLORS = {'old_product': '#8b6f47', 'gap_product': '#0072b2',
          'standard_cbf': '#333333', 'cbf_gap': '#009e73'}
KEY = ['objective', 'fixture', 'profile', 'scenario_id', 'method']
CASE = KEY[:-1]


def clean(x):
    if isinstance(x, dict):
        return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [clean(v) for v in x]
    if isinstance(x, np.generic):
        return clean(x.item())
    if isinstance(x, float) and not np.isfinite(x):
        return None
    return x


def save_json(path, x):
    path.write_text(json.dumps(clean(x), indent=2, allow_nan=False) + '\n')


def goal(obj):
    return 0. if obj == 'gap' else .2


def main():
    panels = {n: pd.read_csv(R / 'data' / f'{n}.csv') for n in
              ['evaluation', 'half_step', 'standstill', 'standstill_half_step', 'long_horizon']}
    base, fine = panels['evaluation'], panels['half_step']
    safety = []
    for name, df in panels.items():
        for (obj, method), q in df.groupby(['objective', 'method']):
            safety.append(dict(panel=name, objective=obj, method=method, n=len(q),
                completed=int((q.status == 'completed').sum()),
                violations=int((q.safety_status == 'violation').sum()),
                boundary_or_unresolved=int((q.safety_status == 'boundary_or_numerically_unresolved').sum()),
                min_h=q.min_h.min(), min_v=q.min_v.min(), min_upper_margin=q.min_upper_margin.min(),
                min_stage_h=q.min_stage_h.min(), min_stage_v=q.min_stage_v.min(),
                min_stage_upper_margin=q.min_stage_upper_margin.min(), max_input_excess=q.max_input_excess.max()))
    safety = pd.DataFrame(safety)
    safety.to_csv(R / 'data/safety_summary.csv', index=False)

    summary = []
    for panel in ['evaluation', 'half_step']:
        df = panels[panel]
        reference = df[df.method == 'standard_cbf'][CASE + ['J']].rename(columns={'J': 'J_reference'})
        df = df.merge(reference, on=CASE, validate='many_to_one')
        for (obj, method), q in df.groupby(['objective', 'method']):
            summary.append(dict(panel=panel, objective=obj, method=method, n=len(q),
                mean_cost=q.J.mean(), mean_paired_cost_ratio_to_standard_cbf=(q.J / q.J_reference).mean(),
                median_paired_cost_ratio_to_standard_cbf=(q.J / q.J_reference).median(),
                mean_acceleration_RMS=q.acceleration_RMS.mean(), mean_jerk_RMS_fd=q.jerk_RMS_fd.mean(),
                mean_peak_jerk_fd=q.jerk_peak_abs_fd.mean(), mean_L1_intervention=q.L1_intervention.mean(),
                mean_speed_RMSE=q.speed_RMSE.mean(), mean_headway_RMSE=q.headway_RMSE.mean()))
    summary = pd.DataFrame(summary)
    summary.to_csv(R / 'data/main_summary.csv', index=False)

    pairs = [('gap_product', 'old_product'), ('cbf_gap', 'standard_cbf'),
             ('cbf_gap', 'gap_product'), ('gap_product', 'standard_cbf')]
    paired = []
    subgroups = []
    for treatment, reference in pairs:
        x = base[base.method == treatment].merge(base[base.method == reference], on=CASE,
                 suffixes=('_treatment', '_reference'), validate='one_to_one')
        for obj, q in x.groupby('objective'):
            g = goal(obj)
            is_rest = (q.profile == 'w5_stopped') & (q.v0_treatment == 0)
            groups = {'all': q,
                      'permanent_stop_strict_excess_rest': q[is_rest & (q.h0_treatment > g)],
                      'permanent_stop_at_or_below_goal_rest': q[is_rest & (q.h0_treatment <= g)],
                      'remaining_cases': q[~is_rest]}
            for subgroup, z in groups.items():
                ratios = z.J_treatment / z.J_reference
                tol = 1e-8 * np.maximum(1, np.abs(z.J_reference))
                row = dict(objective=obj, treatment=treatment, reference=reference,
                    subgroup=subgroup, n=len(z), mean_paired_cost_ratio=ratios.mean(),
                    median_paired_cost_ratio=ratios.median(), mean_cost_difference=(z.J_treatment-z.J_reference).mean(),
                    lower_cost_cases=int(((z.J_treatment-z.J_reference) < -tol).sum()),
                    higher_cost_cases=int(((z.J_treatment-z.J_reference) > tol).sum()),
                    tied_cost_cases=int(((z.J_treatment-z.J_reference).abs() <= tol).sum()),
                    mean_acceleration_RMS_difference=(z.acceleration_RMS_treatment-z.acceleration_RMS_reference).mean(),
                    mean_jerk_RMS_fd_difference=(z.jerk_RMS_fd_treatment-z.jerk_RMS_fd_reference).mean())
                (paired if subgroup == 'all' else subgroups).append(row)
    pd.DataFrame(paired).to_csv(R / 'data/paired_comparisons.csv', index=False)
    pd.DataFrame(subgroups).to_csv(R / 'data/paired_subgroups.csv', index=False)

    recovery = []
    for panel in ['standstill', 'standstill_half_step', 'long_horizon']:
        df = panels[panel]
        for (obj, method), q in df.groupby(['objective', 'method']):
            g = goal(obj)
            excess = q[q.h0 > g]
            target = q[q.h0 <= g]
            row = dict(panel=panel, horizon=60 if panel == 'long_horizon' else 10,
                objective=obj, method=method, strict_excess_n=len(excess),
                reach_v001=int((excess.first_v001 >= 0).sum()), reach_v005=int((excess.first_v005 >= 0).sum()),
                max_terminal_headway_excess=(excess.terminal_h-g).max(),
                min_terminal_headway_excess=(excess.terminal_h-g).min(),
                max_terminal_physical_gap_excess=(excess.terminal_d-.02-g).max(),
                max_terminal_speed=excess.terminal_v.max(),
                at_or_below_goal_n=len(target), at_or_below_goal_max_peak_speed=target.peak_v.max(),
                at_or_below_goal_reach_v001=int((target.first_v001 >= 0).sum()))
            for eta, field, suffix in [(.05, 'first_d_goal005', '005'), (.01, 'first_d_goal001', '001')]:
                eligible = excess[excess.h0 > g + eta + 1e-12]
                reached = eligible[eligible[field] >= 0]
                row[f'initially_outside_tolerance_{suffix}'] = len(eligible)
                row[f'reached_tolerance_{suffix}'] = len(reached)
                row[f'max_entry_time_{suffix}_among_arrivals'] = reached[field].max()
            recovery.append(row)
    recovery = pd.DataFrame(recovery)
    recovery.to_csv(R / 'data/recovery_summary.csv', index=False)

    refinement = []
    for coarse_name, fine_name in [('evaluation', 'half_step'), ('standstill', 'standstill_half_step')]:
        q = panels[coarse_name].merge(panels[fine_name], on=KEY, suffixes=('_base', '_fine'), validate='one_to_one')
        for (obj, method), z in q.groupby(['objective', 'method']):
            row = dict(panel=coarse_name, objective=obj, method=method, n=len(z),
                max_absolute_cost_difference=(z.J_base-z.J_fine).abs().max(),
                max_relative_cost_difference=(z.J_base/z.J_fine-1).abs().max(),
                mean_absolute_cost_difference=(z.J_base-z.J_fine).abs().mean(),
                max_terminal_h_difference=(z.terminal_h_base-z.terminal_h_fine).abs().max(),
                max_terminal_v_difference=(z.terminal_v_base-z.terminal_v_fine).abs().max(),
                mean_acceleration_RMS_base=z.acceleration_RMS_base.mean(), mean_acceleration_RMS_fine=z.acceleration_RMS_fine.mean(),
                mean_jerk_RMS_fd_base=z.jerk_RMS_fd_base.mean(), mean_jerk_RMS_fd_fine=z.jerk_RMS_fd_fine.mean())
            for field in ['first_v001', 'first_v005', 'first_d_goal005', 'first_d_goal001']:
                reached_base = z[f'{field}_base'] >= 0
                reached_fine = z[f'{field}_fine'] >= 0
                both = reached_base & reached_fine
                row[f'{field}_arrival_status_mismatches'] = int((reached_base != reached_fine).sum())
                row[f'{field}_max_absolute_time_difference_among_joint_arrivals'] = (
                    z.loc[both, f'{field}_base']-z.loc[both, f'{field}_fine']).abs().max()
            refinement.append(row)
    refinement = pd.DataFrame(refinement)
    refinement.to_csv(R / 'data/refinement_summary.csv', index=False)

    # All three fixtures at the same prespecified h0=.8, v0=0 are shown.
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False,
                         'figure.facecolor': 'white', 'savefig.facecolor': 'white'})
    fig, axes = plt.subplots(2, 3, figsize=(13.2, 7.7), constrained_layout=True)
    for j, fixture in enumerate(['C1', 'C2', 'C3']):
        z = np.load(R / 'data' / f'trace__{fixture}__w5_stopped__tracking__medium__long_horizon__dt0.005.npz')
        fields = list(z['fields']); ax = axes[0, j]
        for method in METHODS:
            tr = z['trace'][list(z['methods']).index(method)]
            style = {'old_product': ':', 'gap_product': '-', 'standard_cbf': '--', 'cbf_gap': '--'}[method]
            lw = 2.5 if method == 'gap_product' else 1.6
            ax.plot(tr[:, fields.index('t')], tr[:, fields.index('d')]-.02,
                    color=COLORS[method], linestyle=style, linewidth=lw, label=LABELS[method])
        ax.axhline(.2, color='#777777', linewidth=.7)
        ax.axhline(.21, color='#aaaaaa', linewidth=.7, linestyle=':')
        ax.axvline(10, color='#aaaaaa', linewidth=.8, linestyle=':')
        ax.set(xlim=(0, 60), ylim=(.045, .85), xlabel='Normalized time',
               title=f'{fixture}: stopped leader, tracking task')
        ax.set_ylabel(r'Physical clearance $d-\varepsilon$')
        ax.grid(alpha=.15)
    x = np.arange(2); width = .18
    fields = ['mean_paired_cost_ratio_to_standard_cbf', 'mean_acceleration_RMS', 'mean_jerk_RMS_fd']
    titles = ['Mean paired task cost', 'Mean physical acceleration RMS', 'Mean finite-difference jerk RMS']
    ylabels = [r'Mean $J/J_{\rm standard\ CBF}$', 'Normalized acceleration', 'Normalized jerk; step 0.005']
    for j, (field, title, ylabel) in enumerate(zip(fields, titles, ylabels)):
        ax = axes[1, j]
        for i, method in enumerate(METHODS):
            q = summary[(summary.panel == 'evaluation') & (summary.method == method)].set_index('objective')
            xx = x + (i-1.5)*width
            values = [q.loc[o, field] for o in ['gap', 'tracking']]
            if j == 0:
                ax.scatter(xx, values, s=36, color=COLORS[method], zorder=3)
            else:
                ax.bar(xx, values, width, color=COLORS[method], alpha=.9)
            if j == 2:
                qf = summary[(summary.panel == 'half_step') & (summary.method == method)].set_index('objective')
                ax.plot(xx, [qf.loc[o, field] for o in ['gap', 'tracking']], 'o', markersize=3,
                        color='white', markeredgecolor='black', markeredgewidth=.65)
        ax.set_xticks(x, ['Gap task', 'Tracking task'])
        ax.set(title=title, ylabel=ylabel)
        ax.grid(axis='y', alpha=.15)
        if j == 0:
            ax.axhline(1, color='#777777', linewidth=.7)
            ax.set_ylim(.95, 1.18)
        if j == 2:
            ax.text(.97, .96, 'White dots: step 0.0025', ha='right', va='top',
                    transform=ax.transAxes, fontsize=8)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='outside lower center', ncol=4, frameon=False)
    fig.suptitle('Shared recovery seed with product blending and CBF projection', fontsize=14)
    fig.savefig(R / 'figures/shared_recovery_comparison.png', dpi=190)
    plt.close(fig)

    env = json.loads((R / 'metadata/environment.json').read_text())
    validation = json.loads((R / 'metadata/direct_checks.json').read_text())
    all_rows = pd.concat(panels.values(), ignore_index=True)
    report_data = dict(study='Frozen matched CBF+gap comparison', total_integrations=len(all_rows),
        integration_counts=env['counts'], production_wall_seconds=env['wall_seconds'],
        completed=int((all_rows.status == 'completed').sum()),
        classified_violations=int((all_rows.safety_status == 'violation').sum()),
        min_accepted_h=all_rows.min_h.min(), min_accepted_v=all_rows.min_v.min(),
        min_accepted_upper_margin=all_rows.min_upper_margin.min(), min_stage_h=all_rows.min_stage_h.min(),
        max_input_excess=all_rows.max_input_excess.max(),
        main_summary=summary.to_dict(orient='records'), paired_comparisons=paired,
        recovery_summary=recovery.to_dict(orient='records'), refinement_summary=refinement.to_dict(orient='records'),
        direct_formula_checks=validation)
    save_json(R / 'metadata/analysis_summary.json', report_data)

    table = summary[summary.panel == 'evaluation'][['objective', 'method', 'mean_cost',
        'mean_paired_cost_ratio_to_standard_cbf', 'mean_acceleration_RMS', 'mean_jerk_RMS_fd']]
    report = '''MATCHED RECOVERY LAYER: PRODUCT BLENDING AND CBF PROJECTION
Executed 1 November 2026; fixed parameters inherited from Revision 3.

MAIN FINDING
The same low-speed, target-aware recovery seed can be used with CBF projection.
In this study it preserves the new product filter's tested rest-state recovery
and intentional stationarity, while its aggregate cost stays much closer to the
standard CBF baseline. Its mean finite-difference jerk is below the product
filter's and above the standard CBF's. These results support a shared recovery
construction. They do not support claiming that product blending outperforms
an otherwise matched CBF with the same recovery mechanism.

PROTOCOL AND FAIRNESS
All four controllers share the plant, actuator bound, safe set, leader preview,
nominal HJB policy, objective, initial states, and integration settings. The
original and augmented CBF both use the identical feasible interval with gains
(10,10,10). The augmented CBF projects the same seed used in the exact product
factorization: beta=tanh(50*v_+/M), u_rec=beta*k+(1-beta)*backup_lambda;
product=sigma*u_rec+(1-sigma)*backup_lambda, with
sigma=tanh(50*h_+)*tanh(50*(M-v)_+/M). The gap task uses lambda=2,h_goal=0;
tracking uses lambda=.1,h_goal=.2. The activation scale is .2; the product
headway normalization is 1. No parameter was retuned on these results.

The cost functionals, with zero terminal cost and applied input u, are
  J_gap = integral_0^10 [.2*u(t)^2 + 50*d(t)^2] dt,
  J_tracking = integral_0^10 [.2*u(t)^2 + (v(t)-w(t))^2
                              + 5*(h(t)-.2)^2] dt.
The plant is d_dot=w-v, v_dot=A(d,v)+u, with A=alpha*(V(d)-v),
h=d-gamma*v-.02, U=5, and M=1.96. C1 has alpha=2.6,gamma=.2;
C2 has alpha=1,gamma=.3; both use V(d)=tanh(d)-tanh(2), which is
negative for d<2. These two are analytical feasibility fixtures, not calibrated
physical desired-speed models. C3 has alpha=2.6,gamma=.35 and the nonnegative
law V(d)=clip(.8*(d-.1),0,1.5). All three are normalized illustrative benchmarks,
not calibrated vehicle tests. This limits any physical performance interpretation.

There are 750 evaluation scenarios per objective: three normalized OVM fixtures,
five leader profiles, and 50 initial states. Six saved stopped-leader action
tables were reused byte-for-byte; 24 moving-profile tables were rebuilt with
the identical medium-grid Bellman method. Only nominal tables were reused:
every comparison trajectory is newly integrated. Protocol JSON was saved
before any simulation. All policy and source hashes are retained.
All 30 nominal action-array hashes match the archived Revision 3 hashes,
including all 24 rebuilt moving-profile policies.

EXECUTED COUNTS AND SAFETY
6,000 primary evaluation runs; 6,000 half-step evaluation runs; 168 exact-rest
runs; 168 exact-rest half-step runs; 168 sixty-unit diagnostic runs: 12,504
new integrations in total. All completed; none met the declared numerical
violation threshold. Accepted-state headway, lower-speed and upper-speed
margins were nonnegative. The most negative RK4 internal-stage headway was
-7.586e-9 for both CBF variants at step .005, below the declared 1e-7 headway
tolerance; the full .0025 evaluation had nonnegative internal-stage margins.
The maximum input excess was 8.882e-16. No physical state projection, safety
slack, or interval widening was used. These are numerical checks of continuous
feedback, not a sampled-data safety certificate or a proof of exact arithmetic
invariance.

MAIN COST AND COMFORT METRICS (750 equally weighted cases per row)
Cost ratio is the arithmetic mean of paired J_controller/J_standardCBF,
not the ratio of aggregate mean costs. J uses the APPLIED control.

''' + table.to_string(index=False, float_format=lambda x: f'{x:.8f}') + '''

CBF+gap's mean paired cost ratio to gap product is .981089 for the gap task
and .984086 for tracking. Against standard CBF it is 1.000210 and 1.004598.
These small aggregate costs accompany the additional task-aware rest behavior.
There is no universal dominance: some individual scenarios favor other methods.
Acceleration and jerk are normalized physical quantities. They are interpretable
motion-smoothness proxies, not calibrated passenger-comfort or energy measures.

EXACT-REST RECOVERY AND TASK-AWARE STATIONARITY
The prespecified panel has v0=w=0 and h0 in {0,.05,.2,.25,.4,.8,1.4} for every
fixture. Strict mathematical excess h0>h_goal gives 18 gap cases and 12 tracking
cases. Both gap product and CBF+gap reach speed .001 in all 18/18 and 12/12
cases within the ten-unit horizon; their counts reaching .05 are 18/18 and
8/12. A failure to reach .05 in a finite window is not a failure to depart.
The old product stays stopped in all strict excess cases. Standard CBF reaches
.001 in 18/18 gap and 11/12 tracking cases under this fixed nominal; it has no
general task-aware progress guarantee from safety constraints alone.

Both augmented filters preserve exact rest in every at/below-goal case: 3/3
gap cases (the forced corner) and 9/9 tracking cases. Standard CBF preserves
8/9 tracking cases; for the C3 exact target h0=.2 it moves, ending at h=.1613
with peak speed .03829 at T=10. This is safe and compatible with its nominal
objective, but it does not preserve the deliberately specified target rest state.

Gap-entry events use physical d<=epsilon+h_goal+eta, not headway alone.
Cases initially inside that tolerance are excluded from arrival counts.
At T=10, both augmented methods enter eta=.01 in 18/18 eligible gap cases and
9/12 eligible tracking cases; standard CBF enters 18/18 and 4/12. For eta=.05,
the initially outside counts are 15 gap and 9 tracking; both augmented methods
enter 15/15 and 8/9, versus standard CBF's 15/15 and 6/9.

At T=60 both augmented methods enter eta=.01 in all 18/18 gap and 12/12 tracking
cases, and eta=.05 in all 15/15 and 9/9 initially outside cases. Standard CBF's
tracking eta=.01 count stays 4/12; the old product remains stopped. This long
diagnostic continuously extends the same ten-unit nominal by zero after T=10;
it is NOT a sixty-unit optimal-control solve. Its main purpose is to distinguish
task-aware gap progress from safety alone under a fixed bounded nominal.

Recovery does not enforce h>=h_goal or exact arrival at h_goal. In the tracking
C3 example h0=.8, both augmented methods end near h=.0959 by T=60 after the
zero extension. Such undershoot is compatible with no-excess-gap recovery.
Rest preservation when already stopped at/below target is a different property
from exact target tracking while approaching the target.

NUMERICAL VERIFICATION
Every primary evaluation and exact-rest case was repeated with step .0025.
For CBF+gap the maximum relative paired cost change is 2.805e-6 (gap) and
1.573e-5 (tracking). Mean jerk changes from 2.419414 to 2.425185 (gap) and
1.586188 to 1.588657 (tracking). The product's corresponding changes are
4.118462 to 4.167485 and 2.111151 to 2.126904. These values are explicitly
resolution-dependent finite differences; no continuous jerk bound is inferred.
Detailed event-time differences and other controller refinements are in CSV.

6,048 independently evaluated formula probes cover faces, corners, near-rest,
target, interior, saturation, all fixtures, both tasks, and all controllers.
All passed. The maximum physical-formula/stabilized-kernel discrepancy is
3.553e-15; the shared-seed factorization error is 1.776e-15. The direct probe
and full-case half-step checks are complementary, not proofs of the theorems.

FIGURE AND DATA INTERPRETATION
The PNG shows all three fixtures at the same prespecified stopped tracking start
h0=.8,v0=0. The vertical line at ten marks the nominal's zero extension;
horizontal lines mark h_goal and h_goal+.01 in physical clearance. Augmented
product and augmented CBF curves nearly coincide in these examples. The lower
row shows aggregate paired cost and smoothness proxies. No confidence intervals
are added because this is a deterministic scenario matrix, not a population
sample. CSV files retain all individual cases, paired comparisons, subgroup
attribution, safety classifications, recovery eligibility, and refinement data.
'''
    (R / 'report.txt').write_text(report)
    inputs = [R / 'kernel.cpp', R / 'engine.py', R / 'run_comparison.py', R / 'validate_comparison.py',
              R / 'analyze_comparison.py', R / 'scenario_manifest.csv', R / 'README.txt', R / 'report.txt']
    inputs += sorted((R / 'policies').glob('*.npz'))
    inputs += sorted((R / 'data').glob('*.csv'))
    inputs += sorted((R / 'data').glob('trace__*.npz'))
    inputs += sorted((R / 'figures').glob('*.png'))
    inputs += sorted(p for p in (R / 'metadata').glob('*.json') if p.name != 'artifact_manifest.json')
    save_json(R / 'metadata/artifact_manifest.json', {str(p.relative_to(R)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs})
    print('Analysis, six CSV summaries, PNG figure, report, and hashes written.')
    print(table.to_string(index=False))


if __name__ == '__main__':
    main()
