#!/usr/bin/env python3
"""Fixed-setting matched product/CBF recovery comparison. No retuning."""
from __future__ import annotations
import csv,hashlib,json,platform,sys,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from dataclasses import asdict
from pathlib import Path
import numpy as np
import scipy
import engine as E
R=Path(__file__).resolve().parent

def methods(obj):
 lam=2. if obj=='gap' else .1;goal=0. if obj=='gap' else .2
 return [
  {'name':'old_product','family':'old_product','pars':[2,50,0,0,0,.2,goal,0]},
  {'name':'gap_product','family':'gap_product','pars':[2,50,0,0,lam,.2,goal,0]},
  {'name':'standard_cbf','family':'standard_cbf','pars':[4,10,10,10,0,.2,goal,0]},
  {'name':'cbf_gap','family':'cbf_gap','pars':[5,10,10,10,lam,.2,goal,50]},
 ]

def stopped_policy(model,obj):
 ident=f'{model.name}__w5_stopped__{obj}__medium';p=R/'policies'/f'{ident}.npz';z=np.load(p)
 assert z['u'].shape[0]==201 and z['u'].shape[-1]==129
 assert np.allclose(np.diff(z['d']),.1,rtol=0,atol=1e-12)
 return {'u':np.ascontiguousarray(z['u'],dtype=np.float32),'t':z['t'],'d':z['d'],'v':z['v'],'dt':.05,'dd':.1,'dv':float(z['v'][1]-z['v'][0]),'level':'medium','id':ident,'model':model,'profile':E.PROFILES[4],'objective':obj}

def rest_states(model,split='standstill'):
 return [{'scenario_id':f'{model.name}_{split}_{i:02d}','split':split,'h0':h,'v0':0.} for i,h in enumerate([0.,.05,.2,.25,.4,.8,1.4])]

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def run_job(lib,model,profile,obj):
 if profile==E.PROFILES[4]:
  pol=stopped_policy(model,obj);meta={'id':pol['id'],'reused_from_v3':True,'policy_sha256':hashlib.sha256(pol['u'].tobytes()).hexdigest()}
  (R/'metadata'/f'{pol["id"]}.json').write_text(json.dumps(meta,indent=2))
 else:pol,meta=E.solve_dp(lib,model,profile,obj)
 ss=E.scenarios(model,profile,'evaluation');mm=methods(obj)
 base=E.simulate(lib,pol,ss,mm,dt=.005,trace_index=len(ss)-1,trace_stride=2,tag='evaluation')
 fine=E.simulate(lib,pol,ss,mm,dt=.0025,trace_index=-1,tag='half_step')
 stand=[];standfine=[]
 if profile==E.PROFILES[4]:
  sx=rest_states(model)
  stand=E.simulate(lib,pol,sx,mm,dt=.005,trace_index=5,trace_stride=1,tag='standstill')
  standfine=E.simulate(lib,pol,sx,mm,dt=.0025,trace_index=5,trace_stride=1,tag='standstill_half_step')
 return base,fine,stand,standfine

def sort_rows(rows):return sorted(rows,key=lambda q:(q['objective'],q['fixture'],q['profile'],q['scenario_id'],q['method']))

def main():
 started=time.perf_counter()
 protocol={'study':'Shared low-speed recovery seed with product versus CBF completion','fixed_before_runs':True,'T':10.,'main_dt':.005,'half_step_dt':.0025,'workers':2,'models':[asdict(m) for m in E.MODELS],'objectives':['.2*u^2+50*d^2','.2*u^2+(v-w)^2+5*(h-.2)^2'],'methods':{o:methods(o) for o in E.OBJECTIVES},'beta':'tanh(50*max(v,0)/M)','sigma':'tanh(50*max(h,0))*tanh(50*max(M-v,0)/M)','common_recovery_seed':'u_rec=beta*k+(1-beta)*backup_lambda','product_factorization':'u_product=sigma*u_rec+(1-sigma)*backup_lambda exactly','new_cbf':'project u_rec, equivalently a+b*u_rec in acceleration coordinates, onto the SAME feasible CBF interval with gains(10,10,10)','backup_reference':'(w/2-v+lambda*rho((h-h_goal)_+)*(M-v))/gamma; rho=x/(.2+x)','no_retuning':True,'parameter_origin':'Frozen v3: N50;lambda2 gap,lambda.1 tracking;h_goal0 gap,.2 tracking;activation scale.2;blend headway scale1;speed scaleM.','evaluation_cases_per_objective':750,'standstill_h0':[0.,.05,.2,.25,.4,.8,1.4],'standstill_v0':0.,'departure_thresholds':[.001,.05],'gap_tolerances':[.05,.01],'gap_event':'first d<=epsilon+h_goal+eta; only stopped-leader interpretation is used','long_horizon':{'T':60.,'nominal':'same ten-unit reconstructed HJB policy continuously extended by zero after t10','purpose':'diagnostic of no-excess-gap recovery; not a new sixty-unit optimal control solve'},'policy_reuse':'Six byte-identical saved v3 stopped-leader tables;24 moving profiles rebuilt with identical medium-grid Bellman method. All closed-loop trajectories are new.','planned_integration_counts':{'main':6000,'half_step':6000,'standstill':168,'standstill_half_step':168,'long_horizon':168},'safety':'No physical state projection, no safety slack, no interval widening; classify numerical h violations below-1e-7,speed below-1.96e-7/input excessabove1e-8; record intermediate stages','jerk':'adjacent accepted-grid finite difference of physical acceleration, not a certified jerk bound','claims':'No dominance, optimality or sampled-data safety claim.'}
 (R/'metadata/protocol.json').write_text(json.dumps(protocol,indent=2))
 lib,compiler=E.compile_kernel()
 buckets=[[],[],[],[]]
 jobs=[(m,p,o) for o in E.OBJECTIVES for m in E.MODELS for p in E.PROFILES[:5]]
 with ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(run_job,lib,*j) for j in jobs]
  for f in as_completed(futures):
   for dest,rows in zip(buckets,f.result()):dest.extend(rows)
 for name,rows in zip(['evaluation.csv','half_step.csv','standstill.csv','standstill_half_step.csv'],buckets):E.write_csv(R/'data'/name,sort_rows(rows))
 long=[];E.T=60.
 for obj in E.OBJECTIVES:
  for model in E.MODELS:
   pol=stopped_policy(model,obj);long+=E.simulate(lib,pol,rest_states(model,'long_horizon'),methods(obj),dt=.005,trace_index=5,trace_stride=2,tag='long_horizon')
 E.T=10.;E.write_csv(R/'data/long_horizon.csv',sort_rows(long))
 env={'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'compiler':compiler,'wall_seconds':time.perf_counter()-started,'counts':dict(zip(['evaluation','half_step','standstill','standstill_half_step'],map(len,buckets)))|{'long_horizon':len(long)},'source_sha256':{n:digest(R/n) for n in ['engine.py','kernel.cpp','run_comparison.py','scenario_manifest.csv']}}
 (R/'metadata/environment.json').write_text(json.dumps(env,indent=2));print('COMPLETE '+json.dumps(env['counts'])+f' seconds={env["wall_seconds"]:.2f}',flush=True)
if __name__=='__main__':main()
