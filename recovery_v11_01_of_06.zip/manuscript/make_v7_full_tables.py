#!/usr/bin/env python3
"""Rebuild the supplement's complete matched/sweep tables from final CSV."""
from pathlib import Path
import argparse
import csv

ROOT = Path(__file__).resolve().parent
KEYS = ("plant", "task", "v0", "nominal", "theta", "dt")
NOMINAL = {"hjb": "H", "zero_input": "Z", "zero_accel": "C", "opposing": "O"}


def label(row):
    task = "G" if row["task"] == "gap" else "T"
    start = "R" if float(row["v0"]) == 0 else "M"
    return f'{row["plant"]}-{task}{start}-{NOMINAL[row["nominal"]]}'


def fmt(row, key, spec=".6g"):
    return format(float(row[key]), spec)


def table(path, columns, caption, ref, heading, records):
    rule = heading + r"\\\midrule" + "\n"
    content = (
        "\\small\n\\setlength{\\tabcolsep}{4pt}\n"
        + "\\begin{longtable}{" + columns + "}\n"
        + "\\caption{" + caption + "}\\label{" + ref + r"}\\" + "\n"
        + "\\toprule " + rule + "\\endfirsthead\n"
        + "\\toprule " + rule + "\\endhead\n\\bottomrule\\endfoot\n"
        + "".join(" & ".join(row) + r"\\" + "\n" for row in records)
        + "\\end{longtable}\n\\normalsize\n"
    )
    path.write_text(content)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", type=Path,
                        default=ROOT.parent / "numerics_v7/data/episodes.csv")
    args = parser.parse_args()
    with args.csv.open() as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 360:
        raise ValueError("The complete 360-case CSV is required.")
    progress = {tuple(r[k] for k in KEYS): r for r in rows
                if r["method"] == "progress" and r["group"] == "base"}
    pairs = [(r, progress[tuple(r[k] for k in KEYS)]) for r in rows
             if r["method"] == "band" and r["group"] == "base"]
    pairs.sort(key=lambda ab: (ab[0]["plant"], ab[0]["task"],
                              float(ab[0]["v0"]), ab[0]["nominal"],
                              float(ab[0]["theta"])))
    assert len(pairs) == 96
    out = ROOT / "tables/v7"
    out.mkdir(parents=True, exist_ok=True)
    records = []
    for band, prog in pairs:
        records.append([label(band), band["theta"], fmt(band, "Tstar", ".6f"),
                        fmt(band, "T", ".6f"), fmt(prog, "T", ".6f")]
                       + [fmt(row, key, ".7g" if key == "J10" else ".6g") for key in ("J10", "I10_L1")
                          for row in (band, prog)])
    table(out / "all_paired.tex", "llrrrrrrr",
          "All 96 matched main cases: physical entry estimates, cost and absolute "
          "intervention. Times use six decimals; cost uses seven and intervention six "
          "significant digits. B denotes band; P denotes certified progress.",
          "v7:tab:allpaired",
          r"Case&$\theta$&$T^*$&$T_B$&$T_P$&$J_B$&$J_P$&$I_{1,B}$&$I_{1,P}$",
          records)
    records = [[label(band), band["theta"]]
               + [fmt(row, key, ".3g") for key in ("RMS_acc10", "TV_acc10", "max_acc_jump")
                  for row in (band, prog)] for band, prog in pairs]
    table(out / "all_motion.tex", "llrrrrrr",
          "All main-case motion metrics on the common horizon. $A$ is acceleration "
          "RMS, $V_a$ numerical acceleration variation, and $A_{\\rm jump}$ the largest "
          "acceleration jump. Metrics use three significant digits.",
          "v7:tab:allmotion",
          r"Case&$\theta$&$A_B$&$A_P$&$V_{a,B}$&$V_{a,P}$&$A_{{\rm jump},B}$&$A_{{\rm jump},P}$",
          records)
    sweep = sorted((r for r in rows if r["method"] == "band" and r["group"] == "sweep"),
                   key=lambda r: (r["plant"], r["task"], float(r["v0"]),
                                  float(r["theta"]), float(r["dt"])))
    assert len(sweep) == 24
    records = [[label(r), r["theta"], r["dt"], r["min_actual_dt"],
                fmt(r, "T", ".3f"), fmt(r, "T_detected", ".3f"),
                fmt(r, "rate_bound_lower", ".3f"), r["shortened_holds"]] for r in sweep]
    table(out / "all_sweep.tex", "llrrrrrr",
          r"All 24 additional band sampling tests. $T_o$ is the interval-confirmed "
          r"detection time; $B_o=\underline T^*/\sqrt\theta+\bar\Delta$ is the "
          "verified comparison bound. Sh is the number of shortened holds.",
          "v7:tab:sweep",
          r"Case&$\theta$&$\bar\Delta$&$\min\delta_n$&$T$&$T_o$&$B_o$&Sh",
          records)
    print("Rebuilt 96 matched rows, 96 motion rows, and 24 sweep rows.")


if __name__ == "__main__":
    main()
