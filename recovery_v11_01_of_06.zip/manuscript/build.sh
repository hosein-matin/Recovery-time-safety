#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
v11_source_dir="$PWD"
python3 make_main_bibliography.py
v11_build_dir="$(mktemp -d)"
trap 'rm -rf "$v11_build_dir"' EXIT

build_document() {
  local v11_source="$1" v11_job="$2" v11_bibliography="$3"
  (
    cd "$v11_build_dir"
    export TEXINPUTS=".:$v11_source_dir:" BIBINPUTS="$v11_source_dir:"
    export BSTINPUTS="$v11_source_dir:"
    touch "$v11_job.aux" "$v11_job.out" "$v11_job.toc"
    pdflatex -interaction=nonstopmode -halt-on-error \
      -jobname="$v11_job" "$v11_source_dir/$v11_source"
    if [ "$v11_bibliography" = yes ]; then bibtex "$v11_job"; fi
    pdflatex -interaction=nonstopmode -halt-on-error \
      -jobname="$v11_job" "$v11_source_dir/$v11_source"
    pdflatex -interaction=nonstopmode -halt-on-error \
      -jobname="$v11_job" "$v11_source_dir/$v11_source"
  )
  python3 - "$v11_build_dir" "$v11_source_dir" "$v11_job" <<'PY'
from pathlib import Path
import os
import shutil
import sys
stage, destination, job = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
pdf = stage / (job + '.pdf')
payload = pdf.read_bytes()
if not payload.startswith(b'%PDF-') or b'%%EOF' not in payload[-2048:]:
    raise RuntimeError('Incomplete PDF: ' + str(pdf))
for source in stage.glob(job + '.*'):
    target = destination / source.name
    temporary = target.with_name(target.name + '.new')
    shutil.copyfile(source, temporary)
    os.replace(temporary, target)
PY
}

case "${1:-all}" in
  main) build_document main.tex ECC_revision_v11_2026-11-08 yes ;;
  companion) build_document companion.tex ECC_revision_v11_technical_notes_2026-11-08 yes ;;
  all)
    build_document main.tex ECC_revision_v11_2026-11-08 yes
    build_document companion.tex ECC_revision_v11_technical_notes_2026-11-08 yes
    ;;
  *) echo 'Usage: bash build.sh [all|main|companion]' >&2; exit 2 ;;
esac
