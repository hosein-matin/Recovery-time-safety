#!/usr/bin/env python3
"""Regenerate the six supplied stopped-leader HJB action tables in isolation.

The saved policies remain the authoritative nominal inputs for the reported
experiments. This command never overwrites them. It compares all four arrays
of each regenerated archive and records exact matches or numerical differences.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'manuscript/numerics'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plant', choices=['C1', 'C2', 'C3'])
    parser.add_argument('--task', choices=['gap', 'tracking'])
    parser.add_argument('--out', type=Path, default=ROOT / 'reproduced/hjb')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    comparisons = []
    with tempfile.TemporaryDirectory(prefix='recovery_hjb_') as temporary:
        stage = Path(temporary)
        for filename in ('engine.py', 'kernel.cpp', 'scenario_manifest.csv'):
            shutil.copyfile(SOURCE / filename, stage / filename)
        spec = importlib.util.spec_from_file_location('recovery_hjb_engine', stage / 'engine.py')
        engine = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = engine
        spec.loader.exec_module(engine)
        lib, compiler = engine.compile_kernel()
        for model in engine.MODELS:
            if args.plant and model.name != args.plant:
                continue
            for task in ('gap', 'tracking'):
                if args.task and task != args.task:
                    continue
                policy, metadata = engine.solve_dp(lib, model, 'w5_stopped', task,
                                                  level='medium', save_policy=True)
                filename = policy['id'] + '.npz'
                generated = stage / 'policies' / filename
                supplied = SOURCE / 'policies' / filename
                row = {'file': filename, 'supplied_file_sha256': sha(supplied),
                       'generator_seconds': metadata['elapsed_seconds'],
                       'generator_full_box': metadata['full_box'],
                       'generator_full_shape': metadata['full_shape'], 'arrays': {}}
                with np.load(generated) as actual, np.load(supplied) as expected:
                    for key in ('t', 'd', 'v', 'u'):
                        row['arrays'][key] = {
                            'exact_match': bool(np.array_equal(actual[key], expected[key])),
                            'max_absolute_difference': float(np.max(np.abs(
                                actual[key].astype(np.float64)-expected[key].astype(np.float64)))),
                            'supplied_array_sha256': hashlib.sha256(expected[key].tobytes()).hexdigest(),
                        }
                row['all_arrays_exact'] = all(x['exact_match'] for x in row['arrays'].values())
                comparisons.append(row)
                shutil.copyfile(generated, args.out / filename)
                shutil.copyfile(stage / 'metadata' / (policy['id']+'.json'),
                                args.out / (policy['id']+'.json'))
                print(json.dumps({'file': filename, 'all_arrays_exact': row['all_arrays_exact'],
                                  'max_action_difference': row['arrays']['u']['max_absolute_difference']}),
                      flush=True)
        result = {'generator_sources': {f: sha(SOURCE / f) for f in ('engine.py', 'kernel.cpp')},
                  'compiler': compiler, 'cases': comparisons,
                  'all_exact': all(row['all_arrays_exact'] for row in comparisons)}
        (args.out / 'regeneration_check.json').write_text(json.dumps(result, indent=2)+'\n')


if __name__ == '__main__':
    main()
