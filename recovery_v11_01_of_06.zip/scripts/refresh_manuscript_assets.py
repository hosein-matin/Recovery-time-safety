#!/usr/bin/env python3
"""Refresh manuscript assets from completed analyses, without running simulations.

The reproduction wrapper calls this script inside its isolated working copy.
Historical analysis/controller sources and their provenance hashes are untouched.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil
import statistics


ROOT = Path(__file__).resolve().parents[1]
FLOOR_TOLERANCE = 1e-8
PAIR_TOLERANCE = 1e-10


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(row, field):
    value = float(row[field])
    if not math.isfinite(value):
        raise ValueError(f'Nonfinite {field} in case {row.get("case_id", "unknown")}')
    return value


def sampled_tables(root):
    """Return Tables II--IV from the completed base CSV, without writing files."""
    source = root / 'numerics_v7/data/episodes.csv'
    with source.open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 360:
        raise ValueError(f'Expected the full 360-record sampled analysis, found {len(rows)}')
    base = {method: [r for r in rows if r['group'] == 'base' and r['method'] == method]
            for method in ('naive', 'band', 'progress')}
    for method, selected in base.items():
        if len(selected) != 96 or any(number(r, 'dt') != .05 for r in selected):
            raise ValueError(f'Expected 96 base records at period .05 for {method}')

    def domain_departure(row):
        if row['method'] == 'naive':
            # Same diagnostic thresholds as the completed historical analysis.
            return (number(row, 'h_min_diagnostic') < -FLOOR_TOLERANCE
                    or number(row, 'v_min_diagnostic') < -FLOOR_TOLERANCE
                    or number(row, 'v_max_diagnostic') > 1.96 + FLOOR_TOLERANCE)
        # The certified methods save lower whole-hold bounds for all three
        # domain inequalities; do not mistake absent diagnostic flags for zero.
        return any(number(row, field) < 0.0
                   for field in ('cert_min_h', 'cert_min_v', 'cert_min_M'))

    safety = [r'\begin{tabular}{lrrrr}', r'\toprule',
              r'Controller & $N$ & Entry & Domain exits & Floor exits\\', r'\midrule']
    safety_counts = {}
    for method, label in [('naive', 'Naive ZOH'), ('band', 'Certified band'),
                          ('progress', 'Certified progress')]:
        selected = base[method]
        counts = {'n': len(selected), 'entered': sum(r['status'] == 'entered' for r in selected),
                  'domain_exits': sum(domain_departure(r) for r in selected),
                  'floor_exits': sum(number(r, 'floor_min_diagnostic') < -FLOOR_TOLERANCE
                                     for r in selected)}
        safety_counts[method] = counts
        floor = (f'${counts["floor_exits"]}' + r'^{\dagger}$'
                 if method == 'progress' else str(counts['floor_exits']))
        safety.append(f'{label} & {counts["n"]} & {counts["entered"]} & '
                      f'{counts["domain_exits"]} & {floor}' + r'\\')
    safety += [r'\bottomrule', r'\end{tabular}']

    rate = [r'\begin{tabular}{lcrr}', r'\toprule',
            r'Method&$\theta$&Median $T/T^*$&Maximum $T/T^*$\\\midrule']
    rate_statistics = []
    for theta in (.25, .5):
        for method, label in [('band', 'Band'), ('progress', 'Progress')]:
            selected = [r for r in base[method] if number(r, 'theta') == theta]
            if len(selected) != 48 or any(r['status'] != 'entered' for r in selected):
                raise ValueError(f'Expected 48 entered cases for {method}, theta={theta}')
            ratios = []
            for row in selected:
                ratio = number(row, 'T') / number(row, 'Tstar')
                if not math.isclose(ratio, number(row, 'ratio'), rel_tol=1e-12, abs_tol=1e-12):
                    raise ValueError(f'Inconsistent entry ratio in case {row["case_id"]}')
                ratios.append(ratio)
            med, maximum = statistics.median(ratios), max(ratios)
            rate.append(f'{label}&{theta:.2f}'.replace('&0.', '&.')
                        + f'&{med:.3f}&{maximum:.3f}' + r'\\')
            rate_statistics.append({'method': method, 'theta': theta, 'n': len(selected),
                                    'median_ratio': med, 'max_ratio': maximum})
    rate[-1] += r'\bottomrule'
    rate.append(r'\end{tabular}')

    def key(row):
        return (row['plant'], row['task'], number(row, 'v0'), row['nominal'],
                number(row, 'theta'), number(row, 'dt'))
    band = {key(row): row for row in base['band']}
    progress = {key(row): row for row in base['progress']}
    if len(band) != 96 or len(progress) != 96 or set(band) != set(progress):
        raise ValueError('Base band/progress records must form 96 unique matched pairs')
    paired = [r'\begin{tabular}{lrr}', r'\toprule',
              r'Metric & Band lower & Progress lower\\', r'\midrule']
    paired_counts = {}
    for field, label in [('T', 'Entry time'), ('J10', r'$J_{10}$'),
                         ('I10_L1', r'$I_{1,10}$'), ('I10_L2', r'$I_{2,10}$'),
                         ('RMS_acc10', 'Acceleration RMS'), ('TV_acc10', 'Acceleration TV')]:
        differences = [number(band[k], field) - number(progress[k], field) for k in sorted(band)]
        counts = {'n': len(differences), 'band_lower': sum(x < -PAIR_TOLERANCE for x in differences),
                  'progress_lower': sum(x > PAIR_TOLERANCE for x in differences),
                  'ties': sum(abs(x) <= PAIR_TOLERANCE for x in differences)}
        paired_counts[field] = counts
        paired.append(f'{label} & {counts["band_lower"]}/{counts["n"]} & '
                      f'{counts["progress_lower"]}/{counts["n"]}' + r'\\')
    paired += [r'\bottomrule', r'\end{tabular}']
    tables = {'safety_summary.tex': '\n'.join(safety) + '\n',
              'rate_main.tex': '\n'.join(rate) + '\n',
              'paired_counts.tex': '\n'.join(paired) + '\n'}
    evidence = {'input': str(source.relative_to(root)), 'input_sha256': sha256(source),
                'floor_departure_rule': 'floor_min_diagnostic < -1e-8',
                'paired_raw_difference_threshold': PAIR_TOLERANCE,
                'safety': safety_counts, 'rates': rate_statistics, 'paired': paired_counts}
    return tables, evidence


def refresh(root, component):
    copied = []
    generated = []
    report = {'component': component, 'scope': 'Asset copies and descriptive table generation only; no simulations.',
              'copied': copied, 'generated': generated}

    def copy(source, destination):
        src, dst = root / source, root / destination
        if not src.is_file():
            raise FileNotFoundError(f'Missing completed analysis artifact: {src}')
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        copied.append({'source': source, 'destination': destination, 'sha256': sha256(dst)})

    if component == 'sampled':
        tables, evidence = sampled_tables(root)
        report['table_evidence'] = evidence
        source = root / 'numerics_v7'
        # Include the two notes-only plots, not just the main-paper figure.
        for name in ('sample_hold_failure_and_repair.pdf', 'sampled_performance_tradeoffs.pdf', 'sampling_sweep.pdf'):
            if not (source / 'figures' / name).is_file():
                raise FileNotFoundError(f'Missing completed sampled figure: {name}')
        for kind, suffixes in [('figures', {'.pdf', '.png'}), ('tables', {'.tex'})]:
            for path in sorted((source / kind).iterdir()):
                if path.is_file() and path.suffix in suffixes:
                    if kind == 'tables' and path.name in tables:
                        continue  # The V11 main versions are generated below.
                    copy(str(path.relative_to(root)), f'manuscript/{kind}/v7/{path.name}')
        # Keep historical generator outputs intact; apply V11 reporting here.
        for name, contents in tables.items():
            path = root / 'manuscript/tables/v7' / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(contents)
            generated.append({'destination': str(path.relative_to(root)), 'sha256': sha256(path)})
    elif component == 'fixed-periods':
        copy('fixed_period_experiments/figures/fixed_period_overview.pdf',
             'manuscript/figures/v11/fixed_period_overview.pdf')
        for name in ('fixed_period_overview.tex', 'historical_comparison.tex'):
            copy('fixed_period_experiments/tables/' + name, 'manuscript/tables/v11/' + name)
    elif component == 'certificates':
        copy('sampling_certificate/certificate_ratio_table.tex', 'manuscript/tables/period_certificate.tex')
        copy('sampling_certificate/certificate_budget_profiles.pdf',
             'manuscript/figures/period_certificate_budget_profiles.pdf')
    else:
        raise ValueError(f'Unknown asset component: {component}')
    record = root / 'output' / f'manuscript_asset_refresh_{component}.json'
    record.parent.mkdir(parents=True, exist_ok=True)
    record.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    for component in ('sampled', 'fixed-periods', 'certificates'):
        group.add_argument('--' + component, dest='component', action='store_const', const=component)
    parser.add_argument('--root', type=Path, default=ROOT,
                        help='Package directory to update; the wrapper supplies an isolated copy.')
    args = parser.parse_args()
    refresh(args.root.resolve(), args.component)


if __name__ == '__main__':
    main()
