#!/usr/bin/env python3
"""V6 episode experiment. Protocol is fixed in protocol.json before production.

The rate filter is a physical reflected trajectory: nominal interior arcs
are integrated to detected boundary contact, then the selected boundary arc
is followed until the nominal points into the tube. No simulated physical
state is clipped into the safe set. Prepared profiles are fixed for an episode.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, platform, sys, time
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import solve_ivp, quad, quad_vec
from scipy.optimize import brentq

ROOT=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR','/tmp/ecc_v6_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pypdf import PdfReader
for sub in ['data','figures','tables']:(ROOT/sub).mkdir(exist_ok=True)
clip=lambda x,l,r:min(max(float(x),float(l)),float(r))

@dataclass(frozen=True)
class Plant:
    name:str; alpha:float; gamma:float
    eps:float=.02; M:float=1.96; U:float=5.
    def a(self,d,v):
        V=clip(.8*(d-.1),0.,1.5) if self.name=='C3' else math.tanh(d)-math.tanh(2.)
        return self.alpha*(V-v)
    def ceiling_v(self,d):return min(self.M,(d-self.eps)/self.gamma)
    def B(self,d):return .5*self.ceiling_v(d)**2
    def Bprime(self,d):return 0. if d>self.eps+self.gamma*self.M else -(d-self.eps)/self.gamma**2
    def limits(self,d,v):
        a=self.a(d,v);return a-self.U,a+self.U
PLANTS=[Plant('C1',2.6,.2),Plant('C2',1.,.3),Plant('C3',2.6,.35)]
THETAS={'rate_010':.1,'rate_025':.25,'rate_050':.5,'rate_100':1.}
PROGRESS={'progress_r0316':(math.sqrt(.1),5.),'progress_r0500':(.5,5.),
          'progress_r0707':(math.sqrt(.5),5.),'progress_r1000':(1.,5.),
          'progress_c2':(.5,2.),'progress_c10':(.5,10.)}
METHODS=['ordinary_cbf','recovery_blend','recovery_cbf',*PROGRESS,*THETAS]
NOMINALS=['hjb','zero_input','zero_accel','opposing']
INITIALS=[(.4,0.),(.8,0.),(.8,.4)]
LABELS={'ordinary_cbf':'Ordinary CBF','recovery_blend':'Recovery blend','recovery_cbf':'Recovery CBF',
        'progress_r0316':'Progress CBF, r=.316','progress_r0500':'Progress CBF, r=.5',
        'progress_r0707':'Progress CBF, r=.707','progress_r1000':'Progress CBF, r=1',
        'progress_c2':'Progress CBF, c=2','progress_c10':'Progress CBF, c=10',
        'rate_010':r'Rate filter, $\theta=.1$','rate_025':r'Rate filter, $\theta=.25$',
        'rate_050':r'Rate filter, $\theta=.5$','rate_100':r'Optimal profile ($\theta=1$)'}

def csvwrite(name,rows):
    if not rows:return
    path=ROOT/'data'/name;tmp=path.with_suffix('.tmp')
    with tmp.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    tmp.replace(path)
def jsonwrite(name,value):
    (ROOT/name).write_text(json.dumps(value,indent=2,allow_nan=True)+'\n')
def csvread(name):return list(csv.DictReader((ROOT/'data'/name).open()))

class Nominal:
    def __init__(self,p,task,kind,legacy):
        self.p,self.task,self.kind=p,task,kind
        if kind=='hjb':
            path=legacy/'policies'/f'{p.name}__w5_stopped__{task}__medium.npz'
            z=np.load(path);self.u=z['u'];self.ts=z['t'];self.ds=z['d'];self.vs=z['v']
            self.dt=self.ts[1]-self.ts[0];self.dd=self.ds[1]-self.ds[0];self.dv=self.vs[1]-self.vs[0]
    def __call__(self,t,d,v):
        if self.kind=='zero_input':return 0.
        if self.kind=='zero_accel':return clip(-self.p.a(d,v),-self.p.U,self.p.U)
        if self.kind=='opposing':return -self.p.U
        if t>=10:return 0.
        if not (self.ds[0]-1e-9<=d<=self.ds[-1]+1e-9 and self.vs[0]-1e-9<=v<=self.vs[-1]+1e-9):
            raise RuntimeError('Policy query outside retained rectangle')
        vals=[]
        for x,lo,dx,n in [(max(0,t),0,self.dt,len(self.ts)),(d,self.ds[0],self.dd,len(self.ds)),(v,self.vs[0],self.dv,len(self.vs))]:
            q=(x-lo)/dx;i=min(max(int(math.floor(q)),0),n-2);vals.append((i,q-i))
        (it,rt),(id,rd),(iv,rv)=vals
        ans=0.
        for j in [0,1]:
            wt=rt if j else 1-rt
            for k in [0,1]:
                wd=rd if k else 1-rd
                ans+=wt*wd*((1-rv)*float(self.u[it+j,id+k,iv])+rv*float(self.u[it+j,id+k,iv+1]))
        return ans

def controller(p,task,method,nom,t,d,v):
    a=p.a(d,v);k=nom(t,d,v);pnom=a+k;h=d-p.gamma*v-p.eps
    L=max(a-p.U,-10*v);R=min(a+p.U,(-v+10*h)/p.gamma,10*(p.M-v))
    hg,lam=(0.,2.) if task=='gap' else (.2,.1)
    excess=max(h-hg,0.);rho=excess/(.2+excess)
    ref=(-v+lam*rho*(p.M-v))/p.gamma
    ub=clip(ref-a,-p.U,p.U)
    beta=math.tanh(50*max(v,0.)/p.M)
    rec=beta*k+(1-beta)*ub
    slack=0.
    if method=='ordinary_cbf':acc=clip(pnom,L,R)
    elif method=='recovery_cbf':acc=clip(a+rec,L,R)
    elif method=='recovery_blend':
        sigma=math.tanh(50*max(h,0.))*math.tanh(50*max(p.M-v,0.)/p.M)
        acc=a+sigma*rec+(1-sigma)*ub
    elif method in PROGRESS:
        r,c=PROGRESS[method];vb=p.ceiling_v(d)
        vp=0. if d>p.eps+p.gamma*p.M else 1/p.gamma
        required=-r*v*vp+c*(r*vb-v)
        slack=max(0.,required-R)
        acc=clip(pnom,max(L,min(required,R)),R)
    else:raise ValueError(method)
    # Ambient extension for implicit-solver trial states outside D. On D the
    # certified interval is nonempty and this final actuator clip is inactive.
    # No physical state is projected; accepted trajectories are checked below.
    acc=a+clip(acc-a,-p.U,p.U)
    return acc,acc-a,k,slack

class Profile:
    """Maximal OVM energy profile and its nonwaiting physical clock."""
    def __init__(self,p,d0,v0,target,fine=False):
        start=time.perf_counter();self.p,self.d0,self.v0,self.target=p,d0,v0,target
        self.S=d0-target;self.E0=.5*v0*v0
        self.rtol=2e-11 if fine else 2e-9;self.atol=self.rtol/100
        def rhs(s,y):return [p.a(d0-s,math.sqrt(2*max(y[0],0.)))+p.U]
        def hit(s,y):return y[0]-p.B(d0-s)
        hit.direction=1;hit.terminal=True
        self.sol=solve_ivp(rhs,[0,self.S],[self.E0],method='DOP853',rtol=self.rtol,atol=self.atol,
                           max_step=self.S/(512 if fine else 256),dense_output=True,events=hit)
        if not self.sol.success:raise RuntimeError(self.sol.message)
        self.hit=float(self.sol.t[-1]) if len(self.sol.t_events[0]) else self.S+1
        self.cap_kink=d0-(p.eps+p.gamma*p.M)
        self.knots=sorted(set([0.,self.S]+[x for x in [self.hit,self.cap_kink] if 0<x<self.S]))
        launch=p.a(d0,0)+p.U
        def clock_rhs(x,y):
            if x==0:return [math.sqrt(2/launch) if v0==0 else 0.]
            return [2*x/math.sqrt(2*self.E(x*x))]
        self.clocksol=solve_ivp(clock_rhs,[0,math.sqrt(self.S)],[0.],method='DOP853',rtol=self.rtol,atol=self.atol,
                               max_step=math.sqrt(self.S)/(512 if fine else 256),dense_output=True)
        if not self.clocksol.success:raise RuntimeError(self.clocksol.message)
        self.Tstar=self.clock(self.S);self.offline_seconds=time.perf_counter()-start
    def E(self,s):
        if s>=self.hit:return self.p.B(self.d0-s)
        return float(self.sol.sol(s)[0])
    def derivative(self,s):
        if s>=self.hit:return self.p.Bprime(self.d0-s)
        return self.p.a(self.d0-s,math.sqrt(2*max(self.E(s),0.)))+self.p.U
    def clock(self,s):return float(self.clocksol.sol(math.sqrt(max(0.,s)))[0])
    def certificate(self,theta):
        pts=np.unique(np.r_[np.linspace(0,self.S,2049),self.knots,
                            [x+y for x in self.knots for y in [-1e-9,1e-9] if 0<=x+y<=self.S]])
        upper=[];lower=[]
        for s in pts:
            q=theta*self.E(s);qp=theta*self.derivative(s);lo,hi=self.p.limits(self.d0-s,math.sqrt(2*max(q,0.)))
            upper.append(hi-qp);lower.append(qp-lo)
        return min(upper),min(lower)
    def worst(self,theta,fine=False):
        if self.v0==0:return self.Tstar/math.sqrt(theta),0.
        if theta==1:return self.Tstar,0.
        def rhs(s,y):
            v=math.sqrt(2*max(y[0],1e-300))
            return [self.p.a(self.d0-s,v)-self.p.U,1/v]
        def hit(s,y):return y[0]-theta*self.E(s)
        hit.direction=-1;hit.terminal=True
        sol=solve_ivp(rhs,[0,self.S],[self.E0,0.],method='DOP853',rtol=self.rtol,atol=self.atol,
                      max_step=self.S/(512 if fine else 256),events=hit,dense_output=True)
        if not sol.success:raise RuntimeError('Lower profile failed '+sol.message)
        s=float(sol.t[-1]);return float(sol.y[1,-1])+(self.clock(self.S)-self.clock(s))/math.sqrt(theta),s

class TimeArc:
    def __init__(self,p,task,method,nom,t0,t1,sol=None,state=None):
        self.p,self.task,self.method,self.nom=p,task,method,nom
        self.t0,self.t1,self.sol,self.state=t0,t1,sol,state
    def y(self,t):return np.asarray(self.state if self.sol is None else self.sol.sol(t),float)
    def values(self,t):
        d,v=self.y(t);acc,u,k,slack=controller(self.p,self.task,self.method,self.nom,t,float(d),float(v))
        return float(d),float(v),acc,u,k,slack

class SpaceArc:
    def __init__(self,P,nom,mode,s0,s1,t0,theta=None,sol=None):
        self.P,self.nom,self.mode,self.s0,self.s1,self.t0,self.theta,self.sol=P,nom,mode,s0,s1,t0,theta,sol
        self.t1=self.clock(s1)
    def energy(self,s):
        if self.mode=='floor':return self.theta*self.P.E(s)
        if self.mode=='upper':return self.P.p.B(self.P.d0-s)
        if self.mode=='optimal':return self.P.E(s)
        return float(self.sol.sol(s)[0])
    def clock(self,s):
        P=self.P
        if self.mode=='floor':return self.t0+(P.clock(s)-P.clock(self.s0))/math.sqrt(self.theta)
        if self.mode=='optimal':return P.clock(s)
        if self.mode=='upper':
            d0=P.d0-self.s0;d1=P.d0-s;dc=P.p.eps+P.p.gamma*P.p.M
            val=max(0.,d0-max(d1,dc))/P.p.M;high=min(d0,dc)
            if high>d1:val+=P.p.gamma*math.log((high-P.p.eps)/(d1-P.p.eps))
            return self.t0+val
        return float(self.sol.sol(s)[1])
    def values_s(self,s):
        P=self.P;d=P.d0-s;E=self.energy(s)
        if E < -1e-8:raise RuntimeError('Negative interior energy')
        v=math.sqrt(2*max(E,0.));t=self.clock(s);k=self.nom(t,d,v)
        if self.mode=='floor':acc=self.theta*P.derivative(s)
        elif self.mode=='upper':acc=P.p.Bprime(d)
        elif self.mode=='optimal':acc=P.derivative(s)
        else:acc=P.p.a(d,v)+k
        return d,v,acc,acc-P.p.a(d,v),k,0.
    def s_at(self,t):
        if t<=self.t0:return self.s0
        if t>=self.t1:return self.s1
        return brentq(lambda s:self.clock(s)-t,self.s0,self.s1,xtol=1e-13)
    def values(self,t):return self.values_s(self.s_at(t))

def first_positive_root(fun,start,end,knots,resolution):
    """First sign change into the tube on a boundary arc; refinement checks it."""
    pts=np.unique(np.r_[np.linspace(start,end,resolution+1),[k for k in knots if start<k<end]])
    last_s=start;last=fun(start)
    for s in pts[1:]:
        val=fun(float(s))
        if val>1e-10:
            if last<0:
                return brentq(fun,last_s,float(s),xtol=1e-13)
            return last_s
        last_s=float(s);last=val
    return end

def rate_episode(P,nom,theta,fine=False):
    if theta==1:return [SpaceArc(P,nom,'optimal',0.,P.S,0.,theta=1.)]
    if min(P.certificate(theta)) < -1e-7:raise RuntimeError('Performance floor certificate fails')
    p=P.p;S=P.S;s=0.;t=0.;E=P.E0;arcs=[]
    qp=lambda z:theta*P.derivative(z)
    q=lambda z:theta*P.E(z)
    mode='interior'
    if P.v0==0:
        p0=p.a(P.d0,0)+nom(0.,P.d0,0.)
        if p0<=qp(0.)+1e-9:mode='floor'
        else:
            # Resolve the physical launch in time, where no 1/v singularity occurs.
            launch_time=1e-6 if fine else 1e-5
            def rhs(tt,y):return [-y[1],p.a(y[0],y[1])+nom(tt,*y)]
            z=solve_ivp(rhs,[0,launch_time],[P.d0,0.],method='DOP853',rtol=P.rtol,atol=P.atol,dense_output=True,max_step=launch_time/10)
            arc=TimeArc(p,'gap','nominal',nom,0.,launch_time,z)
            # The dedicated nominal launch evaluator avoids a controller substitution.
            arc.values=lambda tt,z=z,p=p,nom=nom: nominal_values(p,nom,tt,z.sol(tt))
            arcs.append(arc);d,v=z.y[:,-1];s=P.d0-d;t=launch_time;E=.5*v*v
            check=np.linspace(0,launch_time,21)
            assert min(.5*z.sol(tt)[1]**2-q(P.d0-z.sol(tt)[0]) for tt in check)>-1e-11
    for iteration in range(100):
        if S-s<=1e-12:break
        if mode in ['floor','upper']:
            proto=SpaceArc(P,nom,mode,s,S,t,theta=theta)
            def inward(z):
                d=P.d0-z;v=math.sqrt(2*proto.energy(z));tt=proto.clock(z)
                pn=p.a(d,v)+nom(tt,d,v)
                return pn-qp(z) if mode=='floor' else p.Bprime(d)-pn
            # Opposing nominal is proven to stay on every feasible scaled floor.
            end=S if (mode=='floor' and nom.kind=='opposing') else first_positive_root(inward,s,S,P.knots,2048 if fine else 1024)
            if end>s+1e-12:
                arc=SpaceArc(P,nom,mode,s,end,t,theta=theta);arcs.append(arc)
                s=end;t=arc.t1;E=arc.energy(s)
            else:
                # A release exactly at a profile derivative kink is a physical switch.
                E=proto.energy(s)
            mode='interior';continue
        start_s=s
        def rhs(z,y):
            vv=math.sqrt(2*max(y[0],1e-300));dd=P.d0-z
            return [p.a(dd,vv)+nom(float(y[1]),dd,vv),1/vv]
        def lower(z,y):
            diff=y[0]-q(z)
            if z<=start_s+2e-12:return max(diff,1e-12)
            return diff
        def upper(z,y):
            diff=p.B(P.d0-z)-y[0]
            if z<=start_s+2e-12:return max(diff,1e-12)
            return diff
        for ev in [lower,upper]:ev.direction=-1;ev.terminal=True
        sol=solve_ivp(rhs,[s,S],[E,t],method='DOP853',rtol=P.rtol,atol=P.atol,
                      max_step=S/(512 if fine else 256),dense_output=True,events=[lower,upper])
        if not sol.success:raise RuntimeError('Reflected interior solve failed: '+sol.message)
        end=float(sol.t[-1])
        if end<=s+1e-13:raise RuntimeError('Reflected solver failed to advance')
        arc=SpaceArc(P,nom,'interior',s,end,t,sol=sol,theta=theta);arcs.append(arc)
        s=end;t=arc.t1;E=arc.energy(s)
        if len(sol.t_events[0]):mode='floor'
        elif len(sol.t_events[1]):mode='upper'
        else:break
    else:raise RuntimeError('Too many reflection switches')
    if not arcs or arcs[-1].t1<=0:raise RuntimeError('Empty rate trajectory')
    if abs(s-S)>1e-8 and theta!=1:raise RuntimeError('Rate trajectory incomplete')
    return arcs

def nominal_values(p,nom,t,y):
    d,v=map(float,y);k=nom(t,d,v);return d,v,p.a(d,v)+k,k,k,0.

def time_episode(P,task,method,nom,fine=False,horizon=600.):
    p=P.p;d0,v0=P.d0,P.v0
    if method=='ordinary_cbf' and v0==0 and nom.kind!='hjb' and p.a(d0,0)+nom(0,d0,0)<=1e-14:
        return [TimeArc(p,task,method,nom,0.,horizon,state=[d0,0.])],False
    def rhs(t,y):return [-y[1],controller(p,task,method,nom,t,*y)[0]]
    def hit(t,y):return y[0]-P.target
    hit.direction=-1;hit.terminal=True
    sol=solve_ivp(rhs,[0,horizon],[d0,v0],method='Radau',rtol=2e-10 if fine else 2e-8,
                  atol=2e-12 if fine else 2e-10,max_step=.25 if fine else .5,dense_output=True,events=hit)
    if not sol.success:raise RuntimeError('Baseline solve failed '+sol.message)
    return [TimeArc(p,task,method,nom,0.,float(sol.t[-1]),sol)],bool(len(sol.t_events[0]))

def continuation(P,task,nom,t0,y0,fine=False):
    if t0>=10:return None
    p=P.p
    def rhs(t,y):return [-y[1],controller(p,task,'recovery_cbf',nom,t,*y)[0]]
    sol=solve_ivp(rhs,[t0,10.],y0,method='Radau',rtol=2e-10 if fine else 2e-8,atol=2e-12 if fine else 2e-10,
                  max_step=.025 if fine else .05,dense_output=True)
    if not sol.success:raise RuntimeError('Post-entry solve failed')
    return TimeArc(p,task,'recovery_cbf',nom,t0,10.,sol)

def integrand(p,task,values):
    d,v,a,u,k,slack=values;h=d-p.gamma*v-p.eps
    state=50*d*d if task=='gap' else v*v+5*(h-.2)**2
    return np.array([.2*u*u+state,u*u,abs(u-k),(u-k)**2,a*a,slack])

def integrate_arc(arc,p,task,end=None,fine=False):
    finish=arc.t1 if end is None else min(end,arc.t1)
    if finish<=arc.t0:return np.zeros(6)
    tol=2e-8 if fine else 2e-6
    if isinstance(arc,SpaceArc):
        s_end=arc.s_at(finish)
        # x=sqrt(s-s0) removes the only possible launch singularity.
        def fun(x):
            s=arc.s0+x*x;vals=arc.values_s(s)
            if x==0:
                if vals[1]>0:return np.zeros(6)
                accel=vals[2]
                return integrand(p,task,vals)*math.sqrt(2/accel)
            return integrand(p,task,vals)*(2*x/max(vals[1],1e-300))
        points=[math.sqrt(x-arc.s0) for x in arc.P.knots if arc.s0<x<s_end]
        val,_=quad_vec(fun,0.,math.sqrt(max(0,s_end-arc.s0)),epsabs=tol,epsrel=tol,points=points,limit=300)
        return val
    points=np.arange(max(0,math.ceil(arc.t0/.05)*.05),min(10,finish),.05) if arc.nom.kind=='hjb' else None
    val,_=quad_vec(lambda t:integrand(p,task,arc.values(t)),arc.t0,finish,epsabs=tol,epsrel=tol,points=points,limit=500)
    return val

def internal_events(a):
    """Known acceleration-discontinuity times, without clipping any state."""
    if hasattr(a,'_internal_events'):return a._internal_events
    events=[]
    if isinstance(a,SpaceArc):
        events=[(a.clock(s),'profile_knot') for s in a.P.knots if a.s0<s<a.s1]
    elif a.sol is not None and a.method in PROGRESS:
        dc=a.p.eps+a.p.gamma*a.p.M
        if a.y(a.t0)[0]>dc>a.y(a.t1)[0]:
            tc=brentq(lambda t:a.y(t)[0]-dc,a.t0,a.t1,xtol=1e-13)
            events=[(tc,'progress_ceiling_kink')]
    a._internal_events=events
    return events

def sample_arcs(arcs,end,dt=.01):
    event_times=[t for a in arcs for t,_ in internal_events(a) if t<=end]
    event_times +=[a.t1 for a in arcs[:-1] if a.t1<=end]
    times=np.unique(np.r_[np.arange(0,end,dt),end,[a.t0 for a in arcs if a.t0<=end],
                          [a.t1 for a in arcs if a.t1<=end],event_times,
                          [max(0.,t-1e-8) for t in event_times],
                          [min(end,t+1e-8) for t in event_times]])
    vals=np.empty((len(times),6));j=0
    for i,t in enumerate(times):
        while j<len(arcs)-1 and t>arcs[j].t1+1e-11:j+=1
        vals[i]=arcs[j].values(float(t))
    return times,vals

def variation_metrics(arcs,dt=.01):
    ts,ys=sample_arcs(arcs,10.,dt=dt);jumps=[];events=[]
    for left,right in zip(arcs,arcs[1:]):
        if left.t1<=10:
            eps=min(1e-8,max(1e-12,(left.t1-left.t0)/1000),(right.t1-right.t0)/1000)
            pl=left.values(max(left.t0,left.t1-eps))[2]
            pr=right.values(min(right.t1,right.t0+eps))[2]
            jumps.append(abs(pl-pr));events.append((left.t1,'arc_handover',pl,pr,abs(pl-pr)))
    for a in arcs:
        for t,kind in internal_events(a):
            if t<=10:
                eps=min(1e-8,(t-a.t0)/1000,(a.t1-t)/1000)
                pl=a.values(t-eps)[2];pr=a.values(t+eps)[2]
                jumps.append(abs(pl-pr));events.append((t,kind,pl,pr,abs(pl-pr)))
    metrics={'accel_TV10_grid':float(np.sum(np.abs(np.diff(ys[:,2])))),
             'largest_recorded_mode_jump':max(jumps,default=0.),
             'recorded_jump_count_above_1e_minus6':sum(j>1e-6 for j in jumps)}
    return metrics,ts,ys,events

def episode_constraints(arcs,p):
    """Check the full accepted episode, including integration nodes and faces."""
    blocks=[]
    for a in arcs:
        if isinstance(a,SpaceArc):
            ss=np.unique(np.r_[np.linspace(a.s0,a.s1,513),
                               [s for s in a.P.knots if a.s0<=s<=a.s1]])
            if a.sol is not None:ss=np.unique(np.r_[ss,a.sol.t,(a.sol.t[1:]+a.sol.t[:-1])/2])
            blocks.append(np.array([a.values_s(float(s)) for s in ss]))
        elif a.sol is None:blocks.append(np.array([a.values(a.t0)]))
        else:
            tt=np.unique(np.r_[np.linspace(a.t0,a.t1,1001),a.sol.t,(a.sol.t[1:]+a.sol.t[:-1])/2])
            blocks.append(np.array([a.values(float(t)) for t in tt]))
    vals=np.vstack(blocks);d,v,acc,u,k,slack=vals.T
    h=d-p.gamma*v-p.eps
    am=np.array([p.a(float(dd),float(vv)) for dd,vv in zip(d,v)])
    L=np.maximum(am-p.U,-10*v)
    R=np.minimum.reduce([am+p.U,(-v+10*h)/p.gamma,10*(p.M-v)])
    return {'episode_min_h':float(min(h)),'episode_min_v':float(min(v)),
            'episode_min_speed_margin':float(min(p.M-v)),
            'episode_max_input_excess':float(max(abs(u)-p.U)),
            'episode_min_cbf_interval_width':float(min(R-L)),
            'episode_validation_samples':len(vals)}

def run_case(P,task,h0,v0,nom,method,fine=False,save_trace=False):
    p=P.p;start=time.perf_counter();theta=THETAS.get(method,math.nan)
    if method in THETAS:
        arcs=rate_episode(P,nom,theta,fine=fine);entered=True
        W,lower_hit=P.worst(theta,fine=fine)
        rate_bound=P.Tstar/math.sqrt(theta)
        residual_upper,residual_lower=P.certificate(theta)
    else:
        arcs,entered=time_episode(P,task,method,nom,fine=fine)
        W=lower_hit=rate_bound=residual_upper=residual_lower=math.nan
    episode_arcs=list(arcs);end=arcs[-1].t1
    entry_time=end if entered else math.nan
    episode_integrals=sum((integrate_arc(a,p,task,fine=fine) for a in episode_arcs),np.zeros(6))
    if entered and end<10:
        vals=arcs[-1].values(end);post=continuation(P,task,nom,end,vals[:2],fine=fine)
        if post is not None:arcs.append(post)
    J10=sum((integrate_arc(a,p,task,end=10.,fine=fine) for a in arcs if a.t0<10),np.zeros(6))
    # Variation on the common ten-unit horizon; mode jumps are retained.
    variation,ts,ys,events=variation_metrics(arcs,dt=.005 if fine else .01)
    h=ys[:,0]-p.gamma*ys[:,1]-p.eps
    sampled_slack=ys[:,5]
    entryratio=entry_time/P.Tstar if entered else math.nan
    row={'plant':p.name,'task':task,'h0':h0,'v0':v0,'nominal':nom.kind,'method':method,'theta':theta,
         'fine':fine,'status':'entered' if entered else 'not_entered_by_600','entry_time':entry_time,'T_star':P.Tstar,
         'entry_ratio':entryratio,'W_theta':W,'simple_bound':rate_bound,'bound_ratio':entry_time/W if entered and math.isfinite(W) else math.nan,
         'lower_profile_hit_s':lower_hit,'floor_upper_residual_min':residual_upper,'floor_lower_residual_min':residual_lower,
         'J10':float(J10[0]),'effort10':float(J10[1]),'L1_intervention10':float(J10[2]),'L2_intervention10':float(J10[3]),
         'accel_RMS10':math.sqrt(max(0.,J10[4])/10),
         'progress_slack_integral10':float(J10[5]),'progress_slack_max10':float(max(sampled_slack)),
         'progress_slack_fraction10':float(np.mean(sampled_slack>1e-8)),
         'episode_cost':float(episode_integrals[0]),'episode_L1_intervention':float(episode_integrals[2]),
         'episode_L2_intervention':float(episode_integrals[3]),'episode_accel_RMS':math.sqrt(max(0,episode_integrals[4])/end),
         'common_grid_min_h':float(min(h)),'common_grid_min_v':float(min(ys[:,1])),
         'common_grid_min_speed_margin':float(min(p.M-ys[:,1])),
         'common_grid_max_input_excess':float(max(np.abs(ys[:,3])-p.U)),
         'mode_arcs':len(episode_arcs),'offline_profile_seconds':P.offline_seconds,
         'case_seconds_including_metrics':time.perf_counter()-start}
    row.update(variation)
    row.update(episode_constraints(episode_arcs,p))
    if min(row['episode_min_h'],row['episode_min_v'],row['episode_min_speed_margin']) < -2e-6 or row['episode_max_input_excess']>2e-6:
        raise RuntimeError('Accepted episode violates a physical constraint beyond 2e-6')
    if method in THETAS:
        samples=np.unique(np.r_[np.linspace(0,P.S,1001),P.knots])
        tube=[]
        for a in episode_arcs:
            if isinstance(a,SpaceArc):
                for s in samples[(samples>=a.s0)&(samples<=a.s1)]:tube.append(a.energy(s)-theta*P.E(s))
        row['sampled_floor_residual_min']=min(tube,default=0.)
    else:row['sampled_floor_residual_min']=math.nan
    if save_trace:
        ident=f'{p.name}_{task}_h{h0:g}_v{v0:g}_{nom.kind}_{method}'+('_fine' if fine else '')
        np.savez_compressed(ROOT/'data'/f'trace_{ident}.npz',t=ts,values=ys,fields=np.array(['d','v','acceleration','u','k','progress_slack']))
    return row

def case_key(row):return (row['plant'],row['task'],float(row['h0']),float(row['v0']),row['nominal'],row['method'])

def group_worker(job):
    plant_name,task,h0,v0,nomkind,fine,legacy,methods=job
    p=next(p for p in PLANTS if p.name==plant_name)
    hg=0. if task=='gap' else .2
    P=Profile(p,p.eps+h0+p.gamma*v0,v0,p.eps+hg+.01,fine=fine)
    nom=Nominal(p,task,nomkind,Path(legacy));rows=[]
    for method in methods:
        try:row=run_case(P,task,h0,v0,nom,method,fine=fine,save_trace=(not fine and p.name=='C2' and h0==.8 and v0==0))
        except Exception as exc:
            raise RuntimeError(f'{plant_name} {task} h={h0} v={v0} {nomkind} {method} fine={fine}: {exc}') from exc
        rows.append(row)
    return rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--legacy',type=Path,default=ROOT.parent/'manuscript/numerics')
    ap.add_argument('--smoke',action='store_true');ap.add_argument('--all',action='store_true');ap.add_argument('--render-only',action='store_true')
    ap.add_argument('--resume',action='store_true');ap.add_argument('--workers',type=int,default=4)
    args=ap.parse_args()
    if args.render_only:render();return
    if args.smoke:
        p=PLANTS[1];task='tracking';h0=.8;v0=0.;P=Profile(p,p.eps+h0,v0,p.eps+.2+.01)
        rows=[]
        for nomkind in NOMINALS:
            nom=Nominal(p,task,nomkind,args.legacy)
            for method in ['ordinary_cbf','recovery_cbf','progress_r0500','rate_025','rate_100']:
                r=run_case(P,task,h0,v0,nom,method,save_trace=True);rows.append(r)
                print(nomkind,method,r['entry_time'],r['entry_ratio'],r['J10'],r['sampled_floor_residual_min'],flush=True)
        csvwrite('smoke.csv',rows);return
    if not args.all:ap.error('Use --smoke, --all, or --render-only')
    from concurrent.futures import ProcessPoolExecutor,as_completed
    start=time.perf_counter();rows=csvread('episodes.csv') if args.resume and (ROOT/'data/episodes.csv').exists() else []
    refinement=csvread('refinement.csv') if args.resume and (ROOT/'data/refinement.csv').exists() else []
    done={case_key(r) for r in rows};done_fine={case_key(r) for r in refinement};profiles=[];jobs=[]
    for p in PLANTS:
      for task in ['gap','tracking']:
       hg=0. if task=='gap' else .2
       for h0,v0 in INITIALS:
        d0=p.eps+h0+p.gamma*v0;target=p.eps+hg+.01
        P=Profile(p,d0,v0,target)
        profile_row={'plant':p.name,'task':task,'h0':h0,'v0':v0,'T_star':P.Tstar,'ceiling_hit_s':P.hit,'offline_seconds':P.offline_seconds}
        for th in [.1,.25,.5,1.]:
            ru,rl=P.certificate(th);W,hit=P.worst(th)
            profile_row[f'theta{th:g}_upper_residual']=ru;profile_row[f'theta{th:g}_lower_residual']=rl
            profile_row[f'theta{th:g}_W']=W
        profiles.append(profile_row);csvwrite('profiles.csv',profiles)
        for nomkind in NOMINALS:
         key0=(p.name,task,h0,v0,nomkind)
         todo=[m for m in METHODS if (*key0,m) not in done]
         if todo:jobs.append((p.name,task,h0,v0,nomkind,False,str(args.legacy.resolve()),todo))
         todo_fine=[m for m in METHODS if (m in THETAS or (h0==.8 and v0==0)) and (*key0,m) not in done_fine]
         if todo_fine:jobs.append((p.name,task,h0,v0,nomkind,True,str(args.legacy.resolve()),todo_fine))
    jobs.sort(key=lambda j:(j[5],PLANTS.index(next(p for p in PLANTS if p.name==j[0])),j[1],j[2],j[3],j[4]))
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(group_worker,j):j for j in jobs}
        for future in as_completed(futures):
            job=futures[future]
            try:batch=future.result()
            except Exception as exc:
                jsonwrite('failure.json',{'job':job,'error':str(exc)})
                for f in futures:f.cancel()
                raise
            if job[5]:refinement.extend(batch);csvwrite('refinement.csv',refinement)
            else:rows.extend(batch);csvwrite('episodes.csv',rows)
            print(f'COMPLETE {job[:6]}: base={len(rows)} fine={len(refinement)}, {time.perf_counter()-start:.1f}s',flush=True)
    jsonwrite('environment.json',{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),
                                 'wall_seconds':time.perf_counter()-start,'base_episodes':len(rows),'refined_episodes':len(refinement),
                                 'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'workers':args.workers})
    summarize();render()

def summarize():
    from analyze_v6 import summarize as run_summary
    run_summary()
def render():
    from analyze_v6 import render as run_render
    run_render()

if __name__=='__main__':main()
