#!/usr/bin/env python3
"""Refresh only variation/jump extraction after the independent metric audit.

Trajectory parameters and input laws are unchanged. All event times, both
one-sided accelerations, and jump magnitudes are exported for independent review.
"""
import csv,json,time,hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from run_v6 import ROOT,PLANTS,Profile,Nominal,THETAS,rate_episode,time_episode,continuation,variation_metrics,csvwrite

def worker(job):
    ident,rr,fine=job
    p=next(p for p in PLANTS if p.name==ident[0]);task=ident[1];h0,v0=map(float,ident[2:4]);kind=ident[4]
    hg=0 if task=='gap' else .2
    P=Profile(p,p.eps+h0+p.gamma*v0,v0,p.eps+hg+.01,fine=fine)
    nom=Nominal(p,task,kind,ROOT.parent/'manuscript/numerics');out=[];ledger=[]
    for row in rr:
        m=row['method']
        if m in THETAS:arcs=rate_episode(P,nom,THETAS[m],fine=fine);entered=True
        else:arcs,entered=time_episode(P,task,m,nom,fine=fine)
        end=arcs[-1].t1
        if entered and abs(end-float(row['entry_time']))>2e-8:raise RuntimeError('Metric refresh changed entry time')
        if entered and end<10:
            vals=arcs[-1].values(end);post=continuation(P,task,nom,end,vals[:2],fine=fine)
            if post is not None:arcs.append(post)
        metrics,ts,ys,events=variation_metrics(arcs,dt=.005 if fine else .01)
        row.pop('recorded_jump_count_above_1e6',None);row.update(metrics)
        row['progress_slack_fraction10']=float(np.mean(ys[:,5]>1e-8))
        row['progress_slack_max10']=float(max(ys[:,5]))
        out.append(row)
        for t,event,pl,pr,jump in events:
            ledger.append({'plant':p.name,'task':task,'h0':h0,'v0':v0,'nominal':kind,'method':m,'fine':fine,
                           'time':t,'event':event,'acceleration_left':pl,'acceleration_right':pr,'absolute_jump':jump})
        if not fine and p.name=='C2' and h0==.8 and v0==0:
            ident2=f'{p.name}_{task}_h{h0:g}_v{v0:g}_{kind}_{m}'
            np.savez_compressed(ROOT/'data'/f'trace_{ident2}.npz',t=ts,values=ys,fields=np.array(['d','v','acceleration','u','k','progress_slack']))
    return out,ledger,fine

def main():
    start=time.perf_counter();jobs=[]
    for file,fine in [('episodes.csv',False),('refinement.csv',True)]:
        rows=list(csv.DictReader((ROOT/'data'/file).open()));groups={}
        for r in rows:
            ident=tuple(r[k] for k in ['plant','task','h0','v0','nominal']);groups.setdefault(ident,[]).append(r)
        jobs.extend((i,rr,fine) for i,rr in groups.items())
    base=[];refined=[];ledger=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        for fut in as_completed([pool.submit(worker,j) for j in jobs]):
            out,events,fine=fut.result();(refined if fine else base).extend(out);ledger.extend(events)
    csvwrite('episodes.csv',base);csvwrite('refinement.csv',refined);csvwrite('acceleration_event_ledger.csv',ledger)
    env=json.loads((ROOT/'environment.json').read_text())
    env['variation_metric_refresh_seconds']=time.perf_counter()-start
    env['variation_refresh_scope']='Only TV/jump extraction, sampled slack frequency and corresponding saved traces changed; event-aware grids include progress-ceiling kinks, profile knots and all arc handovers. All entry times rechecked against original production values.'
    env['source_sha256_after_metric_correction']=hashlib.sha256((ROOT/'run_v6.py').read_bytes()).hexdigest()
    (ROOT/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
    from analyze_v6 import summarize,render
    summarize();render()
    print('Refreshed',len(base),len(refined),'rows;',len(ledger),'recorded events;',time.perf_counter()-start,'seconds')
if __name__=='__main__':main()
