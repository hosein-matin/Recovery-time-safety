#!/usr/bin/env python3
"""Python profile preparation and supplied-state kernel costs, not real-time bounds."""
from pathlib import Path
import argparse,csv,json,time,statistics,hashlib
import numpy as np
from run_v6 import ROOT,PLANTS,Nominal,Profile,controller,clip

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--legacy',type=Path,default=ROOT.parent/'manuscript/numerics');args=ap.parse_args()
    prep=[];kernels=[]
    for p in PLANTS:
      for task in ['gap','tracking']:
        hg=0. if task=='gap' else .2
        for h0,v0 in [(.4,0.),(.8,0.),(.8,.4)]:
            stamps=[]
            for _ in range(5):
                start=time.perf_counter_ns();P=Profile(p,p.eps+h0+p.gamma*v0,v0,p.eps+hg+.01);stamps.append((time.perf_counter_ns()-start)/1e6)
            prep.append({'plant':p.name,'task':task,'h0':h0,'v0':v0,'median_profile_ms':statistics.median(stamps),'min_profile_ms':min(stamps),'max_profile_ms':max(stamps)})
        P=Profile(p,p.eps+.8,0.,p.eps+hg+.01)
        ss=np.linspace(P.S/256,P.S*(255/256),128)
        # A fixed mixture of floor states and strict tube interior states.
        points=[]
        for j,s in enumerate(ss):
            E=.25*P.E(s) if j%2==0 else .6*P.E(s)
            points.append((P.clock(s)/.5,P.d0-s,np.sqrt(2*E)))
        for n in ['hjb','zero_input','zero_accel','opposing']:
            nom=Nominal(p,task,n,args.legacy)
            funcs={m:(lambda t,d,v,m=m:controller(p,task,m,nom,t,d,v)[0]) for m in ['ordinary_cbf','recovery_blend','recovery_cbf','progress_r0500']}
            def rate(t,d,v):
                s=P.d0-d;E=.5*v*v;q=.25*P.E(s);pn=p.a(d,v)+nom(t,d,v)
                if E<=q+1e-12:pn=max(pn,.25*P.derivative(s))
                if E>=p.B(d)-1e-12:pn=min(pn,p.Bprime(d))
                return pn
            funcs['rate_025_kernel']=rate
            for name,fun in funcs.items():
                for point in points:fun(*point)
                samples=[];checksum=0.
                for _ in range(7):
                    begin=time.perf_counter_ns()
                    for repeat in range(4):
                        for point in points:checksum+=fun(*point)
                    samples.append((time.perf_counter_ns()-begin)/(4*len(points))/1000)
                kernels.append({'plant':p.name,'task':task,'nominal':n,'kernel':name,'median_microseconds_per_call':statistics.median(samples),'min_microseconds_per_call':min(samples),'max_microseconds_per_call':max(samples),'checksum':checksum})
    for name,rows in [('profile_preparation_timing.csv',prep),('controller_kernel_timing.csv',kernels)]:
        with (ROOT/'data'/name).open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    result={'profile_ms_median':statistics.median(r['median_profile_ms'] for r in prep),
            'profile_ms_min':min(r['median_profile_ms'] for r in prep),'profile_ms_max':max(r['median_profile_ms'] for r in prep),
            'kernel_medians_microseconds':{m:statistics.median(r['median_microseconds_per_call'] for r in kernels if r['kernel']==m) for m in sorted(set(r['kernel'] for r in kernels))},
            'scope':'Sequential Python microbenchmark: dense-output profile+clock preparation, and scalar supplied-state controller evaluation. Rate kernel includes frozen-profile interpolation and boundary tests; excludes event location, a sampled-data implementation, and guarantee of hard real-time latency. All kernels use identical supplied states within each plant/task/nominal. Mixed 50% floor/50% strict interior. Do not compare simulation-with-metrics runtime to online CBF costs.',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'timing_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
