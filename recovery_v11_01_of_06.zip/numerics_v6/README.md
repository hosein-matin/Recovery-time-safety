# V6 numerical study: episode recovery with a quantified floor

This directory contains a new, reproducible experiment for the V6 revision. It is separate from the earlier V5 experiment and its integration count. `protocol.json` fixed the plants, states, nominals, gains, comparison methods and refinement set before production. No controller gain was selected using these outcomes.

## Reproduce

Use Python 3.12 with NumPy, SciPy, Matplotlib and pypdf. The tested versions are recorded in `environment.json` and `requirements.txt`. From the revision directory:

```bash
python3 numerics_v6/run_v6.py --all --workers 4 --legacy manuscript/numerics
python3 numerics_v6/benchmark_v6.py --legacy manuscript/numerics
```

The six frozen HJB policy files are read from `manuscript/numerics/policies/`; their names are `Cj__w5_stopped__gap__medium.npz` and `Cj__w5_stopped__tracking__medium.npz`, for j=1,2,3. The accompanying legacy directory retains the original HJB construction, metadata and objective definitions. V6 does not retrain or tune these policies. `provenance.json` records hashes of the actual input files and final scripts.

`--smoke` runs a 20-case diagnostic; it is not the study. `--all --resume` resumes completed rows by their unique plant/task/state/nominal/method key. `--render-only` redraws figures from saved rows. `analyze_v6.py` recomputes all summary files, tables, validation summaries and figures without solving a trajectory. The final `run_v6.py` includes the independently requested event-aware variation correction. `refresh_variation.py` documents the one-time correction of variation/jump extraction after initial production; it changes no input law and checks that entry times agree with the initial production values. Running the final main script from scratch needs no correction pass.

## Dynamics, units and cases

The benchmark uses normalized variables and the stopped-leader plant

\[
\dot d=-v,\qquad \dot v=a(d,v)+u,\qquad |u|\le5,
\quad a(d,v)=\alpha\{V(d)-v\}.
\]

The safety set is \(v\in[0,M]\), \(h=d-\gamma v-\epsilon\ge0\), with \(M=1.96\), \(\epsilon=.02\). Thus the physical speed ceiling is \(\bar v(d)=\min\{M,(d-\epsilon)/\gamma\}\). These are mathematical fixtures; physical units and a validated road-vehicle comfort threshold are not asserted.

| Plant | alpha | gamma | V(d) |
|---|---:|---:|---|
| C1 | 2.6 | .2 | tanh(d)-tanh(2) |
| C2 | 1 | .3 | tanh(d)-tanh(2) |
| C3 | 2.6 | .35 | clip(.8(d-.1),0,1.5) |

Every plant uses both task settings. The gap task has \(h_g=0,\lambda=2\); tracking has \(h_g=.2,\lambda=.1\). Both use \(\eta=.01\). Entry is the first time that the **physical gap** satisfies \(d\le d_\eta=\epsilon+h_g+\eta\), with free terminal velocity. This is not a minimum-time terminal-rest problem. Each task has three initial pairs \((h_0,v_0)=(.4,0),(.8,0),(.8,.4)\), with \(d_0=\epsilon+h_0+\gamma v_0\).

There are four actuator-input nominals:

1. **HJB:** the same frozen trilinearly interpolated finite-horizon policy for every method in a given plant/task. Its terminal table is zero, so extension by zero for \(t\ge10\) is continuous. No HJB solve is charged to one controller and excluded from another.
2. **Zero input:** \(k=0\). The plant drift remains active, which can launch C3 by itself.
3. **Cancelled net acceleration:** \(k=\operatorname{clip}(-a,-U,U)\). It gives zero net nominal acceleration only where exact cancellation is actuator-feasible; the clipped definition is used everywhere.
4. **Opposing input:** \(k=-U\), an actuator command, not constant net acceleration.

This gives 3 plants x 2 tasks x 3 states x 4 nominals = 72 matched episodes per method. All 13 methods are retained, for **936 base episodes**. All 288 rate-profile cases and all 216 baseline cases with \((h_0,v_0)=(.8,0)\) are refined, for **504 refined episodes**. The entry horizon is 600. Every unentered case is retained and marked `not_entered_by_600`; no finite entry time is imputed. In a successful-case median for ordinary CBF, the denominator and number of nonentries must be reported.

## Controllers and comparison contract

All intervals below are net-acceleration intervals. Set \(p_n=a+k\) and

\[
L=\max\{a-U,-10v\},\qquad
R=\min\{a+U,(-v+10h)/\gamma,10(M-v)\}.
\]

The ordinary CBF selects \(p=\operatorname{clip}(p_n,L,R)\). The old recovery blend and recovery CBF use the same published-in-draft constants \(N=50,s_h=1,s_v=M,h_s=.2\), with

\[
\rho=\frac{(h-h_g)_+}{.2+(h-h_g)_+},\quad
r_\lambda=\frac{-v+\lambda\rho(M-v)}{\gamma},\qquad u_b=\operatorname{clip}(r_\lambda-a,-U,U),
\]

\[
\beta=\tanh(50v_+/M),\quad u_r=\beta k+(1-\beta)u_b,
\quad \sigma=\tanh(50h_+)\tanh(50(M-v)_+/M).
\]

The blend applies \(u=\sigma u_r+(1-\sigma)u_b\); recovery CBF projects \(a+u_r\) onto \([L,R]\). These are the established comparison methods; they were not retuned for the new entry objective.

The **strong progress-CBF baseline** protects the one-sided speed deficit relative to \(v_r(d)=r\bar v(d)\). It asks for

\[
p\ge p_{\rm req}=-r v\bar v'(d)+c(r\bar v(d)-v).
\]

The priority is safety, minimum nonnegative progress slack, then nominal fidelity:

\[
\zeta=\max\{p_{\rm req}-R,0\},\qquad
p=\operatorname{clip}\{p_n,\max(L,\min(p_{\rm req},R)),R\}.
\]

Its fixed main grid is \(r\in\{\sqrt{.1},.5,\sqrt{.5},1\},c=5\); sensitivity cases add \(c=2,10\) at \(r=.5\). The slope of \(\bar v\) is zero on the speed cap and \(1/\gamma\) on the headway face; the resulting progress-control acceleration jump at the kink is explicitly located and included in variation/jump extraction. This is a transparent CLF/CBF-style instantiation, not a claim to reproduce a particular ACC paper's complete controller. A zero observed slack means that the stated progress inequality held along that tested episode. It is not a new global feasibility proof for all states. These controllers add interior progress constraints and therefore do not automatically belong to the theorem's strict tube-interior-fidelity class.

The **reflected rate filter** uses \(\theta=.1,.25,.5\), with \(q(s)=\theta E^+(s;z_0)\) prepared once from the episode's initial state, \(s=d_0-d\). Its net acceleration equals \(p_n\) in the strict tube interior. At \(E=q\), it is \(\max(p_n,q')\); at the original upper ceiling \(B(s)=\bar v(d_0-s)^2/2\), it is \(\min(p_n,B')\). The code integrates this reflected trajectory and its nonwaiting physical clock. It does not project an integrated physical state onto a feasible set. The \(\theta=1\) endpoint follows \(E^+\) itself and is labelled the optimal-profile endpoint, not an interior-fidelity tradeoff point. There is no online reset or recomputation of the reference profile.

The analytic OVM certificate in the companion establishes feasibility of every scaled profile for these fixtures. Sampled numerical certificate residuals are an implementation check, not the proof. For these fixtures, the maximum profile follows \(A_+\) until first ceiling contact and then follows the admissible ceiling. This fixture-specific implementation should not be substituted for the general reflected ODE without checking its conditions.

## Common continuation and metric definitions

Every method uses its named controller until first entry. At entry, **every method switches to the same recovery-CBF law**, with the case's nominal, \(h_g\), and \(\lambda\), until the common horizon 10. If a method has not entered by time 10, its episode controller continues. Thus common-horizon cost compares an episode policy plus an identical handover rule. It is not the unchanged V5 all-time controller cost. Entry time is unaffected by the handover. Because terminal speed is free, the optimal entry profile can penetrate farther after entry while the common controller brakes.

`entry_time` is \(T\). `T_star` is the spatially computed minimum physical-gap-entry time from the same initial state. `entry_ratio` is \(T/T^*\). `W_theta` is the exact comparison clock of the lower-reflected \(A_-\) profile with the same initial energy. `simple_bound` is \(T^*/\sqrt\theta\); `bound_ratio` is \(T/W_\theta\). From rest, these two upper bounds coincide for the certified fixtures. With initial speed .4, \(W_\theta\) is strictly smaller. Opposing-input equality is expected by the theory and partly built into the reflected construction; its numerical attainment verifies implementation consistency and is not independent evidence proving the theorem.

`J10` integrates the declared task running cost over \([0,10]\):

\[
J_{10}^{\rm gap}=\int_0^{10}(.2u^2+50d^2)\,dt,\qquad
J_{10}^{\rm track}=\int_0^{10}(.2u^2+v^2+5(h-.2)^2)\,dt.
\]

`effort10` is \(\int_0^{10}u^2dt\); `L1_intervention10` is \(\int_0^{10}|u-k|dt\); `L2_intervention10` is \(\int_0^{10}(u-k)^2dt\). `episode_cost` and `episode_L1_intervention`/`episode_L2_intervention` use \([0,T]\) for entered episodes and \([0,600]\) for censored episodes. Censored episode integrals must not be compared as if they covered equal durations. For a persistent opposing input, a shorter episode can reduce the entry-only intervention integral even when instantaneous intervention is stronger. The common-horizon metrics provide the complementary comparison.

`accel_RMS10` is \(\sqrt{\frac1{10}\int_0^{10}p^2dt}\), where \(p=\dot v\) is net acceleration. `episode_accel_RMS` uses the episode interval. `accel_TV10_grid` is the **numerical grid proxy** \(\sum_i|p(t_{i+1})-p(t_i)|\), with grid spacing .01 (refined .005), plus all known profile knots, progress-ceiling kink crossings, arc/handover times, and samples on both sides of these events. It is not a certified exact total variation. `largest_recorded_mode_jump` is the largest observed one-sided acceleration difference at these known discontinuity events. The event ledger supplies each time, event type, left acceleration, right acceleration, and magnitude; differences use offsets at most \(10^{-8}\). `recorded_jump_count_above_1e_minus6` counts event jumps exceeding \(10^{-6}\). Smooth saturation switches can change derivatives without an acceleration jump.

The hard reflected controller is allowed to have acceleration jumps. No intrinsic finite jerk norm or sampled-data safety theorem is asserted. Acceleration RMS and variation are descriptive signal metrics, not validated human-comfort ratings. A hypothetical actuator smoothing stage would change the controller and require a new analysis.

Progress slack integral and maximum use \([0,10]\). All progress episodes in this matrix enter before 10; the common post-entry controller has no progress constraint, and its slack record is zero. `progress_slack_fraction10` is the **fraction of sampled points** with slack greater than \(10^{-8}\), on the event-augmented grid; it is not an exact time-duration fraction. Therefore the integral and maximum are the primary slack measures.

## Numerical implementation and validation

The energy profile and clock use DOP853, tolerances \(2\cdot10^{-9}\) relative and \(2\cdot10^{-11}\) absolute, with maximum spatial steps \(S/256\) and clock-coordinate steps \(\sqrt S/256\). Refined tolerances are \(2\cdot10^{-11}\) and \(2\cdot10^{-13}\), with 512 steps. The launch singularity is removed with \(s=x^2\). For a nominal that initially points strictly above the floor, a physical-time nominal launch of \(10^{-5}\) (refined \(10^{-6}\)) is integrated first, then the coupled energy/clock system is used. Boundary release is located by a scan of 1,024 spatial intervals (refined 2,048), with profile knots included, followed by a bracketed scalar root solve. This is an event resolution method for the benchmark matrix, not a universal event-completeness proof for arbitrary oscillatory nominals.

Ordinary/recovery/progress controllers use Radau at relative/absolute tolerances \(2\cdot10^{-8},2\cdot10^{-10}\), maximum time step .5. Refinement uses \(2\cdot10^{-10},2\cdot10^{-12}\), maximum .25. The common continuation uses maximum steps .05/.025. A standard actuator-saturated ambient extension defines baseline vector fields on implicit solver trial states outside the safe set; it is inactive on admissible states. No accepted physical state is clipped. Exact ordinary-CBF rest equilibria with time-independent nominals are retained as stationary arcs, rather than integrated with thousands of unnecessary zero steps.

Cost integrals use adaptive vector quadrature; profile and HJB knots are supplied where available. The accepted trajectory safety checks cover integration nodes, their midpoints, profile knots and additional dense samples over the entire episode, not just the common ten-unit horizon. Constraints, rate-floor residuals, all 504 refinement comparisons, and observed entry-status agreement are reported in `summary.json` and `data/refinement_comparison.csv`. Sampled residuals support the numerical implementation; the manuscript's analytic conditions supply the guarantees.

`case_seconds_including_metrics` is offline simulation-and-analysis runtime, including solver work, quadrature, and part of the metric extraction. It is not online controller latency. `benchmark_v6.py` separately measures sequential profile preparation and supplied-state scalar controller kernels; it includes frozen-profile interpolation for the reflected kernel. The latter excludes event location and a sampled-data realization, uses the same supplied states for every kernel, and gives no real-time worst-case bound. No claim is made that scalar CBF interval projection is computationally expensive.

## Deliverables and interpretation

- `data/episodes.csv`: all 936 base outcomes with no discarded failures.
- `data/refinement.csv` and `data/refinement_comparison.csv`: 504 refined outcomes and matched errors.
- `data/profiles.csv`: 18 initial-state/task profiles, exact comparison clocks and certificate checks.
- `data/acceleration_event_ledger.csv`: event-aware acceleration discontinuity records.
- `data/summary_by_method.csv` and `data/summary_by_method_nominal.csv`: all 13 methods and all four nominals.
- `data/paired_rate025_progress0500.csv`: task-specific paired comparisons with the strong progress baseline, retaining unfavorable results.
- `data/trace_*.npz`: reproducible C2 representative trajectories, with explicit field names.
- `summary.json`: numerical findings and validation summaries used in paper text.
- `tables/*.tex`: generated full-method, nominal-specific, sharpness and slack tables.
- `figures/*.pdf`: vector scientific figures, accompanied by PNG previews and a caption index.
- `timing_summary.json`: profile/kernel benchmark scope and results.

The intended contribution is a quantified recovery/fidelity theorem, demonstrated against meaningful alternatives. The progress-CBF baseline is frequently faster at matched nominal parameter values and can have better cost; it should not be described as dominated. Ordinary CBF is a safety-only baseline and is not required to recover for arbitrary nominals. C3's positive drift can make ordinary CBF recover without an added recovery design, which is explicitly retained in the study. The exact \(W_\theta\) comparison, the rest-start worst-case equality, the moving-start strictness, robustness to adverse nominals, and the measured acceleration/performance tradeoffs are the supported numerical messages.
