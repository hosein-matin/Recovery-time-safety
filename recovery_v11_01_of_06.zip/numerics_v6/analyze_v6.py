#!/usr/bin/env python3
"""Deterministic tables and vector figures from the locked V6 episode study."""
from pathlib import Path
import csv,json,math,hashlib,sys,os
import numpy as np
os.environ.setdefault('MPLCONFIGDIR','/tmp/ecc_v6_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent
METHODS=['ordinary_cbf','recovery_blend','recovery_cbf','progress_r0316','progress_r0500','progress_r0707','progress_r1000','progress_c2','progress_c10','rate_010','rate_025','rate_050','rate_100']
SHORT={'ordinary_cbf':'CBF','recovery_blend':'Blend','recovery_cbf':'Rec. CBF','progress_r0316':'Prog. .316','progress_r0500':'Prog. .5','progress_r0707':'Prog. .707','progress_r1000':'Prog. 1','progress_c2':'Prog. c=2','progress_c10':'Prog. c=10','rate_010':r'$\theta=.1$','rate_025':r'$\theta=.25$','rate_050':r'$\theta=.5$','rate_100':'Optimum'}
TEX={'ordinary_cbf':'Ordinary CBF','recovery_blend':'Recovery blend','recovery_cbf':'Recovery CBF','progress_r0316':r'Progress $r=\sqrt{.1}$','progress_r0500':'Progress $r=.5$','progress_r0707':r'Progress $r=\sqrt{.5}$','progress_r1000':'Progress $r=1$','progress_c2':'Progress $r=.5,c=2$','progress_c10':'Progress $r=.5,c=10$','rate_010':r'Reflected $\theta=.1$','rate_025':r'Reflected $\theta=.25$','rate_050':r'Reflected $\theta=.5$','rate_100':'Optimal profile'}
NOMINALS=['hjb','zero_input','zero_accel','opposing']
NOM={'hjb':'Frozen HJB','zero_input':'Zero actuator input','zero_accel':'Cancelled net acceleration','opposing':'Opposing actuator input'}
COLORS={'ordinary_cbf':'#707070','recovery_blend':'#be7838','recovery_cbf':'#9470a9','progress_r0316':'#d17523','progress_r0500':'#d17523','progress_r0707':'#d17523','progress_r1000':'#d17523','progress_c2':'#b04d22','progress_c10':'#b04d22','rate_010':'#477fc0','rate_025':'#287999','rate_050':'#096a70','rate_100':'#111111'}

def read(name):
    rows=list(csv.DictReader((ROOT/'data'/name).open()))
    for r in rows:
        for k,v in list(r.items()):
            try:r[k]=float(v)
            except (TypeError,ValueError):pass
    return rows
def write(name,rows):
    if not rows:return
    with (ROOT/'data'/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def finite(x):return isinstance(x,(float,int)) and math.isfinite(x)
def vals(rows,key):return np.array([r[key] for r in rows if finite(r.get(key))])
def statistics(rows,key):
    x=vals(rows,key)
    return {'n':len(x),'min':float(min(x)) if len(x) else None,'median':float(np.median(x)) if len(x) else None,'max':float(max(x)) if len(x) else None}
def select(rows,**kwargs):return [r for r in rows if all(r.get(k)==v for k,v in kwargs.items())]
def key(r):return tuple(r[k] for k in ['plant','task','h0','v0','nominal','method'])
def texnum(x,d=2):return f'{x:.{d}f}' if finite(x) else '--'
def texwrite(name,lines):(ROOT/'tables'/name).write_text('\n'.join(lines)+'\n')

def summarize():
    rows=read('episodes.csv');fine=read('refinement.csv');profiles=read('profiles.csv')
    methods=[];by_nominal=[]
    for m in METHODS:
        a=select(rows,method=m);s={'method':m,'n':len(a),'entered':sum(r['status']=='entered' for r in a)}
        for metric in ['entry_ratio','J10','L1_intervention10','episode_L1_intervention','accel_RMS10','accel_TV10_grid','largest_recorded_mode_jump','progress_slack_max10','progress_slack_fraction10']:
            for stat,v in statistics(a,metric).items():
                if stat!='n':s[f'{metric}_{stat}']=v
        methods.append(s)
        for n in NOMINALS:
            a=select(rows,method=m,nominal=n);d={'method':m,'nominal':n,'n':len(a),'entered':sum(r['status']=='entered' for r in a)}
            for metric in ['entry_ratio','J10','episode_L1_intervention','accel_RMS10','accel_TV10_grid']:
                for st,v in statistics(a,metric).items():
                    if st!='n':d[f'{metric}_{st}']=v
            by_nominal.append(d)
    write('summary_by_method.csv',methods);write('summary_by_method_nominal.csv',by_nominal)
    pair_index={key(r):r for r in rows};paired=[]
    for task in ['gap','tracking','all']:
        a=[r for r in rows if r['method']=='rate_025' and (task=='all' or r['task']==task)]
        for metric in ['entry_time','J10','L1_intervention10','episode_L1_intervention','accel_RMS10','accel_TV10_grid']:
            ratios=[]
            for r in a:
                other=pair_index[key(r)[:-1]+('progress_r0500',)]
                ratios.append(r[metric]/other[metric])
            paired.append({'task':task,'metric':metric,'n':len(a),'rate_lower':sum(x<1-1e-6 for x in ratios),
                           'rate_higher':sum(x>1+1e-6 for x in ratios),'ratio_min':min(ratios),
                           'ratio_median':float(np.median(ratios)),'ratio_max':max(ratios)})
    write('paired_rate025_progress0500.csv',paired)
    base={key(r):r for r in rows};ref=[]
    for f in fine:
        b=base[key(f)];r={k:f[k] for k in ['plant','task','h0','v0','nominal','method']};r['status_matches']=b['status']==f['status']
        for metric in ['entry_time','T_star','W_theta','J10','L1_intervention10','episode_L1_intervention','accel_RMS10','accel_TV10_grid','largest_recorded_mode_jump']:
            bv,fv=b.get(metric),f.get(metric)
            r[f'{metric}_absolute_error']=abs(bv-fv) if finite(bv) and finite(fv) else math.nan
            r[f'{metric}_relative_error']=abs(bv-fv)/max(abs(fv),1e-10) if finite(bv) and finite(fv) else math.nan
        ref.append(r)
    write('refinement_comparison.csv',ref)
    rr=[r for r in rows if r['method'].startswith('rate_')];opp=select(rr,nominal='opposing')
    moving=[r for r in opp if r['v0']>0 and r['theta']<1]
    rest=[r for r in opp if r['v0']==0 and r['theta']<1]
    summary={'base_episodes':len(rows),'refined_episodes':len(fine),'cases_per_method':72,'methods':methods,'by_nominal':by_nominal,
             'paired_rate025_vs_progress0500':paired,
             'rate':{'episodes':len(rr),'entered':sum(r['status']=='entered' for r in rr),
                     'max_T_over_W':max(r['bound_ratio'] for r in rr),
                     'opposing_max_abs_T_over_W_minus_1':max(abs(r['bound_ratio']-1) for r in opp),
                     'rest_max_abs_T_over_simple_bound_minus_1':max(abs(r['entry_time']/r['simple_bound']-1) for r in rest),
                     'moving_min_relative_simple_bound_slack':min((r['simple_bound']-r['W_theta'])/r['simple_bound'] for r in moving),
                     'moving_max_relative_simple_bound_slack':max((r['simple_bound']-r['W_theta'])/r['simple_bound'] for r in moving),
                     'floor_residual_min':min(r['sampled_floor_residual_min'] for r in rr),
                     'floor_upper_certificate_residual_min':min(r['floor_upper_residual_min'] for r in rr),
                     'floor_lower_certificate_residual_min':min(r['floor_lower_residual_min'] for r in rr)},
             'constraints':{k:min(r[k] for r in rows) for k in ['episode_min_h','episode_min_v','episode_min_speed_margin','episode_min_cbf_interval_width']},
             'constraint_max_input_excess':max(r['episode_max_input_excess'] for r in rows),
             'refinement':{'status_disagreements':sum(not r['status_matches'] for r in ref)},
             'profiles':profiles,'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest()}
    for metric in ['entry_time','T_star','W_theta','J10','L1_intervention10','episode_L1_intervention','accel_RMS10','accel_TV10_grid','largest_recorded_mode_jump']:
        summary['refinement'][metric+'_max_absolute_error']=statistics(ref,metric+'_absolute_error')['max']
        summary['refinement'][metric+'_max_relative_error']=statistics(ref,metric+'_relative_error')['max']
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    assert len(rows)==936 and len(fine)==504
    assert len(set(key(r) for r in rows))==936
    assert summary['rate']['max_T_over_W']<1+1e-5
    assert summary['refinement']['status_disagreements']==0
    tables(rows,methods,by_nominal,summary)
    return summary

def tables(rows,methods,by_nominal,summary):
    chosen=['ordinary_cbf','recovery_blend','recovery_cbf','progress_r0500','rate_025','rate_100']
    lines=[r'\begin{tabular}{lrrrr}',r'\toprule',r'Method & HJB & Zero input & Net zero & Opposing \\',r'\midrule']
    for m in chosen:
        cells=[]
        for n in NOMINALS:
            r=next(r for r in by_nominal if r['method']==m and r['nominal']==n)
            cells.append(f"{texnum(r['entry_ratio_median'])} ({int(r['entered'])}/18)")
        lines.append(TEX[m]+' & '+' & '.join(cells)+r' \\')
    lines +=[r'\bottomrule',r'\end{tabular}']
    texwrite('main_entry_ratios.tex',lines)
    lines=[r'\begin{tabular}{lrrrrrr}',r'\toprule',r'Method & Entry & $T/T^*$ med. & $T/T^*$ max. & $J_{10}$ med. & $I_{10}$ med. & $\widehat{\rm TV}_{10}(p)$ med. \\',r'\midrule']
    for r in methods:
        lines.append(f"{TEX[r['method']]} & {int(r['entered'])}/72 & {texnum(r['entry_ratio_median'])} & {texnum(r['entry_ratio_max'])} & {texnum(r['J10_median'])} & {texnum(r['L1_intervention10_median'])} & {texnum(r['accel_TV10_grid_median'])}"+r' \\')
    lines +=[r'\bottomrule',r'\end{tabular}'];texwrite('all_methods.tex',lines)
    lines=[r'\begin{tabular}{lrrrrrr}',r'\toprule',r'Method & $T/T^*$ & $J_{10}$ & $I_{\rm ent}$ & ${\rm RMS}_{10}(p)$ & $\widehat{\rm TV}_{10}(p)$ & $\zeta_{\max}$ \\',r'\midrule']
    case=select(rows,plant='C2',task='tracking',h0=.8,v0=0.,nominal='opposing')
    for m in METHODS:
        r=next(r for r in case if r['method']==m)
        cells=[texnum(r[k]) for k in ['entry_ratio','J10','episode_L1_intervention','accel_RMS10','accel_TV10_grid','progress_slack_max10']]
        if r['status']!='entered':cells[2]+=r'$^{\dagger}$'
        lines.append(TEX[m]+' & '+' & '.join(cells)+r' \\')
    lines +=[r'\bottomrule',r'\end{tabular}'];texwrite('opposing_case.tex',lines)
    lines=[r'\begin{tabular}{llrrrr}',r'\toprule',r'Plant & Task & $T^*$ & $W_{.1}$ & $W_{.25}$ & $W_{.5}$ \\',r'\midrule']
    for p in ['C1','C2','C3']:
      for task in ['gap','tracking']:
        a=select(rows,plant=p,task=task,h0=.8,v0=.4,nominal='opposing')
        x=next(r for r in a if r['method']=='rate_100')
        cells=[texnum(x['T_star'],4)]+[texnum(next(r for r in a if r['method']==m)['W_theta'],4) for m in ['rate_010','rate_025','rate_050']]
        lines.append(p+' & '+task+' & '+' & '.join(cells)+r' \\')
    lines +=[r'\bottomrule',r'\end{tabular}'];texwrite('moving_exact_bounds.tex',lines)
    lines=[r'\begin{tabular}{lrrr}',r'\toprule',r'Progress setting & Slack-free episodes & Maximum slack & Median sampled fraction \\',r'\midrule']
    for m in METHODS:
        if not m.startswith('progress'):continue
        a=select(rows,method=m)
        lines.append(TEX[m]+f" & {sum(r['progress_slack_max10']<1e-8 for r in a)}/72 & {max(r['progress_slack_max10'] for r in a):.3f} & {np.median([r['progress_slack_fraction10'] for r in a]):.3f}"+r' \\')
    lines +=[r'\bottomrule',r'\end{tabular}'];texwrite('progress_slack.tex',lines)
    labels={'entry_time':r'Entry $T$','J10':r'Cost $J_{10}$','L1_intervention10':r'Intervention $I_{10}$',
            'episode_L1_intervention':r'Entry intervention $I_{\rm ent}$','accel_RMS10':r'Acceleration RMS',
            'accel_TV10_grid':r'Grid variation $\widehat{\rm TV}_{10}$'}
    lines=[r'\begin{tabular}{lrrrr}',r'\toprule',r'Quantity & Gap: lower/36 & Gap ratio & Tracking: lower/36 & Tracking ratio \\',r'\midrule']
    for metric,label in labels.items():
        aa=[next(r for r in summary['paired_rate025_vs_progress0500'] if r['task']==t and r['metric']==metric) for t in ['gap','tracking']]
        lines.append(label+' & '+' & '.join(f"{r['rate_lower']}/36 & {r['ratio_median']:.3f}" for r in aa)+r' \\')
    lines +=[r'\bottomrule',r'\end{tabular}'];texwrite('paired_rate025_progress0500.tex',lines)

def style():
    plt.rcParams.update({'font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,
                         'legend.fontsize':7,'font.family':'DejaVu Sans','pdf.fonttype':42,'ps.fonttype':42,
                         'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18,
                         'savefig.bbox':'tight','savefig.pad_inches':.03})
def save(fig,name):
    fig.savefig(ROOT/'figures'/f'{name}.pdf');fig.savefig(ROOT/'figures'/f'{name}.png',dpi=180)
    assert len(PdfReader(ROOT/'figures'/f'{name}.pdf').pages)==1
    plt.close(fig)

def render():
    style();rows=read('episodes.csv')
    main=['ordinary_cbf','recovery_blend','recovery_cbf','progress_r0500','rate_010','rate_025','rate_050','rate_100']
    fig,axs=plt.subplots(2,2,figsize=(7.1,4.6),sharey=True)
    for ax,n in zip(axs.flat,NOMINALS):
        for j,m in enumerate(main):
            a=select(rows,method=m,nominal=n);y=vals(a,'entry_ratio');jitter=np.linspace(-.18,.18,len(y))
            ax.scatter(j+jitter,y,s=10,color=COLORS[m],alpha=.6,zorder=3)
            if len(y):ax.plot([j-.25,j+.25],[np.median(y)]*2,color=COLORS[m],lw=2.2)
            fails=len(a)-len(y)
            if fails:ax.text(j,1600,f'{fails}/18\nno entry',ha='center',va='top',fontsize=6.3,color='#a33b39')
        ax.set_yscale('log');ax.set_ylim(.85,1900);ax.set_title(NOM[n]);ax.set_xticks(range(len(main)))
        ax.set_xlim(-.55,len(main)-.45)
        ax.set_xticklabels([SHORT[m] for m in main],rotation=55,ha='right');ax.axhline(1,color='k',lw=.5)
        ax.set_ylabel(r'Entry time $T/T^*$');ax.set_yticks([1,2,5,10,50,100,500,1000]);ax.set_yticklabels(['1','2','5','10','50','100','500','1000'])
    fig.tight_layout(h_pad=1.4,w_pad=.6);save(fig,'entry_ratios')
    fig,axs=plt.subplots(1,2,figsize=(7.1,2.55))
    ms=['rate_010','rate_025','rate_050'];nomcolors=['#774699','#218c84','#bd8532','#d24e3a']
    for i,m in enumerate(ms):
        for j,n in enumerate(NOMINALS):
            a=select(rows,method=m,nominal=n);v=[r['bound_ratio'] for r in a]
            xx=np.linspace(i-.25+j*.13,i-.18+j*.13,len(v));axs[0].scatter(xx,v,s=10,alpha=.65,color=nomcolors[j],label=NOM[n] if i==0 else None)
    axs[0].axhline(1,color='k',ls='--',lw=.8);axs[0].set_xticks(range(3));axs[0].set_xticklabels([r'$\theta=.1$',r'$\theta=.25$',r'$\theta=.5$'])
    axs[0].set_ylabel(r'Observed $T/W_\theta$');axs[0].set_ylim(.25,1.04);axs[0].legend(loc='lower left',fontsize=6.3)
    axs[0].set_title('Nominal-uniform exact bound')
    for p,c in zip(['C1','C2','C3'],['#366fa5','#be7131','#328875']):
      for task,linestyle in [('gap','-'),('tracking','--')]:
        a=[next(r for r in rows if r['plant']==p and r['task']==task and r['v0']==.4 and r['nominal']=='opposing' and r['method']==m) for m in ms]
        y=[100*(1-r['W_theta']/r['simple_bound']) for r in a]
        axs[1].plot([.1,.25,.5],y,marker='o',ms=3,lw=1,color=c,ls=linestyle,label=p+' '+task)
    axs[1].set_xticks([.1,.25,.5]);axs[1].set_xlabel(r'Floor fraction $\theta$');axs[1].set_ylabel(r'$(1-W_\theta\sqrt{\theta}/T^*)\,100\%$')
    axs[1].set_title('Moving starts: conservative simple bound');axs[1].legend(ncol=2,fontsize=6)
    fig.tight_layout(w_pad=2);save(fig,'sharpness')
    fig,axs=plt.subplots(2,2,figsize=(7.1,4.35),sharex=False)
    for ax,(task,n) in zip(axs.flat,[(t,n) for t in ['gap','tracking'] for n in ['hjb','opposing']]):
        a=select(rows,plant='C2',task=task,h0=.8,v0=0.,nominal=n)
        for methods,color,marker,label in [(['rate_010','rate_025','rate_050','rate_100'],'#267ca0','o','Reflected floor'),(['progress_r0316','progress_r0500','progress_r0707','progress_r1000'],'#c0762b','s','Progress CBF, c=5')]:
            aa=[next(r for r in a if r['method']==m) for m in methods]
            ax.plot([r['entry_ratio'] for r in aa],[r['episode_L1_intervention'] for r in aa],marker=marker,ms=4,color=color,label=label)
        for m,mark in [('progress_c2','v'),('progress_c10','^')]:
            r=next(r for r in a if r['method']==m);ax.scatter(r['entry_ratio'],r['episode_L1_intervention'],marker=mark,facecolor='none',edgecolor='#c0762b',s=25,label='Progress '+m.split('_')[1] if ax is axs[0,0] else None)
        ax.set_title(task.capitalize()+'; '+NOM[n]);ax.set_xlabel(r'Entry time $T/T^*$');ax.set_ylabel(r'Entry intervention $\int_0^T|u-k|\,dt$')
    axs[0,0].legend(fontsize=6);fig.tight_layout(w_pad=1,h_pad=1);save(fig,'time_intervention_tradeoff')
    fig,axs=plt.subplots(1,2,figsize=(7.1,2.5))
    for ax,n in zip(axs,['hjb','opposing']):
        case=select(rows,plant='C2',task='tracking',h0=.8,v0=0.,nominal=n)
        for mm,c,marker,label in [(['rate_010','rate_025','rate_050','rate_100'],'#267ca0','o','Reflected floor'),(['progress_r0316','progress_r0500','progress_r0707','progress_r1000'],'#c0762b','s','Progress CBF, c=5')]:
            aa=[next(r for r in case if r['method']==m) for m in mm]
            ax.plot([r['entry_ratio'] for r in aa],[r['L1_intervention10'] for r in aa],marker=marker,ms=4,color=c,label=label)
        ax.set_title('Tracking; '+NOM[n]);ax.set_xlabel(r'Entry time $T/T^*$');ax.set_ylabel(r'Common intervention $\int_0^{10}|u-k|\,dt$')
    axs[0].legend(fontsize=6);fig.tight_layout(w_pad=1);save(fig,'common_intervention_tradeoff')
    fig,axs=plt.subplots(2,2,figsize=(7.1,4.25),sharex=True)
    trace_ms=['ordinary_cbf','recovery_cbf','progress_r0500','rate_025','rate_100']
    for m in trace_ms:
        z=np.load(ROOT/'data'/f'trace_C2_tracking_h0.8_v0_opposing_{m}.npz');t=z['t'];v=z['values'];sel=t<=4
        for ax,col in zip(axs.flat,[0,1,2,3]):ax.plot(t[sel],v[sel,col],color=COLORS[m],label=SHORT[m],lw=1)
    axs[0,0].axhline(.23,color='k',ls='--',lw=.6);axs[0,0].set_ylabel('Physical gap d');axs[0,1].set_ylabel('Speed v')
    axs[1,0].set_ylabel('Acceleration p');axs[1,1].set_ylabel('Actuator input u')
    for ax in axs[1]:ax.set_xlabel('Time');
    axs[0,0].legend(fontsize=6);fig.tight_layout(w_pad=1);save(fig,'opposing_trace')
    fig,axs=plt.subplots(1,3,figsize=(7.1,2.45))
    case=select(rows,plant='C2',task='tracking',h0=.8,v0=0.,nominal='opposing')
    for ax,metric,ylabel in zip(axs,['J10','accel_RMS10','accel_TV10_grid'],[r'Common-horizon cost $J_{10}$',r'Acceleration RMS on $[0,10]$',r'Acceleration TV on $[0,10]$']):
        for mm,c,marker,label in [(['rate_010','rate_025','rate_050','rate_100'],'#267ca0','o','Reflected'),(['progress_r0316','progress_r0500','progress_r0707','progress_r1000'],'#c0762b','s','Progress CBF')]:
            aa=[next(r for r in case if r['method']==m) for m in mm]
            ax.plot([r['entry_ratio'] for r in aa],[r[metric] for r in aa],marker=marker,ms=4,color=c,label=label)
        ax.set_xlabel(r'Entry time $T/T^*$');ax.set_ylabel(ylabel)
    axs[0].legend(fontsize=6);fig.tight_layout(w_pad=.8);save(fig,'performance_variation_tradeoff')
    (ROOT/'figures'/'figure_index.json').write_text(json.dumps({'entry_ratios':'All 18 states/tasks per nominal; dots are successes, labels count all cases unentered by 600; bars are successful-case medians.',
       'sharpness':'All 216 nonendpoint rate cases versus W; six moving-state curves show strictness of simple bound. Exact rest equality is in summary/table.',
       'time_intervention_tradeoff':'Matched fixed grids θ=.1,.25,.5,1 and r=sqrt(.1),.5,sqrt(.5),1; main progress gain c=5 and hollow gain-sensitivity symbols c=2,10 at r=.5. Points can coincide under HJB. Same C2 rest state; entry-only intervention. No post-hoc tuning.',
       'common_intervention_tradeoff':'Same C2 tracking rest state; intervention integrated on the common horizon 10, including common post-entry controller.',
       'opposing_trace':'C2 tracking rest opposing nominal. Common recovery-CBF continuation after each method enters. Window 0–4 does not display old filter eventual entry.',
       'performance_variation_tradeoff':'Same C2 tracking opposing case, common horizon 10 and common post-entry controller.'},indent=2)+'\n')

if __name__=='__main__':
    summarize();render()
