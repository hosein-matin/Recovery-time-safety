#!/usr/bin/env python3
"""Serialized replay of all decisions in a declared16-case stress subset."""
from pathlib import Path
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import sys,json,time,platform
import numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import fixed_period as fp
import importlib.util
_spec=importlib.util.spec_from_file_location('fixed_experiment_run_matrix',ROOT/'run_matrix.py')
rm=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(rm)
STRESS=[('C3','gap',.4,'hjb'),('C3','gap',0.,'opposing'),('C1','gap',0.,'opposing'),('C2','tracking',.4,'hjb')]

def main():
    rows=[];times={};allrecords=[];started=time.perf_counter()
    paths=sorted((ROOT/'data'/'cases').glob('*.json'))
    for path in paths:
        saved=json.loads(path.read_text());c=saved['case']
        if (c['plant'],c['task'],c['v0'],c['nominal']) not in STRESS:continue
        if saved['row']['status']!='entered':raise RuntimeError('Incomplete source case')
        p=next(p for p in fp.b.PLANTS if p.name==c['plant'])
        C=fp.constants(p,c['v0'],c['theta'],c['task']);cert=fp.stored_certificate(p,c['v0'],c['theta'],c['dt'])
        nom=fp.b.Nominal(p,c['task'],c['nominal'],ROOT.parent/'manuscript'/'numerics')
        pre=[r for r in saved['trace'] if r['mode']!='tail']
        # Prime all residual matrix/transcendental caches and code paths with one
        # complete first decision; these warm-up timings are not retained.
        r=pre[0];z=np.array([r['d'],r['v']]);w=np.array([r['sample_radius_d'],r['sample_radius_v']])
        fp.select(p,C,cert,z,w,r['t'],nom,c['dt'],.001,initial_rest=(c['v0']==0.))
        vals=[];modes=[]
        for i,r in enumerate(pre):
            z=np.array([r['d'],r['v']]);w=np.array([r['sample_radius_d'],r['sample_radius_v']])
            start=time.perf_counter()
            H,we,info,ncalls,rej=fp.select(p,C,cert,z,w,r['t'],nom,c['dt'],.001,initial_rest=(i==0 and c['v0']==0.))
            elapsed=(time.perf_counter()-start)*1000
            if H.u!=r['u'] or info['mode']!=r['mode']:
                raise RuntimeError(f'Replay changed a decision in {path.name} at {i}')
            vals.append(elapsed);modes.append(info['mode'])
        ident=path.stem;times[ident]=vals
        rows.append({**c,'case_id':ident,'decision_count':len(vals),'mean_ms':float(np.mean(vals)),
            'p50_ms':float(np.median(vals)),'p95_ms':float(np.percentile(vals,95)),'max_ms':max(vals)})
        allrecords.extend({'period':c['dt'],'mode':m,'milliseconds':t,'case_id':ident} for m,t in zip(modes,vals))
        print(json.dumps(rows[-1]),flush=True)
    assert len(rows)==16,len(rows)
    pooled=[]
    for period in [.01,.025]:
        vals=np.array([r['milliseconds'] for r in allrecords if r['period']==period])
        pooled.append({'period':period,'count':len(vals),'mean_ms':float(np.mean(vals)),
            'p50_ms':float(np.median(vals)),'p95_ms':float(np.percentile(vals,95)),'max_ms':float(np.max(vals))})
    result={'status':'complete','all_decisions_reproduced_exactly':True,'stress_cases':STRESS,'rows':rows,'pooled':pooled,
        'decision_samples':allrecords,'wall_seconds':time.perf_counter()-started,'environment':rm.environment(1),
        'source_sha256':fp.sha(Path(__file__)),'scope':'single-process serial replay, all pre-entry decisions from16 declared stress episodes; no production pool running; preloaded policy/certificate, one warmup decision per episode',
        'included':'nominal evaluation, witness lookup, held-flow proposal(s), continuous residual enclosure, full-hold acceptance and fallback selection',
        'excluded':'offline certificate/profile generation, file/policy loading, warmup, diagnostics and cost quadrature, post-entry tail',
        'claim':'elapsed implementation runtimes only; no hard real-time or dimensional sample-period deadline claim'}
    (ROOT/'serial_timing.json').write_text(json.dumps(rm.safe(result),indent=2,allow_nan=False)+'\n')
    print(json.dumps(pooled,indent=2),flush=True)

if __name__=='__main__':main()
