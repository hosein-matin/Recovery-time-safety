V11 FIXED-PERIOD NOMINAL-FIRST / STORED-WITNESS EXPERIMENTS
========================================================

This is the new192-run experiment requested by the Round5 review. It directly
exercises periods0.01 and0.025 on the full96-configuration matrix, including
HJB. The periods are normalized model time. Historical V7 cases and code are
not overwritten; matched historical .05 comparisons are labelled explicitly.

Start with:
  METHOD.txt                  proof/implementation scope and exact-decimal bridge
  protocol.json               matrix and numerical protocol fixed before runs
  summary.json / summary.csv   generated results and comparison counts
  audit_results.json          result invariants plus deliberately straddled kinks
  serial_timing.json          separate serial online-decision replay evidence
  environment.json            production environment, compiler, source/policy hashes
  reference_clock_summary.json exact reflected-clock diagnostics and rigorous lower bounds
  provenance/clock_correction.json reporting correction with unchanged-trace fingerprints
  quadrature_sensitivity.json  tighter six-case metric diagnostic replay

Main retained data:
  data/cases/*.json            all192 cases, complete holds/branches/enclosures
  data/episodes.csv            full run-level rows
  data/run_summary.json        retained failures (none), actual production runtime
  certificates/               new .01 tables/report; original .025 tables are read
                              from ../sampling_certificate after hash verification
  matched_pairs_full_precision.csv
  matched_search_comparisons.csv
  nominal_theta_summary.csv

Ready-to-integrate assets:
  figures/fixed_period_overview.pdf  7.10in by2.10in, three-panel main-paper option
  figures/fixed_period_overview.png
  figures/fixed_period_overview_caption.txt
  tables/fixed_period_overview.tex   compact two-row alternative to the figure
  tables/historical_comparison.tex  detailed notes comparison (different periods)
  paper_paragraph.tex               concise main-paper wording
  notes_subsection.tex              detailed notes wording
Use the figure OR the overview table as the primary main-paper vehicle; the
notes can include the detailed comparison. The CSV/JSON values are authoritative.

Reproduction from this directory:
  ./build_outward.sh
  python prepare_certificates.py
  python run_matrix.py --workers 3
  python benchmark_serial.py
  python audit_results.py
  python analyze_results.py

Dependencies are the same as numerics_v7/requirements.txt. The inherited
mpmath1.3.0 source is vendored in ../numerics_v7/vendor. The primary runtime
used NumPy2.3.5 and SciPy1.17.0; environment.json gives the full runtime.
The optional C loop is built only in this directory, from the unchanged
../numerics_v7/outward_loop.c with -std=c99 -O2 -fPIC -shared -fno-fast-math
-ffp-contract=off. If absent, the outward Python propagation path is used;
it will be slower. The released driver always recomputes requested cases;
it never reuses a source-only cache. Copy or move data/cases aside before a
fresh reproduction if the retained production evidence should be preserved.
The archived first production driver is provenance/production_run_matrix.py.
The retained production source is provenance/production_fixed_period.py.
Its only subsequent change is reference-clock reporting: future runs use the
correct lower-reflected Wtheta, while the retained output was corrected by
recompute_reference_clocks.py without altering any trace or non-clock field.
Case source hashes identify actual production; reporting hashes are separate.
The audit checks both. Do not rerun the correction script on new production
with unrelated source hashes; it is specifically for the retained first run.

Controller summary
------------------
1. The sampled nominal is clipped to[-5,5] and proposed for the full fixed hold.
2. The gate is for the physical hold of Theorem7, not the smaller spatial
   prefix set I_Delta. Continuous residual tubes, exact-decimal constraints, the frozen profile and
   explicit positive-launch guard decide acceptance. A stored one-sided floor
   comparison can prove a contact/rest floor that a rectangular tube cannot.
3. Otherwise, use the stored Proposition8 floor or ceiling witness only after
   its opposite-clearance test passes for the ENTIRE carried sample enclosure.
   If an enclosure straddles cells, recompute commands AND budgets on their
   union. Failure would be retained; no adaptive halving is hidden.
4. Track continuous entry separately from sampled detection; continue the
   historical sampled safety tail for cost diagnostics to model time10.

No finite set of ordinary trajectory samples is treated as a certificate.
Minimum diagnostic margins, ODE roots, costs and motion remain numerical
diagnostics. Full-hold acceptance and interval entry brackets have separate
proof records. The enclosures cover numerical/roundoff errors; there is no
additional sensing-noise or computation-delay guarantee. Parallel production
timings are not used as real-time evidence. Serial replay includes the stated
online work and excludes offline loading/warmup; no hard deadline is asserted.

Principal result
----------------
192/192 enter with no shortened pre-entry hold and no unresolved witness.
Maximum T/Wtheta is below0.990619 at.01 and0.980558 at.025
(values rounded upward). All independent
entry-upper/Wtheta-lower checks pass. Earlier-entry counts against historical
.05 search are21/96 and28/96; the reviewer's52-53/72 suggestion is not
reproduced. The code and reporting were not tuned to force that conjecture.

Reference-clock distinction
--------------------------
Wtheta denotes the lower-reflected Aminus recovery clock with initial E0.
Only rest starts give Wtheta=Tstar/sqrt(theta). For moving starts the latter
is the distinct simple_factor_bound field. The rigorous Wtheta_lower uses
an upper energy envelope max(q,E0+m*s), m>=alpha*V(d0)-U<0, together with
full-cell profile bounds and downward Riemann summation. See METHOD.txt for
the proof and the transparent reporting-correction provenance.

Independent review closure
--------------------------
The fresh independent reviewer checked all24 corrected reference groups and
all192 reporting receipts. Independent65-digit envelope sums validate the
reflected W lower construction; all original non-clock evidence is unchanged.
See ../../reviews/fresh_clock_repair_checks.json and fresh_numerical_audit.txt.
The physical-hold versus spatial-prefix distinction is explicit above and in
METHOD. The final evidence report is ../../reviews/fixed_period_numerics.txt.
The final serial timings were collected before the reporting-only correction;
all online control definitions are syntax-tree identical. The compiled .so is
a local build product and is excluded from the portable SHA256 manifest.
