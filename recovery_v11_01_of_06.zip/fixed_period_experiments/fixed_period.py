#!/usr/bin/env python3
"""V11 nominal-first, otherwise stored Proposition8 witness controller.

This module does not change or reuse any saved V7 control decision. The nominal
inner test is a continuous residual-tube check. The fallback is selected from
rigorous stored boundary enclosures by outward clearance tests on the carried
sample-state enclosure. Ordinary ODE/quadrature values are labelled diagnostics.
See METHOD.txt for the induction, exact-decimal correction, and limits.
"""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction
from dataclasses import dataclass
import os,sys,math,time,json,hashlib,ctypes
import numpy as np
from scipy.optimize import brentq

ROOT=Path(__file__).resolve().parent
V7=ROOT.parent/'numerics_v7';SC=ROOT.parent/'sampling_certificate'
sys.path.insert(0,str(V7))
import certified_zoh as cz
b=cz.base;cr=cz.cr
cr.iv.dps=40
# Optional identical outward propagation kernel, built in this experiment only.
try:
    lib=ctypes.CDLL(str(ROOT/'outward_loop.so'))
    arr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    lib.propagate_cells.argtypes=[ctypes.c_size_t,arr,arr,arr,arr,arr,arr]
    lib.propagate_cells.restype=None
    cz._lib=lib
except OSError:
    pass

EPS=2.**-40
MODEL_DOMAIN=(-1.,3.)
DECIMAL={'C1':('2.6','.2'),'C2':('1','.3'),'C3':('2.6','.35')}

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dec(s):return tuple(np.asarray(x) for x in cr.ivfloat(cr.iv.mpf(str(s))))
def lo_float(x):return float(cr.lo(x))
def hi_float(x):return float(cr.hi(x))
def dfloat(a):return (float(a[0]),float(a[1]))
def nonneg(a):return (np.maximum(0.,a[0]),np.maximum(0.,a[1]))
def sum_upper(a):
    a=np.asarray(a,float)
    assert np.all(a>=0.) and np.all(np.isfinite(a))
    return hi_float(float(np.sum(a))/(1.-len(a)*np.finfo(float).eps)) if len(a) else 0.

@dataclass
class Constants:
    alpha:tuple;gamma:tuple;eps:tuple;M:tuple;theta:tuple;r:tuple
    x0:tuple;d0:tuple;v0:tuple;target:tuple
    v_perturbation:float;model_perturbation_proved_upper:float


def constants(p,v0,theta,task):
    aa,gg=DECIMAL[p.name]
    ai=dec(aa);gi=dec(gg);ei=dec('.02');mi=dec('1.96');vi=dec('0' if v0==0 else '.4')
    thi=dec('.25' if theta==.25 else '.5')
    ri=cr.ivfloat(cr.iv.sqrt(cr.iv.mpf('.25' if theta==.25 else '.5')))
    xi=cr.add(dec('.8'),cr.mul(gi,vi));di=cr.add(ei,xi)
    ti=cr.add(ei,dec('.01' if task=='gap' else '.21'))
    # Difference of exact-decimal and binary64 reference vector fields on
    # d,v in [-1,3]. Clipping is 1-Lipschitz. The residual receives EPS>=bound.
    a=cr.iv.mpf(aa);ab=cr.iv.mpf(float(p.alpha))
    da=abs(a-ab)
    if p.name=='C3':
        beta=cr.iv.mpf('.8');betab=cr.iv.mpf(float(.8))
        off=cr.iv.mpf('.1');offb=cr.iv.mpf(float(.1))
        dv=abs(beta-betab)*(3+abs(off))+abs(betab)*abs(off-offb)
        dafield=da*cr.iv.mpf('4.5')+a*dv
    else:
        dv=cr.iv.mpf(0);dafield=da*5
    vb=float(cr.ivfloat(dv)[1]);bound=float(cr.ivfloat(dafield)[1])
    assert bound<EPS
    return Constants(ai,gi,ei,mi,thi,ri,xi,di,vi,ti,vb,bound)


def exact_v_range(p,C,dl,du):
    vr=cr.V_range(p,dl,du)
    if C.v_perturbation:vr=cr.add(vr,(-C.v_perturbation,C.v_perturbation))
    return vr


def ceiling(C,x):
    x=nonneg(x)
    vl,vu=cr.divpos(x,C.gamma)
    vl=np.minimum(C.M[0],vl);vu=np.minimum(C.M[1],vu)
    return cr.scale(cr.square((vl,vu)),.5)


@dataclass
class Witness:
    j0:int;j1:int;k:int;uq:float;uB:float;HB:float;Hq:float
    xlo:float;xhi:float

class StoredCertificate:
    def __init__(self,p,v0,theta,period):
        self.p=p;self.v0=v0;self.theta=theta;self.period=period
        vs='0' if v0==0 else '.4';ts='.25' if theta==.25 else '.5'
        ds='.01' if period==.01 else '.025'
        directory=ROOT/'certificates' if period==.01 else SC
        self.path=directory/f'certificate_{p.name}_v{vs}_theta{ts}_delta{ds}.npz'
        report=json.loads((ROOT/'certificates'/'generated_001_report.json').read_text()) if period==.01 else json.loads((SC/'certified_results_0025.json').read_text())
        row=next(r for r in report['rows'] if r['plant']==p.name and r['v0']==vs and r['theta']==ts)
        assert row['certified'] and sha(self.path)==row['detail_sha256']
        z=np.load(self.path)
        self.values=z['values'];self.Eup=z['E_cell_upper'];self.Elo=z['E_cell_lower'];self.phase=z['phase']
        self.Rq=z['Rq_upper'];self.RB=z['RB_lower'];self.zB=z['zB_upper'];self.zq=z['zq_upper']
        self.scale=10000;self.hi_h=hi_float(.0001)
        self.i0=int((Fraction('.8')+Fraction(DECIMAL[p.name][1])*Fraction(vs))*self.scale)
        self.n=len(self.Eup);self.nr=len(self.values)
        self._queries={}
        self.source_sha256=sha(self.path)
        # Checked for all rows during prepare_certificates, not inferred online.
        check=json.loads((ROOT/'certificates'/'generated_001_report.json').read_text())
        pr=next(r for r in check['prefix_clock_checks'] if r['plant']==p.name and r['v0']==vs and r['requested_period']==period)
        assert pr['all_prefixes_cover_binary64_period'] and pr['minimum_prefix_clock_lower']>=period

    def cell_range(self,xlo,xhi):
        a=cr.sub(cr.pt(self.i0),cr.scale(cr.pt(xhi),self.scale))[0]
        z=cr.sub(cr.pt(self.i0),cr.scale(cr.pt(xlo),self.scale))[1]
        return max(0,int(math.floor(float(a)))),min(self.n-1,max(0,int(math.floor(float(z)))))

    def upper_energy(self,C,xlo,xhi):
        j0,j1=self.cell_range(xlo,xhi)
        if j0>j1 or j0>=self.n:return math.inf
        # The maximal profile is separately bounded by the exact ceiling.
        return min(float(np.max(self.Eup[j0:j1+1])),float(ceiling(C,(xlo,xhi))[1]))

    def query(self,C,z,w):
        di=(cr.lo(z[0]-w[0]),cr.hi(z[0]+w[0]))
        xi=cr.sub(di,C.eps)
        if float(xi[0])<.002:raise RuntimeError('Sample enclosure exceeded certified profile extension')
        xl=float(xi[0]);xu=min(float(C.x0[1]),float(xi[1]))
        j0,j1=self.cell_range(xl,xu)
        if j0>=self.nr or j1>=self.nr:
            raise RuntimeError(f'Sample enclosure outside certified pre-entry position cells: {j0},{j1}/{self.nr}')
        key=(j0,j1)
        if key not in self._queries:
            k=int(np.max(self.values[j0:j1+1,1]))
            if j0==j1:
                rr=self.values[j0]
                uq,uB,HB,Hq=map(float,rr[4:8])
            else:
                uq=max(-self.p.U,float(np.max(self.Rq[j0:k])))
                uB=min(self.p.U,float(np.min(self.RB[j0:k])))
                if j0==0 and self.v0==0:uq=max(uq,float(self.values[0,4]))
                CB=np.maximum(0.,cr.hi(uq+self.zB[j0:k]))
                Cq=np.maximum(0.,cr.hi(self.zq[j0:k]-uB))
                HB=hi_float(self.hi_h*sum_upper(CB));Hq=hi_float(self.hi_h*sum_upper(Cq))
            assert -self.p.U<=uq<=self.p.U and -self.p.U<=uB<=self.p.U and k<=self.n
            self._queries[key]=(k,uq,uB,HB,Hq)
        k,uq,uB,HB,Hq=self._queries[key]
        return Witness(j0,j1,k,uq,uB,HB,Hq,float(xi[0]),float(xi[1]))

    def clock_lower(self,target_x):
        n=self.i0-int(Fraction(str(target_x))*self.scale)
        eup=self.Eup[:n]
        vv=cr.hi(np.sqrt(cr.hi(2*eup)))
        parts=cr.divpos(dec('.0001'),(vv,vv))[0]
        # Sum downward one term at a time; no unproved pairwise-sum correction.
        total=0.
        for x in parts:total=lo_float(total+float(x))
        return total


class VerifiedHold(cz.Hold):
    def __init__(self,p,z,u,dt,cell):
        super().__init__(p,z,u,dt,cell)
        self.residual[:,1]=cr.hi(self.residual[:,1]+EPS)


def evaluate_hold(H,C,cert,w0,*,floor_tangent=False,safety_only=False,band_proved=False):
    """Continuous enclosure plus exact-decimal constraint bounds.

    band_proved marks the stored-witness branch: the Prop8 proof supplies band
    invariance, while this routine still propagates the numerical state radius.
    """
    p=H.p
    initjump=cr.absolute_upper(cr.sub(cr.pt(H.c[0,:,0]),cr.pt(H.z)))
    wm,we=cz.propagate_all(p,H.hs,H.residual,H.jumps,cr.hi(w0+initjump))
    H.wm=wm;H.we=we
    wd,wv=wm[:,0],wm[:,1]
    dl=cr.lo(H.dr[0]-wd);du=cr.hi(H.dr[1]+wd)
    vl=cr.lo(H.vr[0]-wv);vu=cr.hi(H.vr[1]+wv)
    H.tube_dmin=float(np.min(dl));H.tube_dmax=float(np.max(du))
    broad_ok=bool(np.min(dl)>-1 and np.max(du)<3 and np.min(vl)>-1 and np.max(vu)<3)
    if not broad_ok:raise RuntimeError('Residual parameter-perturbation box exited')
    hc=cr.sub(cr.pt(H.c[:,0]),cr.mul(cr.pt(H.c[:,1]),C.gamma))
    hc=(hc[0].copy(),hc[1].copy())
    hc[0][:,0],hc[1][:,0]=cr.sub((hc[0][:,0],hc[1][:,0]),C.eps)
    hr=cr.brange_interval(hc)
    hl=cr.sub(cr.sub(hr,cr.pt(wd)),cr.mul(cr.pt(wv),C.gamma))[0]
    Ml=cr.sub(C.M,(vu,vu))[0]
    vmargin=float(np.min(vl))
    c0=cr.add(cr.mul(C.alpha,exact_v_range(p,C,dl,du)),cr.pt(H.u))[0]
    nonnegative_proof=bool(float(np.min(c0))>=0.)
    if nonnegative_proof or floor_tangent or band_proved:vmargin=max(0.,vmargin)
    floor_margin=math.inf
    if not safety_only:
        if floor_tangent or band_proved:floor_margin=0.
        else:
            # Analytic sufficient ceiling-floor branches (v >= r*min(M,x/g))
            # preserve correlation across each exact polynomial piece.
            dc=(H.c[:,0].copy(),H.c[:,0].copy())
            dc[0][:,0],dc[1][:,0]=cr.sub((dc[0][:,0],dc[1][:,0]),C.eps)
            rg=cr.divpos(C.r,C.gamma)
            gl=cr.sub(cr.pt(H.c[:,1]),cr.mul(dc,rg))
            linear=cr.sub(cr.sub(cr.brange_interval(gl),cr.pt(wv)),cr.mul(cr.pt(wd),rg))[0]
            capfloor=cr.sub(cr.sub(H.vr,cr.pt(wv)),cr.mul(C.r,C.M))[0]
            margins=[]
            for j in range(H.n):
                xi=cr.sub((dl[j],du[j]),C.eps)
                if float(xi[0])<.002:
                    margins.append(-math.inf);continue
                qu=cert.upper_energy(C,float(xi[0]),min(float(C.x0[1]),float(xi[1])))
                elo=cr.scale(cr.square(cr.pt(max(0.,float(vl[j])))),.5)
                em=float(cr.sub(elo,cr.mul(C.theta,cr.pt(qu)))[0])
                # Store velocity-scale lower bound, as in the inherited checker.
                evel=lo_float(em/max(1.,abs(float(vu[j]))+math.sqrt(max(0.,2*float(C.theta[1])*qu))))
                margins.append(max(evel,float(linear[j]),float(capfloor[j])))
            floor_margin=min(margins)
    extension_margin=math.inf if safety_only else float(cr.sub(cr.sub(cr.pt(H.tube_dmin),C.eps),dec('.002'))[0])
    raw_h=float(np.min(hl));raw_M=float(np.min(Ml))
    hmargin=max(0.,raw_h) if band_proved else raw_h
    Mmargin=max(0.,raw_M) if band_proved else raw_M
    ok=all(x>=0 for x in [hmargin,vmargin,Mmargin,floor_margin,extension_margin])
    info={'ok':ok,'h_margin':hmargin,'v_margin':vmargin,'M_margin':Mmargin,'floor_margin':floor_margin,
          'extension_margin':extension_margin,'tube_h_lower':raw_h,'tube_v_lower':float(np.min(vl)),
          'tube_M_lower':raw_M,'nonnegative_comparison':nonnegative_proof,'floor_tangent_comparison':floor_tangent,
          'band_by_stored_witness':band_proved,'max_radius_d':float(wd.max()),'max_radius_v':float(wv.max()),
          'endpoint_radius_d':float(we[0]),'endpoint_radius_v':float(we[1]),'cells':H.n}
    return ok,we,info


def clearances(C,cert,W,z,w):
    vl=max(0.,lo_float(z[1]-w[1]));vu=min(float(C.M[1]),hi_float(z[1]+w[1]))
    e=cr.scale(cr.square((vl,vu)),.5)
    B=ceiling(C,(max(0.,W.xlo),max(0.,W.xhi)))
    qu=cert.upper_energy(C,max(.002,W.xlo),min(float(C.x0[1]),W.xhi))
    upper=float(cr.sub((B[0],B[0]),(e[1],e[1]))[0])
    lower=float(cr.sub((e[0],e[0]),cr.mul(C.theta,cr.pt(qu)))[0])
    return upper,lower


def launch_guard(C,p,u):
    c=cr.add(cr.mul(C.alpha,exact_v_range(p,C,*C.d0)),cr.pt(p.U))
    required=cr.sub(cr.pt(p.U),cr.mul(cr.sub(cr.pt(1.),C.theta),c))
    margin=float(cr.sub(cr.pt(u),required)[0])
    return margin>=0.,margin


def select(p,C,cert,z,w,t,nom,dt,cell,initial_rest):
    W=cert.query(C,z,w)
    k=b.clip(float(nom(t,*z)),-p.U,p.U)
    guard,gm=launch_guard(C,p,k) if initial_rest else (True,math.inf)
    H=VerifiedHold(p,z,k,dt,cell)
    ok,we,info=evaluate_hold(H,C,cert,w,floor_tangent=(k>=W.uq))
    rejected=[]
    if not guard:rejected.append('rest_guard')
    rejected += [key for key in ['h_margin','v_margin','M_margin','floor_margin','extension_margin'] if info[key]<0]
    if ok and guard:
        info.update(mode='nominal',nominal_guard_margin=gm,witness_clearance_margin=None,
                    witness_j0=W.j0,witness_j1=W.j1,witness_k=W.k)
        return H,we,info,1,rejected
    uc,lc=clearances(C,cert,W,z,w)
    if W.uq<=W.uB:
        u=W.uq;mode='witness_overlap';margin=W.uB-W.uq
    elif uc>=W.HB:
        u=W.uq;mode='witness_floor';margin=lo_float(uc-W.HB)
    elif lc>=W.Hq:
        u=W.uB;mode='witness_ceiling';margin=lo_float(lc-W.Hq)
    else:
        raise RuntimeError(f'Unresolved robust witness at t={t}: upper {uc} < HB {W.HB}; lower {lc} < Hq {W.Hq}; z={z}; w={w}; cells={W.j0}:{W.j1}')
    if initial_rest:
        gok,gmargin=launch_guard(C,p,u)
        if not gok:raise RuntimeError('Stored rest witness failed positive-launch guard')
    else:gmargin=math.inf
    H=VerifiedHold(p,z,u,dt,cell)
    ok,we,info=evaluate_hold(H,C,cert,w,band_proved=True)
    if not ok:raise RuntimeError('Stored witness numerical enclosure exceeded profile extension')
    info.update(mode=mode,nominal_guard_margin=gm,applied_guard_margin=gmargin,
                witness_clearance_margin=margin,upper_clearance_lower=uc,lower_clearance_lower=lc,
                witness_HB=W.HB,witness_Hq=W.Hq,witness_j0=W.j0,witness_j1=W.j1,witness_k=W.k)
    return H,we,info,2,rejected


def tail_hold(p,C,cert,z,w,dt,cell):
    u0=-p.alpha*float(cz.V(p,z[0]))+(p.alpha-1/p.gamma)*z[1]
    u=u0
    for n in range(12):
        if not -p.U<=u<=p.U:raise RuntimeError('Tail input outside bounds')
        H=VerifiedHold(p,z,u,dt,cell)
        ok,we,info=evaluate_hold(H,C,cert,w,safety_only=True)
        if ok:
            info.update(mode='tail',tail_correction=abs(u-u0))
            return H,we,info,n+1
        cc=cr.mul(C.alpha,exact_v_range(p,C,H.tube_dmin,H.tube_dmin))
        need=hi_float(-float(cc[0])+1e-10)
        u=max(u,need)
    raise RuntimeError('Tail failed continuous safety check')


def polynomial_point_interval(H,j,tau,axis):
    r=cr.divpos(cr.pt(float(tau-H.ts[j])),cr.pt(float(H.hs[j])))
    val=cr.pt(H.c[j,axis,3])
    for k in [2,1,0]:val=cr.add(cr.mul(val,r),cr.pt(H.c[j,axis,k]))
    return cr.add(val,(-H.wm[j,axis],H.wm[j,axis]))


def entry_bracket(H,C,tinterval,last_lower):
    """Certified monotone-entry time bracket from continuous polynomial tubes."""
    lower=last_lower;upper=None
    for j in range(H.n):
        a=float(H.ts[j]);btime=float(H.ts[j+1])
        ia=polynomial_point_interval(H,j,a,0);ib=polynomial_point_interval(H,j,btime,0)
        if float(ia[0])>float(C.target[1]):lower=float(cr.add(tinterval,cr.pt(a))[0])
        if float(ib[0])>float(C.target[1]):lower=float(cr.add(tinterval,cr.pt(btime))[0])
        if float(ib[1])<=float(C.target[0]):
            # Move certified lower/upper endpoints toward each other. The entire
            # cell radius is used at every bisection point, never an ODE tolerance.
            lo=a;hi=btime
            for _ in range(35):
                mid=(lo+hi)/2;im=polynomial_point_interval(H,j,mid,0)
                if float(im[0])>float(C.target[1]):lo=mid;lower=float(cr.add(tinterval,cr.pt(mid))[0])
                elif float(im[1])<=float(C.target[0]):hi=mid
                else:break
            upper=float(cr.add(tinterval,cr.pt(hi))[1])
            break
    return lower,upper


_PROFILES={};_CERTS={}
def diagnostic_profile(p,d0,v0):
    key=(p.name,d0,v0)
    if key not in _PROFILES:_PROFILES[key]=b.Profile(p,d0,v0,p.eps+.002,fine=True)
    return _PROFILES[key]

def stored_certificate(p,v0,theta,dt):
    key=(p.name,v0,theta,dt)
    if key not in _CERTS:_CERTS[key]=StoredCertificate(p,v0,theta,dt)
    return _CERTS[key]


def simulate(p,task,v0,kind,theta,dt,cell=.001,tail=True):
    C=constants(p,v0,theta,task)
    d0=p.eps+.8+p.gamma*v0;z=np.array([d0,v0],float)
    w=np.array([max(abs(d0-float(C.d0[0])),abs(float(C.d0[1])-d0)),
                max(abs(v0-float(C.v0[0])),abs(float(C.v0[1])-v0))])
    w=cr.hi(w)
    P=diagnostic_profile(p,d0,v0);cert=stored_certificate(p,v0,theta,dt)
    target=p.eps+(.01 if task=='gap' else .21)
    nom=b.Nominal(p,task,kind,ROOT.parent/'manuscript'/'numerics')
    Tstar=P.clock(d0-target)
    from reference_clocks import evaluate as reference_clocks
    clocks=reference_clocks(p,task,v0,theta,cert,Tstar)
    Wtheta=clocks['Wtheta'];clocklo=clocks['Tstar_lower'];wlower=clocks['Wtheta_lower']
    Tentry=Tdet=entrylo=entryhi=None;last_entry_lower=0.
    trace=[];counts={k:0 for k in ['nominal','witness_overlap','witness_floor','witness_ceiling','tail']}
    diagnostics={'h':.8,'v':v0,'floor':(1-theta)*v0*v0/2,'M':p.M-v0}
    mins={k:math.inf for k in ['h_margin','v_margin','M_margin','floor_margin','extension_margin']}
    maxrad=np.zeros(2);calls=0;witness_margin=math.inf;active=0;control=[];preholds=0
    J=I1=I2=I1sample=I2sample=A2=TVA=TVU=0.;maxjump=0.;previous_a=None;previous_u=None
    tailmax=0.;tailcount=0;gx,gw=np.polynomial.legendre.leggauss(16)
    start=time.perf_counter();t=0.;tinterval=cr.pt(0.);steps=0;rejects={};multicell=0;maxrad_pre=np.zeros(2);Tdet_interval=None
    while t<max(20.,10.)-1e-12:
        before=Tdet is None
        if not before and not tail:break
        if not before and t>=10.-1e-12:break
        # No adaptive halving and no shortened pre-entry holds.
        useddt=dt if before else min(dt,10.-t)
        if before:
            tick=time.perf_counter()
            H,we,info,ncalls,rejected=select(p,C,cert,z,w,t,nom,useddt,cell,initial_rest=(steps==0 and v0==0))
            decision=(time.perf_counter()-tick)*1000;control.append(decision)
            for reason in rejected:rejects[reason]=rejects.get(reason,0)+1
            preholds+=1;active+=int(abs(H.u-b.clip(nom(t,*z),-p.U,p.U))>1e-8)
            multicell+=int(info['witness_j0']!=info['witness_j1'])
            if info.get('witness_clearance_margin') is not None:witness_margin=min(witness_margin,info['witness_clearance_margin'])
        else:
            H,we,info,ncalls=tail_hold(p,C,cert,z,w,useddt,cell);decision=None;rejected=[]
            tailmax=max(tailmax,info['tail_correction']);tailcount+=int(info['tail_correction']>1e-12)
        mode=info['mode'];counts[mode]+=1;calls+=ncalls
        # All task/intervention/motion values below are quadrature diagnostics.
        # Split at plant kinks, so acceleration derivative's branch is respected.
        breaks=[0.,useddt]
        if p.name=='C3':
            for kink in [.1,1.975]:
                if H.end[0]<kink<z[0]:breaks.append(brentq(lambda tau:float(H.sol.sol(tau)[0])-kink,0.,useddt))
        breaks=sorted(breaks)
        sampled_k=b.clip(nom(t,*z),-p.U,p.U)
        for a,bb in zip(breaks[:-1],breaks[1:]):
            qt=a+(gx+1)*(bb-a)/2;qw=gw*(bb-a)/2
            qd,qv=H.sol.sol(qt);qa=p.alpha*(cz.V(p,qd)-qv)+H.u;qh=qd-p.gamma*qv-p.eps
            running=.2*H.u**2+50*qd**2 if task=='gap' else .2*H.u**2+qv**2+5*(qh-.2)**2
            kn=np.array([b.clip(nom(t+tt,float(dd),float(vv)),-p.U,p.U) for tt,dd,vv in zip(qt,qd,qv)])
            J+=float(np.dot(qw,running));I1+=float(np.dot(qw,np.abs(H.u-kn)));I2+=float(np.dot(qw,(H.u-kn)**2))
            A2+=float(np.dot(qw,qa*qa))
            vp=.8*((qd>.1)&(qd<1.975)) if p.name=='C3' else 1-np.tanh(qd)**2
            ap=-p.alpha*vp*qv-p.alpha*qa;TVA+=float(np.dot(qw,np.abs(ap)))
        I1sample+=useddt*abs(H.u-sampled_k);I2sample+=useddt*(H.u-sampled_k)**2
        astart=p.a(*z)+H.u;aend=p.a(*H.end)+H.u
        if previous_a is not None:
            jump=abs(astart-previous_a);TVA+=jump;maxjump=max(maxjump,jump);TVU+=abs(H.u-previous_u)
        previous_a=aend;previous_u=H.u
        ss=np.linspace(0,useddt,101);dd,vv=H.sol.sol(ss)
        diagnostics['h']=min(diagnostics['h'],float(np.min(dd-p.gamma*vv-p.eps)))
        diagnostics['v']=min(diagnostics['v'],float(np.min(vv)))
        diagnostics['M']=min(diagnostics['M'],float(np.min(p.M-vv)))
        if before:
            ff=[.5*v*v-theta*P.E(min(P.S,max(0.,d0-d))) for d,v in zip(dd,vv)]
            diagnostics['floor']=min(diagnostics['floor'],min(ff))
            if Tentry is None and H.end[0]<=target:
                Tentry=t+brentq(lambda tau:float(H.sol.sol(tau)[0])-target,0.,useddt,xtol=1e-14)
            if entryhi is None:
                last_entry_lower,high=entry_bracket(H,C,tinterval,last_entry_lower)
                if high is not None:entrylo,entryhi=last_entry_lower,high
            if hi_float(H.end[0]+we[0])<=float(C.target[0]):
                Tdet=t+useddt;Tdet_interval=dfloat(cr.add(tinterval,cr.pt(useddt)))
        for key in mins:
            if key=='floor_margin' and not before:continue
            mins[key]=min(mins[key],info[key])
        maxrad=np.maximum(maxrad,[info['max_radius_d'],info['max_radius_v']])
        if before:maxrad_pre=np.maximum(maxrad_pre,[info['max_radius_d'],info['max_radius_v']])
        trace.append({'t':t,'d':float(z[0]),'v':float(z[1]),'sample_radius_d':float(w[0]),'sample_radius_v':float(w[1]),
                      'u':H.u,'sampled_nominal':sampled_k,'dt':useddt,'mode':mode,'decision_ms':decision,
                      'nominal_rejection_reasons':rejected,'calls':ncalls,**info})
        z=H.end;w=we;t=math.fsum([t,useddt]);tinterval=cr.add(tinterval,cr.pt(useddt));steps+=1
        if steps>3000:raise RuntimeError('Hold budget exceeded')
    if Tdet is None:status='horizon'
    else:status='entered'
    if Tentry is not None and entryhi is None:raise RuntimeError('Entry detected without certified entry bracket')
    pre=[r for r in trace if r['mode']!='tail']
    row={'plant':p.name,'task':task,'h0':.8,'v0':v0,'d0':d0,'nominal':kind,'theta':theta,'dt':dt,
         'method':'nominal_first_stored_witness','status':status,'T':Tentry,'T_detected':Tdet,
         'T_detected_interval':Tdet_interval,'T_entry_lower':entrylo,'T_entry_upper':entryhi,'entry_bracket_width':entryhi-entrylo if entryhi is not None else None,
         'Tstar':Tstar,**clocks,
         'ratio':Tentry/Tstar if Tentry else None,'T_over_Wtheta':Tentry/Wtheta if Tentry else None,
         'entry_upper_over_Wtheta_lower':entryhi/wlower if entryhi else None,
         'verified_conservative_entry_bound':bool(entryhi is not None and entryhi<=wlower),
         'sample_detection_delay':Tdet-Tentry if Tentry else None,
         'h_min_diagnostic':diagnostics['h'],'v_min_diagnostic':diagnostics['v'],
         'M_min_diagnostic':diagnostics['M'],'floor_min_diagnostic':diagnostics['floor'],
         'cert_min_h':mins['h_margin'],'cert_min_v':mins['v_margin'],'cert_min_M':mins['M_margin'],
         'cert_min_floor':mins['floor_margin'],'cert_min_extension':mins['extension_margin'],
         'max_radius_d':float(maxrad[0]),'max_radius_v':float(maxrad[1]),'max_pre_entry_radius_d':float(maxrad_pre[0]),'max_pre_entry_radius_v':float(maxrad_pre[1]),'witness_min_clearance_margin':witness_margin,
         'nominal_accepts':counts['nominal'],'fallbacks':preholds-counts['nominal'],'mode_counts':counts,
         'nominal_acceptance_fraction':counts['nominal']/max(preholds,1),'intervention_fraction':active/max(preholds,1),
         'pre_entry_holds':preholds,'sample_multicell_enclosures':multicell,'nominal_rejection_counts':rejects,
         'J10':J if t>=10.-1e-8 else None,'I10_L1':I1 if t>=10.-1e-8 else None,'I10_L2':I2 if t>=10.-1e-8 else None,
         'I1_sampled10':I1sample if t>=10.-1e-8 else None,'I2_sampled10':I2sample if t>=10.-1e-8 else None,
         'RMS_acc10':math.sqrt(A2/10) if t>=10.-1e-8 else None,'TV_acc10':TVA if t>=10.-1e-8 else None,'TV_u10':TVU if t>=10.-1e-8 else None,
         'max_acc_jump':maxjump,'tail_correction_max':tailmax,'tail_correction_holds':tailcount,'cost_horizon_actual':t,
         'max_abs_actuator':max(abs(r['u']) for r in trace),'shortened_pre_entry_holds':0,
         'min_actual_pre_entry_dt':min(r['dt'] for r in pre),'max_actual_pre_entry_dt':max(r['dt'] for r in pre),
         'control_mean_ms':float(np.mean(control)),'control_p50_ms':float(np.median(control)),
         'control_p95_ms':float(np.percentile(control,95)),'control_max_ms':max(control),
         'holds':steps,'cert_calls':calls,'wall_seconds':time.perf_counter()-start,'cell':cell,
         'certificate_file':str(cert.path.relative_to(ROOT.parent)),'certificate_sha256':cert.source_sha256,
         'model_perturbation_bound':EPS,'actual_parameter_difference_bound':C.model_perturbation_proved_upper,
         'timing_scope':'production run; concurrency stated in run manifest, not real-time evidence'}
    return row,trace


def source_hashes():
    files=[Path(__file__),ROOT/'reference_clocks.py',ROOT/'prepare_certificates.py',V7/'certified_zoh.py',V7/'certificate_rounding.py',V7/'outward_loop.c',V7/'reference_v6.py',SC/'certify_balanced.py']
    return {str(p.relative_to(ROOT.parent)):sha(p) for p in files}

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--plant',default='C3');ap.add_argument('--task',default='gap')
    ap.add_argument('--v0',type=float,default=0.);ap.add_argument('--theta',type=float,default=.5)
    ap.add_argument('--period',type=float,default=.025);ap.add_argument('--nominal',default='opposing')
    ap.add_argument('--no-tail',action='store_true');ap.add_argument('--out',required=True);a=ap.parse_args()
    p=next(p for p in b.PLANTS if p.name==a.plant)
    row,trace=simulate(p,a.task,a.v0,a.nominal,a.theta,a.period,tail=not a.no_tail)
    Path(a.out).write_text(json.dumps({'row':row,'trace':trace,'source_hashes':source_hashes()},indent=2)+'\n')
    print(json.dumps(row,indent=2),flush=True)
