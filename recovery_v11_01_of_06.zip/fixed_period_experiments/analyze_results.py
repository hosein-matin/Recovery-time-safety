#!/usr/bin/env python3
"""Generate V11 figures/tables from the retained new matrix, without copied claims."""
from pathlib import Path
import json,csv,math,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));import fixed_period as fp


def csvwrite(path,rows):
    fields=list(rows[0])
    with path.open('w',newline='') as f:
        wr=csv.DictWriter(f,fields);wr.writeheader();wr.writerows(rows)

def comparison_counts(rr,old,key,metric,tol):
    d=np.array([r[metric]-old[key(r)][metric] for r in rr],float)
    return {'lower':int(np.sum(d< -tol)),'tied':int(np.sum(abs(d)<=tol)),'higher':int(np.sum(d>tol)),
            'median_difference':float(np.median(d)),'tolerance':tol}


def main():
    (ROOT/'figures').mkdir(exist_ok=True);(ROOT/'tables').mkdir(exist_ok=True)
    rows=json.loads((ROOT/'data/rows.json').read_text())
    timing=json.loads((ROOT/'serial_timing.json').read_text())
    sr={r['period']:r for r in timing['pooled']}
    oldrows=[json.loads(p.read_text())['row'] for p in (ROOT.parent/'numerics_v7/data/cases').glob('*.json')]
    oldrows=[r for r in oldrows if r.get('group')=='base' and r.get('method')=='band']
    key=lambda r:(r['plant'],r['task'],r['v0'],r['nominal'],r['theta'])
    old={key(r):r for r in oldrows};assert len(old)==96
    metrics={'T':1e-9,'J10':1e-8,'I10_L1':1e-8,'I10_L2':1e-8,'RMS_acc10':1e-8,'TV_acc10':1e-8,'TV_u10':1e-8}
    summary=[];matched=[];breakdowns=[]
    for dt in [.01,.025]:
        rr=[r for r in rows if r['dt']==dt];assert len(rr)==96
        nominal=sum(r['nominal_accepts'] for r in rr);fallback=sum(r['fallbacks'] for r in rr);ph=nominal+fallback
        s={'period':dt,'cases':len(rr),'entered':sum(r['status']=='entered' for r in rr),
           'median_T_over_Wtheta':float(np.median([r['T_over_Wtheta'] for r in rr])),
           'maximum_T_over_Wtheta':max(r['T_over_Wtheta'] for r in rr),
           'maximum_interval_entry_upper_over_W_lower':max(r['entry_upper_over_Wtheta_lower'] for r in rr),
           'all_interval_entry_checks_pass':all(r['verified_conservative_entry_bound'] for r in rr),
           'nominal_accepted_holds':nominal,'fallback_holds':fallback,'pre_entry_holds':ph,
           'pooled_nominal_acceptance_percent':100*nominal/ph,
           'median_case_nominal_acceptance_percent':100*float(np.median([r['nominal_acceptance_fraction'] for r in rr])),
           'minimum_headway_diagnostic':min(r['h_min_diagnostic'] for r in rr),
           'minimum_speed_diagnostic':min(r['v_min_diagnostic'] for r in rr),
           'minimum_floor_diagnostic':min(r['floor_min_diagnostic'] for r in rr),
           'minimum_cap_diagnostic':min(r['M_min_diagnostic'] for r in rr),
           'maximum_pre_entry_d_radius':max(r['max_pre_entry_radius_d'] for r in rr),
           'maximum_pre_entry_v_radius':max(r['max_pre_entry_radius_v'] for r in rr),
           'maximum_entry_bracket_width':max(r['entry_bracket_width'] for r in rr),
           'maximum_detection_delay':max(r['sample_detection_delay'] for r in rr),
           'minimum_witness_clearance_margin':min(r['witness_min_clearance_margin'] for r in rr if r['witness_min_clearance_margin'] is not None),
           'shortened_pre_entry_holds':sum(r['shortened_pre_entry_holds'] for r in rr),
           'maximum_actuator':max(r['max_abs_actuator'] for r in rr),
           'median_J10':float(np.median([r['J10'] for r in rr])),
           'median_I10_L1':float(np.median([r['I10_L1'] for r in rr])),
           'median_RMS_acc10':float(np.median([r['RMS_acc10'] for r in rr])),
           'serial_decisions':sr[dt]['count'],'serial_p50_ms':sr[dt]['p50_ms'],
           'serial_p95_ms':sr[dt]['p95_ms'],'serial_max_ms':sr[dt]['max_ms']}
        summary.append(s)
        for subset,rr2 in [('all96',rr),('non_HJB72',[r for r in rr if r['nominal']!='hjb'])]:
            for metric,tol in metrics.items():
                matched.append({'period':dt,'historical_search_period':.05,'subset':subset,'cases':len(rr2),
                    'metric':metric,**comparison_counts(rr2,old,key,metric,tol)})
        for nominal in fp.b.NOMINALS:
            for theta in [.25,.5]:
                sub=[r for r in rr if r['nominal']==nominal and r['theta']==theta]
                breakdowns.append({'period':dt,'nominal':nominal,'theta':theta,'cases':len(sub),
                    'median_T_over_Wtheta':float(np.median([r['T_over_Wtheta'] for r in sub])),
                    'maximum_T_over_Wtheta':max(r['T_over_Wtheta'] for r in sub),
                    'pooled_nominal_acceptance_percent':100*sum(r['nominal_accepts'] for r in sub)/sum(r['pre_entry_holds'] for r in sub),
                    'median_J10':float(np.median([r['J10'] for r in sub])),
                    'median_I10_L1':float(np.median([r['I10_L1'] for r in sub])),
                    'median_RMS_acc10':float(np.median([r['RMS_acc10'] for r in sub]))})
    result={'summary':summary,'matched_historical_comparisons':matched,'by_nominal_and_theta':breakdowns,
        'historical_baseline':'unchanged V7 candidate-search band, requested period .05',
        'comparison_caveat':'Matched state/task/theta/nominal but different period and selection rule; descriptive paired counts, not a same-period causal estimate or independent-sample inference.',
        'diagnostic_scope':'T/Wtheta uses a target-specific diagnostic lower-reflected clock initialized at E0; a separate downward energy-envelope clock bound verifies entry. Task/intervention costs, motion, and dense minima are numerical diagnostics; physical-hold acceptance and entry brackets have separate outward proof records.',
        'production_case_count':192,'all_entered':all(r['status']=='entered' for r in rows),
        'analysis_source_sha256':fp.sha(Path(__file__))}
    (ROOT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    csvwrite(ROOT/'summary.csv',summary);csvwrite(ROOT/'matched_search_comparisons.csv',matched)
    csvwrite(ROOT/'nominal_theta_summary.csv',breakdowns)
    # Full-precision pairwise rows make every published count reconstructible.
    pairs=[]
    for r in rows:
        o=old[key(r)]
        pairs.append({**{k:r[k] for k in ['plant','task','v0','nominal','theta','dt','case_id']},
            'old_case_id':o['case_id'],'old_period':.05,
            **{f'new_{m}':r[m] for m in metrics},**{f'old_{m}':o[m] for m in metrics},
            **{f'difference_{m}':r[m]-o[m] for m in metrics}})
    csvwrite(ROOT/'matched_pairs_full_precision.csv',pairs)
    table=[r'\begin{tabular}{lrrrrrr}',r'\toprule',
        r'$\Delta$ & Entered & Max. $T/W_\theta$ & Nominal (\%) & Witness holds & p50 (ms) & p95 (ms)\\',r'\midrule']
    for s in summary:
        table.append(f"{s['period']:.3f} & {s['entered']}/96 & {s['maximum_T_over_Wtheta']:.4f} & {s['pooled_nominal_acceptance_percent']:.1f} & {s['fallback_holds']:,} & {s['serial_p50_ms']:.2f} & {s['serial_p95_ms']:.2f}\\\\")
    table += [r'\bottomrule',r'\end{tabular}']
    (ROOT/'tables/fixed_period_overview.tex').write_text('\n'.join(table)+'\n')
    paired=[r'\begin{tabular}{lrrrrrr}',r'\toprule',
      r'$\Delta$ & $T$ lower & $J_{10}$ lower & $I_{1,10}$ lower & Acc. RMS lower & Acc. TV lower & Input TV lower\\',r'\midrule']
    for dt in [.01,.025]:
        vals={r['metric']:r['lower'] for r in matched if r['period']==dt and r['subset']=='all96'}
        paired.append(f"{dt:.3f} & {vals['T']}/96 & {vals['J10']}/96 & {vals['I10_L1']}/96 & {vals['RMS_acc10']}/96 & {vals['TV_acc10']}/96 & {vals['TV_u10']}/96\\\\")
    paired += [r'\bottomrule',r'\end{tabular}']
    (ROOT/'tables/historical_comparison.tex').write_text('\n'.join(paired)+'\n')
    # Two periods, two theta levels, fixed deterministic point jitter.
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7.6,'axes.titlesize':8.3,
        'axes.labelsize':7.7,'xtick.labelsize':7.2,'ytick.labelsize':7.1,'pdf.fonttype':42})
    colors=['#007C83','#C96B21'];theta_colors=['#305C88','#7A477F']
    fig,axs=plt.subplots(1,3,figsize=(7.10,2.10),gridspec_kw={'width_ratios':[1.08,1.1,1.0]})
    fig.subplots_adjust(left=.067,right=.993,bottom=.24,top=.83,wspace=.47)
    ax=axs[0]
    positions=[];dat=[]
    for di,dt in enumerate([.01,.025]):
        for ti,th in enumerate([.25,.5]):
            pos=di+(-.16 if ti==0 else .16);positions.append(pos)
            vals=[r['T_over_Wtheta'] for r in rows if r['dt']==dt and r['theta']==th];dat.append(vals)
            jitter=np.linspace(-.045,.045,len(vals))
            ax.scatter(pos+jitter,vals,s=4.3,color=theta_colors[ti],alpha=.55,linewidths=0,zorder=2)
    box=ax.boxplot(dat,positions=positions,widths=.20,patch_artist=True,showfliers=False,
        boxprops={'linewidth':.65},whiskerprops={'linewidth':.65},capprops={'linewidth':.65},medianprops={'color':'black','linewidth':.9})
    for i,bx in enumerate(box['boxes']):bx.set_facecolor(theta_colors[i%2]);bx.set_alpha(.19)
    ax.axhline(1.,color='#444444',ls='--',lw=.7,zorder=1)
    ax.set_xticks([0,1],['0.010','0.025']);ax.set_ylim(.46,1.035);ax.set_yticks([.5,.75,1.])
    ax.set_xlabel(r'Period $\Delta$');ax.set_ylabel(r'Entry ratio $T/W_\theta$')
    ax.set_title('(a) All 192 episodes',loc='left',pad=7)
    from matplotlib.lines import Line2D
    ax.legend(handles=[Line2D([0],[0],marker='o',ls='',color=theta_colors[j],markersize=3,label=rf'$\theta={th:g}$') for j,th in enumerate([.25,.5])],
        loc='lower left',fontsize=6.4,frameon=False,ncol=1,handletextpad=.3,borderaxespad=.1,labelspacing=.15)
    ax=axs[1]
    names=['hjb','zero_input','zero_accel','opposing'];labels=['HJB',r'$0$',r'$-a$',r'$-U$']
    for j,dt in enumerate([.01,.025]):
        values=[]
        for nom in names:
            rr=[r for r in rows if r['dt']==dt and r['nominal']==nom]
            values.append(100*sum(r['nominal_accepts'] for r in rr)/sum(r['pre_entry_holds'] for r in rr))
        ax.bar(np.arange(4)+(-.17 if j==0 else .17),values,.30,label=f'{dt:.3f}',color=colors[j])
    ax.set_xticks(np.arange(4),labels);ax.set_ylim(0,55);ax.set_yticks([0,25,50]);ax.set_ylabel('Nominal accepted (%)')
    ax.set_xlabel('Nominal law');ax.set_title('(b) Remaining holds: witness',loc='left',pad=7)
    ax.legend(title=r'$\Delta$',fontsize=6.4,title_fontsize=6.5,frameon=False,ncol=2,loc='upper right',columnspacing=.7,handlelength=1.)
    ax=axs[2]
    dtime=[np.array([s['milliseconds'] for s in timing['decision_samples'] if s['period']==dt]) for dt in [.01,.025]]
    bp=ax.boxplot(dtime,positions=[0,1],widths=.4,whis=(5,95),showfliers=False,patch_artist=True,
        boxprops={'linewidth':.7},whiskerprops={'linewidth':.7},capprops={'linewidth':.7},medianprops={'color':'black','linewidth':.9})
    for bx,c in zip(bp['boxes'],colors):bx.set_facecolor(c);bx.set_alpha(.55)
    for j,vals in enumerate(dtime):ax.scatter(j,float(np.max(vals)),s=15,marker='x',color=colors[j],linewidths=.8,zorder=3)
    ax.set_xticks([0,1],['0.010','0.025']);ax.set_ylabel('Serial decision time (ms)');ax.set_xlabel(r'Period $\Delta$')
    ax.set_title('(c) 16-case serial replay',loc='left',pad=7)
    ax.text(.03,.73,'Whiskers: 5–95%\n× maximum',transform=ax.transAxes,ha='left',va='top',fontsize=6.3)
    ax.set_ylim(bottom=0)
    for ax in axs:
        ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.18,linewidth=.5);ax.set_axisbelow(True)
        ax.tick_params(length=2.5,width=.55,pad=2)
    fig.savefig(ROOT/'figures/fixed_period_overview.pdf')
    fig.savefig(ROOT/'figures/fixed_period_overview.png',dpi=250)
    plt.close(fig)
    caption='Fixed-period nominal-first/stored-witness rule on96 configurations per period. (a) Diagnostic continuous-entry ratios for all four nominals; the entire matrix also passes the separate interval entry-upper/Wtheta-lower check. (b) Pooled fraction of pre-entry holds accepting the nominal; The labels denote frozen HJB, zero input, zero-acceleration command -a, and braking command -U; all nominal commands are actuator-clipped. Every remaining hold uses the stored comparison witness. (c) Single-process replay of all pre-entry decisions in16 declared stress episodes; boxes show quartiles, whiskers5–95%, crosses maxima. Runtimes are wall-clock milliseconds; Delta is normalized model time, so no real-time deadline comparison is implied. All runs retain accumulated numerical state enclosures, exact-decimal rounding correction, actuator bounds and the explicit rest guard. No pre-entry hold is shortened.'
    (ROOT/'figures/fixed_period_overview_caption.txt').write_text(caption+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
