#!/usr/bin/env python3
"""Diagnostic quadrature/tolerance sensitivity on the closest paired differences.

This does not change a controller decision or establish an interval error bound.
"""
from pathlib import Path
import sys,csv,json,math
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import fixed_period as fp


def recompute(case):
    r=case['row'];p=next(p for p in fp.b.PLANTS if p.name==r['plant'])
    nom=fp.b.Nominal(p,r['task'],r['nominal'],ROOT.parent/'manuscript/numerics')
    gx,gw=np.polynomial.legendre.leggauss(32)
    J=I1=I2=A2=TVA=0.;prev=None
    for tr in case['trace']:
        z=np.array([tr['d'],tr['v']]);u=tr['u'];dt=tr['dt'];t=tr['t']
        sol=solve_ivp(lambda tt,y:[-y[1],p.a(*y)+u],(0.,dt),z,method='DOP853',rtol=2e-13,atol=2e-15,max_step=dt/8,dense_output=True)
        assert sol.success
        end=sol.sol(dt);breaks=[0.,dt]
        if p.name=='C3':
            for kink in [.1,1.975]:
                if end[0]<kink<z[0]:breaks.append(brentq(lambda tau:float(sol.sol(tau)[0])-kink,0.,dt))
        breaks.sort()
        for a,b in zip(breaks[:-1],breaks[1:]):
            tt=a+(gx+1)*(b-a)/2;ww=gw*(b-a)/2;d,v=sol.sol(tt)
            acc=p.alpha*(fp.cz.V(p,d)-v)+u;h=d-p.gamma*v-p.eps
            cost=.2*u*u+50*d*d if r['task']=='gap' else .2*u*u+v*v+5*(h-.2)**2
            kval=np.array([fp.b.clip(nom(t+tau,float(dd),float(vv)),-p.U,p.U) for tau,dd,vv in zip(tt,d,v)])
            J+=float(np.dot(ww,cost));I1+=float(np.dot(ww,abs(u-kval)));I2+=float(np.dot(ww,(u-kval)**2));A2+=float(np.dot(ww,acc*acc))
            vp=.8*((d>.1)&(d<1.975)) if p.name=='C3' else 1-np.tanh(d)**2
            TVA+=float(np.dot(ww,abs(-p.alpha*vp*v-p.alpha*acc)))
        astart=p.a(*z)+u
        if prev is not None:TVA+=abs(astart-prev)
        prev=p.a(*end)+u
    return {'J10':J,'I10_L1':I1,'I10_L2':I2,'RMS_acc10':math.sqrt(A2/10),'TV_acc10':TVA}


def main():
    pairs=list(csv.DictReader((ROOT/'matched_pairs_full_precision.csv').open()))
    metrics=['J10','I10_L1','I10_L2','RMS_acc10','TV_acc10']
    selected={min(pairs,key=lambda r:abs(float(r['difference_'+m])))['case_id'] for m in metrics}
    hjb=[r for r in pairs if r['nominal']=='hjb']
    selected.add(min(hjb,key=lambda r:abs(float(r['difference_I10_L1'])))['case_id'])
    output=[]
    for ident in sorted(selected):
        case=json.loads((ROOT/'data/cases'/f'{ident}.json').read_text());new=recompute(case)
        old=case['row'];record={'case_id':ident,'plant':old['plant'],'task':old['task'],'nominal':old['nominal'],'period':old['dt'],
            'recomputed_32_point':new,'difference_from_published_16_point':{m:new[m]-old[m] for m in metrics}}
        output.append(record);print(json.dumps(record),flush=True)
    result={'case_count':len(output),'selection':'case with smallest absolute historical-pair difference for each of J,I1,I2,RMSacc,TVacc, plus closest HJB I1 pair',
        'parameters':'32-node Gauss-Legendre; DOP853 rtol2e-13 atol2e-15 max_step=dt/8; same stored commands/start centers; C3-kink splitting retained',
        'rows':output,'maximum_absolute_changes':{m:max(abs(z['difference_from_published_16_point'][m]) for z in output) for m in metrics},
        'scope':'numerical sensitivity diagnostic only, not a rigorous quadrature certificate or altered controller experiment',
        'source_sha256':fp.sha(Path(__file__))}
    (ROOT/'quadrature_sensitivity.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['maximum_absolute_changes'],indent=2),flush=True)

if __name__=='__main__':main()
