#!/usr/bin/env python3
"""Reporting-only reference clocks; never used to select a held command.

Wtheta is the lower-reflected Aminus clock, not Tstar/sqrt(theta) for moving
starts. The diagnostic ODE and the rigorous lower bound are separate paths.
See METHOD.txt, section 5, for the envelope proof behind the lower bound.
"""
from fractions import Fraction
from functools import lru_cache
import math
import numpy as np

@lru_cache(maxsize=None)
def evaluate(p,task,v0,theta,cert,Tstar):
    import fixed_period as f
    C=f.constants(p,v0,theta,task)
    target_x='.01' if task=='gap' else '.21'
    d0=p.eps+.8+p.gamma*v0;target=p.eps+float(target_x)
    profile=f.b.Profile(p,d0,v0,target,fine=True)
    reflected,contact=profile.worst(theta,fine=True)
    # V is nondecreasing in d; during the episode d<=d0 and v>=0.
    # Hence fminus=alpha*(V(d)-v)-U <= alpha*V(d0)-U <= m < 0.
    aa=f.cr.iv.mpf(f.DECIMAL[p.name][0]);gg=f.cr.iv.mpf(f.DECIMAL[p.name][1])
    di=f.cr.iv.mpf('.02')+f.cr.iv.mpf('.8')+gg*f.cr.iv.mpf(str(v0))
    if p.name=='C3':
        V=f.cr.iv.mpf('.8')*(di-f.cr.iv.mpf('.1'))
        assert V.a>=0 and V.b<=f.cr.iv.mpf('1.5')
    else:V=f.cr.ivtanh(di)-f.cr.ivtanh(f.cr.iv.mpf(2))
    m=float(f.cr.ivfloat(aa*V-f.cr.iv.mpf(5))[1]);assert m<0
    n=cert.i0-int(Fraction(target_x)*cert.scale)
    assert n>0 and n<=len(cert.Eup)
    # Before its first floor contact Aminus<=E0+m*s; after contact it equals q.
    # The envelope max(q,E0+m*s) therefore bounds it everywhere. On cell j,
    # m<0 makes the left endpoint j*h the largest value of this free line.
    sl=f.cr.mul(f.dec('.0001'),f.cr.pt(np.arange(n,dtype=float)))
    E0=f.cr.scale(f.cr.square(C.v0),.5)
    free_upper=f.cr.add(E0,f.cr.mul(f.cr.pt(m),sl))[1]
    floor_upper=f.cr.mul(C.theta,(cert.Eup[:n],cert.Eup[:n]))[1]
    energy_upper=np.maximum(floor_upper,free_upper)
    assert np.all(energy_upper>0)
    speed_upper=f.cr.hi(np.sqrt(f.cr.hi(2*energy_upper)))
    terms=f.cr.divpos(f.dec('.0001'),(speed_upper,speed_upper))[0]
    lower=0.
    for term in terms:lower=f.lo_float(lower+float(term))
    Tstar_lower=cert.clock_lower(float(target_x))
    simple_lower=float(f.cr.divpos(f.cr.pt(Tstar_lower),C.r)[0])
    return {'Wtheta':reflected,'Wtheta_lower':lower,
        'Wtheta_floor_contact_s_diagnostic':contact,
        'Wtheta_definition':'lower-reflected Aminus clock initialized at E0',
        'Wtheta_lower_method':'downward Riemann sum from max(theta*Eplus_cell_upper,E0+m*s_left)',
        'Wtheta_free_slope_upper':m,'Tstar_lower':Tstar_lower,
        'simple_factor_bound':Tstar/math.sqrt(theta),
        'simple_factor_bound_lower':simple_lower}
