#!/usr/bin/env python3
"""Hash portable experiment files; exclude bytecode and rebuildable binaries."""
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parent
out=ROOT/'MANIFEST_SHA256.txt'
paths=sorted(p for p in ROOT.rglob('*') if p.is_file() and p!=out and '__pycache__' not in p.parts and p.suffix not in ['.so','.pyc'])
lines=[hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT)) for p in paths]
out.write_text('\n'.join(lines)+'\n')
print(len(paths),'portable files')
