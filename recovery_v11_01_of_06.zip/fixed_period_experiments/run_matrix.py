#!/usr/bin/env python3
"""Frozen 192-case V11 matrix; failures are retained, never silently omitted."""
from pathlib import Path
import os
for var in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[var]='1'
import sys,json,csv,time,hashlib,argparse,traceback,concurrent.futures,multiprocessing,platform,subprocess
import numpy as np
import scipy
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import fixed_period as fp
OUT=ROOT/'data';OUT.mkdir(exist_ok=True);(OUT/'cases').mkdir(exist_ok=True)

def safe(x):
    if isinstance(x,dict):return {str(k):safe(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [safe(v) for v in x]
    if isinstance(x,(float,np.floating)) and not np.isfinite(x):return None
    if isinstance(x,np.generic):return x.item()
    return x

def cases():
    return [dict(plant=p.name,task=task,h0=.8,v0=v0,nominal=nominal,theta=theta,dt=dt,
                 method='nominal_first_stored_witness',group='main')
            for dt in [.01,.025] for p in fp.b.PLANTS for task in ['gap','tracking']
            for v0 in [0.,.4] for nominal in fp.b.NOMINALS for theta in [.25,.5]]

def ident(c):return hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest()[:16]
def hashes():return {**fp.source_hashes(),'fixed_period_experiments/run_matrix.py':fp.sha(Path(__file__))}

def worker(c):
    fn=OUT/'cases'/f'{ident(c)}.json'
    # Always recompute: the previous cache keyed only source files, not every
    # policy/certificate/runtime dependency. No stale semantic reuse is allowed.
    try:
        p=next(p for p in fp.b.PLANTS if p.name==c['plant'])
        row,trace=fp.simulate(p,c['task'],c['v0'],c['nominal'],c['theta'],c['dt'],tail=True)
        row.update(group='main',case_id=ident(c))
        data={'case':c,'row':row,'trace':trace,'source_hashes':hashes()}
    except Exception as e:
        row={**c,'case_id':ident(c),'status':'exception','exception':str(e)}
        data={'case':c,'row':row,'traceback':traceback.format_exc(),'source_hashes':hashes()}
    tmp=fn.with_suffix('.tmp');tmp.write_text(json.dumps(safe(data),indent=2,allow_nan=False)+'\n');tmp.replace(fn)
    return row

def environment(workers):
    cpu=Path('/proc/cpuinfo').read_text()
    model=next((s.split(':',1)[1].strip() for s in cpu.splitlines() if s.startswith('model name')),'unknown')
    return {'utc_start':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'python':sys.version,
        'platform':platform.platform(),'processor':model,'logical_cpus':os.cpu_count(),
        'available_cpu_affinity':sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None,
        'numpy':np.__version__,'scipy':scipy.__version__,'mpmath':fp.cr.iv.__class__.__module__,
        'residual_transcendental_precision_decimal_digits':40,'offline_certificate_precision_decimal_digits':45,
        'floating_point':'IEEE 754 binary64; every elementary certificate operation enlarged by nextafter',
        'compiler':subprocess.check_output(['cc','--version'],text=True).splitlines()[0],
        'compiler_flags':'-std=c99 -O2 -fPIC -shared -fno-fast-math -ffp-contract=off',
        'outward_C_kernel_loaded':fp.cz._lib is not None,'workers':workers,
        'thread_environment':{s:os.environ.get(s) for s in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']},
        'source_hashes':hashes(),
        'frozen_policy_sha256':{p.name:fp.sha(p) for p in (ROOT.parent/'manuscript'/'numerics'/'policies').glob('*medium.npz')},
        'note':'Parallel production wall-clock samples are not real-time evidence. Serial replay is reported separately.'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=3);ap.add_argument('--limit',type=int);a=ap.parse_args()
    tasks=cases();tasks=tasks[:a.limit] if a.limit else tasks
    protocol={'frozen_before_production':True,'cases':tasks,'case_count':len(tasks),
        'controller':'clipped nominal if continuous residual tube and explicit launch guard certify the full hold; otherwise stored Proposition8 witness with outward clearance over the carried sample-state box',
        'periods_normalized_model_time':[.01,.025],'no_adaptive_shortening':True,'main_initial_h':.8,
        'nominals':fp.b.NOMINALS,'targets_x':{'gap':.01,'tracking':.21},'profile_extension_x':.002,
        'profile_cell_width':.0001,'residual_time_cell_max':.001,'cost_horizon':10.,
        'tail':'same sampled safety law as historical V7, at the new period, with complete-hold safety check and minimal nonnegative-source correction when required',
        'metrics':'ordinary ODE/quadrature diagnostics; sample-state and whole-hold enclosures are proof records, not finite-sample tests',
        'quadrature':'16-point Gauss-Legendre per hold, split at C3 saturation kinks; diagnostic minima at101 dense points/hold',
        'entry':'dense numerical root for continuous entry T; separate interval-tube bracket and sampled detection',
        'model_parameters':'exact declared decimals; binary64 reference curve receives a proved uniform model-field perturbation residual of2^-40 on [-1,3]^2',
        'initial_state':'outward enclosure of exact d0=.02+.8+gamma*v0 and exact v0; radius propagated without resetting',
        'sensing':'exact sampled physical state theory; stored state enclosure covers numerical integration/roundoff only, no independent sensor-noise or delay model',
        'comparisons':'historical whole-hold candidate-search band at .05, explicitly different period; same frozen task/initial/theta/nominal',
        'source_hashes':hashes()}
    (ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    env=environment(a.workers);(ROOT/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
    started=time.perf_counter();rows=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers,mp_context=multiprocessing.get_context('spawn')) as pool:
        futures={pool.submit(worker,c):c for c in tasks}
        for f in concurrent.futures.as_completed(futures):
            r=f.result();rows.append(r)
            print(json.dumps(safe({'done':len(rows),'total':len(tasks),'case_id':r['case_id'],'status':r['status'],
                'plant':r['plant'],'task':r['task'],'v0':r['v0'],'nominal':r['nominal'],'theta':r['theta'],'dt':r['dt'],
                'T_over_Wtheta':r.get('T_over_Wtheta'),'nominal_accepts':r.get('nominal_accepts'),'fallbacks':r.get('fallbacks'),
                'exception':r.get('exception')})),flush=True)
    rows.sort(key=lambda r:next(i for i,c in enumerate(tasks) if ident(c)==r['case_id']))
    (OUT/'rows.json').write_text(json.dumps(safe(rows),indent=2,allow_nan=False)+'\n')
    columns=sorted(set().union(*(r.keys() for r in rows)))
    with (OUT/'episodes.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,columns);writer.writeheader()
        writer.writerows({k:json.dumps(safe(v),sort_keys=True) if isinstance(v,(dict,list,tuple)) else safe(v) for k,v in r.items()} for r in rows)
    result={'case_count':len(rows),'entered':sum(r['status']=='entered' for r in rows),
        'failures':[r for r in rows if r['status']!='entered'],'production_wall_seconds':time.perf_counter()-started,
        'workers':a.workers,'complete':len(rows)==len(tasks),'source_hashes':hashes()}
    (OUT/'run_summary.json').write_text(json.dumps(safe(result),indent=2,allow_nan=False)+'\n')
    print(json.dumps(safe(result),indent=2),flush=True)

if __name__=='__main__':main()
