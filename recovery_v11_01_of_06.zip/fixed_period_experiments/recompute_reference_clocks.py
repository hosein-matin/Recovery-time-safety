#!/usr/bin/env python3
"""Repair reporting clocks without rerunning or modifying any held trajectory.

The original production used the simple factor clock in fields labelled Wtheta.
This deterministic postprocessor replaces only reference-clock fields, records
all replaced values and verifies the complete trace/non-clock row fingerprints.
The original numerical source and its hashes remain in provenance/ and cases.
"""
from pathlib import Path
import sys,json,csv,hashlib
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import fixed_period as fp
from reference_clocks import evaluate
CLOCK_KEYS={'Wtheta','Wtheta_lower','Tstar_lower','T_over_Wtheta',
    'entry_upper_over_Wtheta_lower','verified_conservative_entry_bound',
    'Wtheta_floor_contact_s_diagnostic','Wtheta_definition','Wtheta_lower_method',
    'Wtheta_free_slope_upper','simple_factor_bound','simple_factor_bound_lower'}
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def main():
    receiptpath=ROOT/'provenance/clock_correction.json'
    previous=json.loads(receiptpath.read_text()) if receiptpath.exists() else None
    oldcases={x['case_id']:x for x in previous['cases']} if previous else {}
    original=ROOT/'provenance/production_fixed_period.py'
    records=[];rows=[];refs={};production_hashes=None
    for path in sorted((ROOT/'data/cases').glob('*.json')):
        x=json.loads(path.read_text());r=x['row'];c=x['case'];cid=r['case_id']
        tracehash=digest(x['trace']);nonclock=digest({k:v for k,v in r.items() if k not in CLOCK_KEYS})
        if cid in oldcases:
            assert tracehash==oldcases[cid]['trace_sha256']
            assert nonclock==oldcases[cid]['non_clock_row_sha256']
            old=oldcases[cid]['original_clock_fields']
        else:old={k:v for k,v in r.items() if k in CLOCK_KEYS}
        p=next(p for p in fp.b.PLANTS if p.name==r['plant'])
        cert=fp.stored_certificate(p,r['v0'],r['theta'],r['dt'])
        clocks=evaluate(p,r['task'],r['v0'],r['theta'],cert,r['Tstar'])
        r.update(clocks);r['T_over_Wtheta']=r['T']/r['Wtheta']
        r['entry_upper_over_Wtheta_lower']=r['T_entry_upper']/r['Wtheta_lower']
        r['verified_conservative_entry_bound']=r['T_entry_upper']<=r['Wtheta_lower']
        assert r['verified_conservative_entry_bound']
        assert tracehash==digest(x['trace'])
        assert nonclock==digest({k:v for k,v in r.items() if k not in CLOCK_KEYS})
        production_hashes=x['source_hashes']
        assert fp.sha(original)==production_hashes['fixed_period_experiments/fixed_period.py']
        x['reporting_correction']={'kind':'reflected_reference_clock','script_sha256':fp.sha(Path(__file__)),
            'reference_clock_source_sha256':fp.sha(ROOT/'reference_clocks.py'),
            'trace_sha256':tracehash,'non_clock_row_sha256':nonclock}
        tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(path)
        rows.append(r);records.append({'case_id':cid,'trace_sha256':tracehash,'non_clock_row_sha256':nonclock,
            'original_clock_fields':old,'corrected_clock_fields':{k:v for k,v in r.items() if k in CLOCK_KEYS}})
        key=(r['plant'],r['task'],r['v0'],r['theta'])
        refs[key]={'plant':key[0],'task':key[1],'v0':key[2],'theta':key[3],**clocks}
    old_order={r['case_id']:j for j,r in enumerate(json.loads((ROOT/'data/rows.json').read_text()))}
    rows.sort(key=lambda r:old_order[r['case_id']])
    (ROOT/'data/rows.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
    columns=sorted(set().union(*(r.keys() for r in rows)))
    with (ROOT/'data/episodes.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,columns);w.writeheader();w.writerows({k:json.dumps(v,sort_keys=True) if isinstance(v,(dict,list,tuple)) else v for k,v in r.items()} for r in rows)
    receipt={'status':'complete','scope':'reference-clock reporting correction only; every complete held trace and every non-clock row field unchanged',
        'original_production_source_hashes':production_hashes,'corrected_current_source_hashes':fp.source_hashes(),
        'correction_script_sha256':fp.sha(Path(__file__)),'case_count':len(rows),'all_corrected_interval_entry_checks_pass':all(r['verified_conservative_entry_bound'] for r in rows),
        'cases':records}
    receiptpath.write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    (ROOT/'reference_clock_summary.json').write_text(json.dumps({'definitions':{'Wtheta':'diagnostic lower-reflected reference initialized at E0','simple_factor_bound':'Tstar/sqrt(theta), distinct for moving starts','Wtheta_lower':'rigorous downward cell sum from max(q_upper,E0+m*s_left)'},'rows':list(refs.values())},indent=2,allow_nan=False)+'\n')
    print(json.dumps({'case_count':len(rows),'all_interval_entry_checks_pass':True,'max_T_over_Wtheta':{str(dt):max(r['T_over_Wtheta'] for r in rows if r['dt']==dt) for dt in [.01,.025]},'max_entry_upper_over_Wtheta_lower':{str(dt):max(r['entry_upper_over_Wtheta_lower'] for r in rows if r['dt']==dt) for dt in [.01,.025]}},indent=2))
if __name__=='__main__':main()
