#!/usr/bin/env python3
"""Generate .01 witness tables from the released rigorous profile enclosures.

The .025 tables remain the original release files. All stored input files are
checked against the signed-off certificate report's SHA-256 values. No profile
is inferred from an ordinary numerical trajectory.
"""
from pathlib import Path
from fractions import Fraction
import hashlib,json,math,sys,time
import numpy as np
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'sampling_certificate'
sys.path.insert(0,str(OLD))
import certify_balanced as cb
from mpmath import iv
iv.dps=45
OUT=ROOT/'certificates'
OUT.mkdir(exist_ok=True)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def prepare():
    original=json.loads((OLD/'certified_results_0025.json').read_text())
    assert original['all_certified'] and original['interval_precision_dps']==45
    rows=[];start=time.perf_counter()
    cb.ROOT=OUT
    prefix_cache={}
    for row in original['rows']:
        source=OLD/row['detail_file']
        assert sha(source)==row['detail_sha256'],source
        z=np.load(source)
        P=cb.CertifiedProfile.__new__(cb.CertifiedProfile)
        P.p=next(p for p in cb.PLANTS if p.name==row['plant'])
        P.v0=row['v0'];P.scale=10000
        P.x0=Fraction('.8')+Fraction(P.p.gamma)*Fraction(P.v0)
        P.xe=Fraction('.002');P.i0=int(P.x0*P.scale);P.ie=20;P.n=P.i0-P.ie
        P.xindex=np.arange(P.i0,P.ie-1,-1,dtype=np.int64)
        P.h=iv.mpf(1)/P.scale;P.hhi=cb.upper(P.h)
        P.Elo=z['E_lower'];P.Ehi=z['E_upper'];P.Ecelllo=z['E_cell_lower'];P.Ecellhi=z['E_cell_upper']
        P.phase=z['phase'];P.contact_proved_index=int(z['contact_proved_index'])
        P.seconds=0.;P.cap_cell_checks=row['cap_kink_cells_checked']
        boundary=tuple(z[key] for key in ['Rq_upper','RB_lower','zB_upper','zq_upper','width_lower'])
        new=cb.certify(P,row['theta'],'.01',boundary=boundary)
        assert new['certified']
        new['profile_reused_from']=str(source.relative_to(ROOT.parent))
        new['profile_source_sha256']=sha(source)
        # Every stored prefix must cover the *binary64* simulation period.
        # This is slightly stronger than the decimal period when float rounds up.
        for dt,values in [(.025,z['values']),(.01,np.load(OUT/new['detail_file'])['values'])]:
            key=(P.p.name,P.v0,dt)
            if key not in prefix_cache:
                g=iv.mpf(P.p.gamma);M=iv.mpf(P.p.M);cap=g*M
                worst=math.inf;worstj=None
                for rr in values:
                    j,k=int(rr[0]),int(rr[1])
                    xa=iv.mpf(P.i0-j-1)/P.scale
                    xb=iv.mpf(P.i0-k)/P.scale
                    # Explicit split at the speed-cap/headway kink.
                    if P.i0-j-1 <= Fraction(P.p.gamma)*Fraction(P.p.M)*P.scale:
                        clock=g*iv.ln(xa/xb)
                    elif P.i0-k >= Fraction(P.p.gamma)*Fraction(P.p.M)*P.scale:
                        clock=(xa-xb)/M
                    else:
                        clock=(xa-cap)/M+g*iv.ln(cap/xb)
                    clocklo=cb.lower(clock)
                    assert clocklo>=dt,(P.p.name,P.v0,dt,j,k,clocklo)
                    if clocklo<worst:worst=clocklo;worstj=j
                prefix_cache[key]={'plant':P.p.name,'v0':P.v0,'requested_period':dt,
                    'minimum_prefix_clock_lower':worst,'worst_cell':worstj,
                    'binary64_period_hex':float(dt).hex(),'all_prefixes_cover_binary64_period':True}
        rows.append(new)
        print(json.dumps({'plant':P.p.name,'v0':P.v0,'theta':row['theta'],'delta':'.01','certified':True}),flush=True)
    report={'status':'complete','generated_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        'all_certified':all(r['certified'] for r in rows),'interval_precision_dps':45,'rows':rows,
        'prefix_clock_checks':list(prefix_cache.values()),
        'reused_certificate_source_sha256':sha(OLD/'certify_balanced.py'),
        'reused_report_sha256':sha(OLD/'certified_results_0025.json'),
        'generation_source_sha256':sha(Path(__file__)),
        'seconds':time.perf_counter()-start,
        'scope':'Period-specific .01 Proposition8 witnesses from unchanged .025 interval profile/boundary enclosures; original .025 witnesses retained. Exact decimal models and h0=.8.'}
    (OUT/'generated_001_report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':prepare()
