#!/usr/bin/env python3
"""Check numerical comparison classifications on the selected refined metrics."""
from pathlib import Path
import json,csv
ROOT=Path(__file__).resolve().parent
pairs={r['case_id']:r for r in csv.DictReader((ROOT/'matched_pairs_full_precision.csv').open())}
q=json.loads((ROOT/'quadrature_sensitivity.json').read_text());checks=[]
for r in q['rows']:
    pair=pairs[r['case_id']]
    for metric in r['recomputed_32_point']:
        old=float(pair['difference_'+metric])
        fresh=old+r['difference_from_published_16_point'][metric]
        sign=lambda x:-1 if x< -1e-8 else (1 if x>1e-8 else 0)
        checks.append({'case_id':r['case_id'],'metric':metric,'published_pair_difference':old,
            'refined_new_vs_retained_old_difference':fresh,'same_classification':sign(old)==sign(fresh)})
out={'status':'passed' if all(r['same_classification'] for r in checks) else 'failed',
    'scope':'sensitivity on six selected new trajectories versus retained historical quadrature values, not an interval bound',
    'comparison_tolerance':1e-8,'checked_pairs':checks}
(ROOT/'quadrature_comparison_signs.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['status'],len(checks))
