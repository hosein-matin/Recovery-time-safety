#!/usr/bin/env python3
"""Evidence checks for the complete matrix and deliberately straddled kinks."""
from pathlib import Path
import sys,json,math,ast
from fractions import Fraction
import numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import fixed_period as fp
import importlib.util
_spec=importlib.util.spec_from_file_location('fixed_experiment_run_matrix',ROOT/'run_matrix.py')
rm=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(rm)

def main():
    rows=[];holds=0;uncertain=0;checks=[]
    from recompute_reference_clocks import digest,CLOCK_KEYS
    correction=json.loads((ROOT/'provenance/clock_correction.json').read_text())
    corrected={r['case_id']:r for r in correction['cases']}
    original=ROOT/'provenance/production_fixed_period.py'
    original_hashes=correction['original_production_source_hashes']
    assert fp.sha(original)==original_hashes['fixed_period_experiments/fixed_period.py']
    assert fp.sha(ROOT/'provenance/production_run_matrix.py')==original_hashes['fixed_period_experiments/run_matrix.py']
    for name,value in original_hashes.items():
        if name not in ['fixed_period_experiments/fixed_period.py','fixed_period_experiments/run_matrix.py']:
            assert fp.sha(ROOT.parent/name)==value
    def definitions(path):
        return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body
                if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name not in ['simulate','source_hashes']}
    assert definitions(original)==definitions(ROOT/'fixed_period.py')
    assert correction['correction_script_sha256']==fp.sha(ROOT/'recompute_reference_clocks.py')
    for path in sorted((ROOT/'data/cases').glob('*.json')):
        x=json.loads(path.read_text());r=x['row'];tr=x['trace'];c=x['case']
        if x['source_hashes']!=rm.hashes():
            assert x['source_hashes']==original_hashes,path
            assert digest(tr)==corrected[r['case_id']]['trace_sha256']
            assert digest({k:v for k,v in r.items() if k not in CLOCK_KEYS})==corrected[r['case_id']]['non_clock_row_sha256']
            assert {k:v for k,v in r.items() if k in CLOCK_KEYS}==corrected[r['case_id']]['corrected_clock_fields']
            assert x['reporting_correction']['reference_clock_source_sha256']==fp.sha(ROOT/'reference_clocks.py')
        assert r['status']=='entered'
        assert r['shortened_pre_entry_holds']==0
        assert all(z['dt']==c['dt'] for z in tr if z['mode']!='tail')
        assert r['max_abs_actuator']<=5
        assert all(r[k]>=0 for k in ['cert_min_h','cert_min_v','cert_min_M','cert_min_floor','cert_min_extension'])
        assert r['verified_conservative_entry_bound']
        assert r['T_entry_lower']-1e-12<=r['T']<=r['T_entry_upper']+1e-12
        assert 0<=r['sample_detection_delay']<=c['dt']+1e-12
        assert r['actual_parameter_difference_bound']<r['model_perturbation_bound']==2.**-40
        for a,b in zip(tr[:-1],tr[1:]):
            assert a['endpoint_radius_d']==b['sample_radius_d']
            assert a['endpoint_radius_v']==b['sample_radius_v']
        for z in tr:
            assert z['ok']
            if z['mode']=='nominal':assert not z['nominal_rejection_reasons']
            if z['mode'].startswith('witness_'):
                assert z['band_by_stored_witness']
                assert z['witness_clearance_margin']>=0
                uncertain+=int(z['witness_j0']!=z['witness_j1'])
        if c['v0']==0:
            p=next(p for p in fp.b.PLANTS if p.name==c['plant'])
            C=fp.constants(p,c['v0'],c['theta'],c['task'])
            guard,margin=fp.launch_guard(C,p,tr[0]['u'])
            assert guard
        rows.append(r);holds+=len(tr)
    assert len(rows)==192
    # Construct boxes that deliberately straddle the speed-cap/headway kink.
    # This forces a union-of-cells query rather than relying on chance in a run.
    synthetic=[]
    for p in fp.b.PLANTS:
      for v0 in [0.,.4]:
       for theta in [.25,.5]:
        for dt in [.01,.025]:
            C=fp.constants(p,v0,theta,'gap');cert=fp.stored_certificate(p,v0,theta,dt)
            x=float(Fraction(fp.DECIMAL[p.name][1])*Fraction('1.96'))
            xl=x-1e-9;xu=x+1e-9
            q=theta*cert.upper_energy(C,xl,xu);B=float(fp.ceiling(C,(xl,xu))[0])
            assert B>q
            e=(q+B)/2;v=math.sqrt(2*e)
            z=np.array([float(Fraction('.02')+Fraction(fp.DECIMAL[p.name][1])*Fraction('1.96')),v])
            w=np.array([1e-9,1e-10])
            W=cert.query(C,z,w)
            assert W.j0<W.j1
            cb,cq=fp.clearances(C,cert,W,z,w)
            assert W.uq<=W.uB or cb>=W.HB or cq>=W.Hq
            synthetic.append({'plant':p.name,'v0':v0,'theta':theta,'period':dt,
              'j0':W.j0,'j1':W.j1,'k':W.k,'uq':W.uq,'uB':W.uB,'HB':W.HB,'Hq':W.Hq,
              'upper_clearance_lower':cb,'lower_clearance_lower':cq})
    assert len(synthetic)==24
    # The zero-acceleration command at rest must never count as a positive launch.
    rest=[]
    for p in fp.b.PLANTS:
      for theta in [.25,.5]:
        C=fp.constants(p,0.,theta,'gap')
        command=-p.a(p.eps+.8,0.)
        ok,margin=fp.launch_guard(C,p,command)
        assert not ok
        rest.append({'plant':p.name,'theta':theta,'zero_acceleration_input':command,'guard_margin_lower':margin})
    timing=json.loads((ROOT/'serial_timing.json').read_text())
    assert timing['status']=='complete' and timing['all_decisions_reproduced_exactly']
    out={'status':'passed','case_count':len(rows),'total_holds':holds,
      'retained_production_source_hashes_verified':True,'reporting_clock_correction_fingerprints_verified':True,'control_definitions_unchanged_by_clock_correction':True,'fixed_pre_entry_periods':True,
      'no_reset_in_carried_state_radius':True,'all_nominal_accepts_pass_full_gate':True,
      'all_stored_witness_clearance_tests_pass':True,'all_rest_launch_guards_pass':True,
      'all_continuous_entry_brackets_contain_diagnostic_roots':True,
      'all_entry_upper_bounds_below_certified_W_lower':True,'all_detected_delays_below_period':True,
      'production_witnesses_with_multicell_sample_enclosures':uncertain,
      'deliberate_kink_straddling_boxes':synthetic,'zero_acceleration_rest_rejections':rest,
      'serial_replay_exact':True,'source_sha256':fp.sha(Path(__file__)),
      'scope':'Runtime result/invariant checks and adversarial boundary cases. The proof is the interval/comparison construction documented in METHOD.txt; finite trace checks alone are not a theorem.'}
    (ROOT/'audit_results.json').write_text(json.dumps(rm.safe(out),indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['deliberate_kink_straddling_boxes','zero_acceleration_rest_rejections']},indent=2))

if __name__=='__main__':main()
