V8: cache-corrected certified sampled-data recovery experiments
=============================================================

This package contains the frozen 360-case production study, corrected source,
separate focused revision validation, continuous
intersample certificates, original frozen nominal policies (in the sibling
manuscript/numerics/policies directory), figures and numerical summaries.
The controller holds the physical actuator input u, not net acceleration.
No physical state or energy is projected back into the safe set.

PRIMARY FILES
  protocol.json             Fixed case grid and final audited method definitions.
  summary.json              Compact results, paired comparisons and limitations.
  data/episodes.csv          All 360 scheduled cases, including naive failures.
  data/cases/*.json          Individual states, held commands and certificates.
  timing_summary.json       Serialized representative timing, separate from the
                            parallel production run.
  environment.json          Frozen production dependency/source provenance.
  revision_v8_validation.json Current source hashes, cache checks, six-profile
                            reconstruction, and four complete episode replays.
  run_summary.json          Final status counts (not an intermediate run).
  figures/ and tables/      Reproducible paper assets.

  certified_zoh.py           Certificate and controller implementation.
  certificate_rounding.py   Outward interval operations, residual bounds,
                            matrix error propagation and transcendental lookup.
  profile_bounds.py        Certified upper energy profile and lower optimal clock.
  outward_loop.c           Optional C99 acceleration of the same outward error
                            recurrence. It does not replace the proof or predicate.
  reference_v6.py          Frozen prior numerical model, nominal interpolation,
                            and high-accuracy reference profiles.
  run_matrix.py            Production experiment runner.
  analyze_v7.py            Tables, plots, complete-case classification.
  benchmark_v7.py          Serialized timing protocol.
  finalize_metadata.py     Final source/environment hashes and artifact manifest.
  finalize_data.py         Audit migration/refresh for the original production
                            snapshot; unnecessary for a new clean run.

DEPENDENCIES
  Python 3.12 was used. NumPy, SciPy, Matplotlib and pypdf are required;
  exact installed versions are recorded in environment.json. mpmath 1.3.0
  is vendored under vendor/ for interval arithmetic. No solver, optimizer,
  network service or proprietary control package is needed at run time.
  A C99 compiler is optional. To use the compiled outward loop:

      ./build_outward.sh

  The script explicitly disables fast math and floating-point contraction.
  If outward_loop.so cannot be loaded, the Python interval implementation
  is used automatically. A representative compiled/Python recurrence check
  was bit-for-bit identical. The portable C source and Python fallback are
  the reproducible deliverables; the shared object is platform specific.

READING THE DELIVERED RESULTS
  Reading summary.json or data/episodes.csv does not run the simulations.
  Rebuilding plots/tables from all saved cases is:

      python analyze_v7.py

  The analysis refuses an incomplete case set. Do not use a --limit run as
  the source of the manuscript's complete-case tables.

CLEAN RECOMPUTATION
  To recompute every final experiment rather than reuse results:

      ./build_outward.sh
      python run_matrix.py --fresh --workers 4
      python benchmark_v7.py
      python analyze_v7.py
      python finalize_metadata.py

  --fresh archives the existing case and profile caches under
  data/archived_runs/<timestamp>/ before recomputation. It does not silently
  overwrite the old experiment. Without --fresh, case results are reused
  only if the stored core-source hashes agree with the current source.
  Profile caches use an exact canonical construction identity and validate
  the complete requested data before reuse. The identity includes binary64
  gap, speed, extension and grid spacing; plant parameters and name; grid
  specification; precision; source fingerprint, dependency versions, and schema version.
  The loader also checks the payload, redundant metadata, exact grid,
  dimensions, finiteness and initial energy. Invalid or stale entries are
  recomputed, including a damaged compressed member; cache writes use atomic
  replacement. The older delivered
  profile files remain historical data and are not accepted as v3 caches.

  A clean run directly computes the final actual-nominal L1 and L2
  intervention metrics; finalize_data.py is NOT required. That script was
  used to migrate the initial production snapshot after independent audit:
  it reran affected cases and recomputed additional intervention metrics
  from the unchanged recorded holds. Audit snapshots are kept separately
  under data/pre_finalization and are not included in the final statistics.

CASE GRID
  Base: 3 plants x 2 tasks x 2 initial speeds x 4 nominals x 2 theta values
  x 3 methods = 288 cases. h0=0.8; v0=0 or 0.4; theta=0.25 or 0.5;
  requested period Delta=0.05. The initial gap is explicitly

      d0 = epsilon + h0 + gamma*v0.

  Four prespecified stress cases use three additional requested periods
  (0.0125, 0.025, 0.1), two theta values and three methods: 72 cases.
  All 360 scheduled cases are retained.

  Methods:
    band      Nominal first; complete-hold safety and theta-energy floor.
              At a rest start, an explicit full-throttle initialization is
              used. If the nominal is not certified, deterministic finite
              candidates and ten bisection refinements toward a tested
              feasible command are tried. This is not a claim of exact
              globally minimum intervention.
    progress  The previous progress-aware CBF request, with r=sqrt(theta),
              c=5, passed through the SAME complete-hold safety certificate.
              No theta-energy-floor guarantee is imposed on this baseline.
    naive     Sample the original continuous reflected law, hold u, and
              react to a band exit at the next sample. This is an explicitly
              declared implementation outside the theorem. State-domain
              violations and progress-floor violations are counted separately.

CERTIFICATE
  A cubic Hermite approximate curve is only a proposal. Its continuous
  residual is bounded analytically over every subcell using Bernstein
  polynomial ranges, interval derivatives and explicit Taylor remainders.
  Error radii are propagated with the OVM comparison matrix

      H = [[0,1],[alpha*L,-alpha]],

  including floating polynomial joins and endpoint representation errors.
  The radii are carried between sampling instants. All acceptance decisions
  use continuous tube bounds; checking a fine grid alone is not sufficient.

  The maximal energy profile is bounded above using constant-C scalar flows
  whose elementary clocks are enclosed by mpmath interval arithmetic. A
  numerically fitted DOP853 profile is not used as a safety oracle. The
  certified lower optimal clock is evaluated at a lower-rounded target
  travel and combines affine-energy and ceiling clock bounds.

  Full throttle preserves the exact floor analytically; it still receives
  the safety and profile-domain checks. Its reported floor lower margin is
  zero (not a fictitious strictly positive margin). Other candidates can
  use the profile enclosure or stronger ceiling-derived floor tests.

  If the requested period is not certified, it is halved explicitly and
  logged. A final analytic extreme-input witness uses a conservatively
  bounded short period; its uncertainty-aware opposite clearance is g/4
  and its period uses g/(8*K*M). No analytic fallback was needed in the
  final study. All 96 base band episodes used Delta=0.05 without shortening.
  One of 24 band sweep episodes, at requested Delta=0.1, used one 0.05 hold.

  Detected entry requires the upper endpoint gap enclosure to lie within
  the target. Because enclosure-based detection can be conservative, the
  exact-state theorem's +Delta detection statement is not automatically
  claimed for an arbitrary interval observer. Instead every reported band
  case passes the stronger directly checked inequality

      detected_time_upper <= Tstar_lower/sqrt(theta) + requested_Delta,

  with outward arithmetic. The high-accuracy root-based first-entry time
  and its ratio are diagnostic values; the certified detected-time check
  is recorded separately.

COMMON-HORIZON METRICS
  Every certified method uses the same post-entry tangent command, with a
  small certificate-checked positivity correction when accumulated state
  enclosures make the uncorrected floating evaluation inconclusive. This
  correction is recorded. Safety is certified through the numerical H=10
  horizon; asymptotic convergence of this corrected numerical policy is
  not asserted. The manuscript's exact-state analytic tail proposition is
  a separate statement.

  Final holds are truncated at H=10 for metric integration. The state is
  never clipped. Running cost:
    gap:       0.2*u^2 + 50*d^2
    tracking:  0.2*u^2 + v^2 + 5*(h-0.2)^2.
  Costs from these different objectives must not be pooled as a common
  physical utility. Task-specific and paired ratios are supplied.

  I10_L1: integral_0^10 |u(t)-k(t,d(t),v(t))| dt.
  I10_L2: integral_0^10 |u(t)-k(t,d(t),v(t))|^2 dt.
  I1_sampled10 / I2_sampled10: the corresponding sampled-request distortion,
  using k at the start of each actual hold. These are distinct metrics.
  RMS_acc10: root mean square net acceleration.
  TV_acc10: acceleration variation within holds plus jump magnitudes.
  max_acc_jump: largest command-induced acceleration jump.

  Costs and comfort values use 12-node Gauss integration and high-accuracy
  held trajectories; they are numerical estimates, not interval-enclosed
  cost functionals. No bounded-jerk guarantee is claimed.

INTERPRETATION AND RUNTIME
  The new result is safety plus a certified recovery-time bound. It does
  not establish empirical speed, cost or comfort dominance over the strong
  progress-aware baseline. The summary reports every paired comparison.

  timing_summary.json times the full certificate search in a serialized
  process, separately from offline reference construction. The validated
  Python implementation with ten search refinements often exceeds a 50 ms
  budget. This is an offline validated numerical study, not a demonstrated
  hard real-time deployment. Compilation or future search optimization is
  not counted as experimental evidence.

V8 CORRECTION AND VALIDATION
  The earlier rounded cache name could confuse distinct initial speeds,
  such as .4 and .4000001. The repaired disk, memory and lower-clock caches
  use the complete exact construction identity. This fixes reuse for new
  initial states without changing the physical controller or profile math.

  All 22 cache regression checks pass. All six production reference profiles
  were rebuilt from scratch; their spatial grids and upper-envelope arrays
  match the frozen profiles bit for bit. Four complete episodes (701 holds)
  were rerun using fresh validated caches: C3 rest/opposing, C1 rest/opposing,
  C3 moving/HJB band, and C2 moving/HJB progress. Every held actuator, mode,
  and pre-entry period matches the saved trajectory. Non-timing metric
  differences are at roundoff scale. The full 360-case matrix and serialized
  timing benchmark were not rerun. None of their recorded values was changed.

  From the outer complete-archive directory, rerun the focused checks with:
      python checks/test_profile_cache.py -v
      python checks/validate_profile_cache_revision.py
  Both accept --package /absolute/path/to/numerics_v7 or ECC_NUMERICS_PACKAGE.
  The latter optionally accepts --baseline-package to compare against a
  separate authoritative V7 package and reproduce the original-code defect.
  Outputs are separate from the production data. See the script help for
  choosing another evidence directory.

  environment.json remains the original production snapshot; its old core
  hashes intentionally differ for the two repaired files. Current hashes
  and precise validation provenance are in revision_v8_validation.json.
  The original artifact manifest is preserved under provenance/. The
  current artifact manifest accounts for this README and validation record.
