"""Outward upper enclosure of the OVM maximal spatial energy profile.

The numerical profile used for plotting is not used as a safety oracle.
On every spatial cell C(s)=alpha*V(d0-s)+U is bounded above by its
left-end value (all supplied V are nondecreasing).  A constant-C flow
dominates the unrestricted energy flow and therefore also the reflected
profile.  The exact flow is evaluated through its elementary physical
clock, with time brackets checked using mpmath interval arithmetic.

Online evaluations use a conservative linear upper envelope within a
cell, capped by the safety ceiling.  Only the offline endpoint update
needs transcendental arithmetic.  Inputs and returned interval endpoints
are binary64 values. Every offline interval-to-float conversion is enlarged
by one representable number; elementary online upper operations are also
rounded outward.  This enclosure is for the autonomous OVM fixtures only.
"""
from __future__ import annotations
import hashlib
import json
import math
import os
import platform
import tempfile
import time
import sys
import zipfile
import zlib
from pathlib import Path
import numpy as np
import scipy
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
import mpmath
from mpmath import iv
from scipy.optimize import brentq

iv.dps = 40

# Invalidate caches when recorded source, configuration, or dependency versions
# change; this is not a complete platform or libm fingerprint.
# The mathematics version below is unchanged; v3 changes only cache storage.
_SOURCE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def _canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)

def _finite_hex(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError('Profile inputs must be finite binary64 values')
    return value.hex()

def _payload_sha256(payload):
    """Checksum typed NPZ contents, independent of ZIP timestamps/compression.

    This detects accidental corruption or edits, not a hostile party able to
    replace both the data and its checksum. Cache files remain trusted inputs.
    """
    digest = hashlib.sha256()
    for name in sorted(payload):
        value = np.asarray(payload[name])
        digest.update(name.encode('utf-8') + b'\0')
        digest.update(value.dtype.str.encode('ascii') + b'\0')
        digest.update(_canonical_json(value.shape).encode('ascii') + b'\0')
        digest.update(value.tobytes(order='C'))
    return digest.hexdigest()

def up(x):
    return math.nextafter(float(x), math.inf)

def down(x):
    return math.nextafter(float(x), -math.inf)

def point(x):
    return iv.mpf(float(x))

def ihigh(x):
    return up(float(x.b))

def ilow(x):
    return down(float(x.a))

def parameter(x):
    # Include both the stored binary64 value and its printed decimal datum.
    return iv.mpf([down(x), up(x)])

def iv_tanh(x):
    y = iv.exp(2*x)
    return (y-1)/(y+1)

def constant_c_upper(E0, C, alpha, h):
    """Upper energy after an exact spatial length h for constant C>0.

    E0,C,alpha,h are nonnegative point data, alpha>0.  Monotonicity of
    speed toward C/alpha determines which verified clock endpoint gives
    an upper energy.  No root-solver error estimate is trusted.
    """
    if h <= 0:
        return up(E0)
    ei, ci, ai, hi = point(E0), point(C), point(alpha), point(h)
    vi = iv.sqrt(2*ei)
    veq = ci/ai
    vlo, vhi, clo, chi = ilow(vi), ihigh(vi), ilow(veq), ihigh(veq)
    if vhi >= clo and vlo <= chi:
        return ihigh(iv.mpf('0.5')*iv.mpf(max(vhi,chi))**2)
    increasing = vhi < clo
    v0, c = math.sqrt(2*E0), C/alpha

    def clock_float(t):
        return c*t+(v0-c)*(-math.expm1(-alpha*t))/alpha

    def clock_interval(t):
        ti = point(t)
        return veq*ti+(vi-veq)*(1-iv.exp(-ai*ti))/ai

    top = max(1e-12, math.sqrt(2*h/C)+alpha*h/C+h/max(c,1e-12))
    while clock_float(top) < h:
        top *= 2
    root = brentq(lambda t: clock_float(t)-h, 0., top,
                  xtol=5e-15, rtol=1e-14)
    radius = max(2e-14, abs(root)*2e-12)
    for _ in range(30):
        tl = max(0., down(root-radius))
        tr = up(root+radius)
        if ihigh(clock_interval(tl)) <= ilow(hi) and ilow(clock_interval(tr)) >= ihigh(hi):
            break
        radius *= 4
    else:
        raise ArithmeticError('Failed to validate constant-C clock bracket')
    ti = point(tr if increasing else tl)
    vt = vi*iv.exp(-ai*ti)+veq*(1-iv.exp(-ai*ti))
    return ihigh(iv.mpf('0.5')*vt**2)


class ProfileUpper:
    """Certified upper envelope, on 0 <= s <= d0-target_ext.

    range_upper accepts an interval already known to intersect the
    monotone (v>=0) episode. A negative left endpoint may be intersected
    with s>=0 only under that caller's monotonicity certificate.
    """
    version = 'constant-C-interval-clock-v2'
    cache_format = 'profile-upper-cache-v3'

    @classmethod
    def cache_spec(cls, p, d0, v0, target_ext, ds=1e-4):
        """Exact construction request, including numerical configuration.

        No decimal rounding is used. Source/dependency identities cover the
        fixed algorithm constants as well as implementation-dependent grids.
        The current interval precision is recorded rather than assumed.
        """
        d0, v0, target_ext, ds = map(float, (d0, v0, target_ext, ds))
        initial = {name: _finite_hex(value) for name, value in
                   [('d0', d0), ('v0', v0), ('target_ext', target_ext), ('ds', ds)]}
        parameters = {name: _finite_hex(getattr(p, name)) for name in
                      ['alpha', 'gamma', 'eps', 'M', 'U']}
        S = d0-target_ext
        if not math.isfinite(S) or S <= 0 or target_ext <= p.eps:
            raise ValueError('Profile extension must have positive travel above epsilon')
        if ds <= 0 or v0 < 0 or p.alpha <= 0 or p.gamma <= 0:
            raise ValueError('Profile requires positive spacing, alpha and gamma, and nonnegative speed')
        cells = max(1, math.ceil(S/ds))
        return {
            'cache_format': cls.cache_format,
            'mathematics_version': cls.version,
            'source_sha256': _SOURCE_SHA256,
            'plant': str(p.name),
            'plant_parameters_binary64': parameters,
            'initial_and_grid_binary64': initial,
            'grid': {'kind': 'numpy.linspace', 'cells': cells, 'travel_binary64': S.hex()},
            'interval_precision_bits': int(iv.prec),
            'runtime': {'python': platform.python_version(), 'numpy': np.__version__,
                        'scipy': scipy.__version__, 'mpmath': mpmath.__version__},
        }

    @classmethod
    def cache_key(cls, p, d0, v0, target_ext, ds=1e-4):
        spec = cls.cache_spec(p, d0, v0, target_ext, ds)
        return hashlib.sha256(_canonical_json(spec).encode('utf-8')).hexdigest()

    def __init__(self, p, d0, v0, target_ext, ds=1e-4, cache=None):
        started = time.perf_counter()
        self.p, self.d0, self.v0 = p, float(d0), float(v0)
        self.target_ext, self.ds = float(target_ext), float(ds)
        self._construction_spec = self.cache_spec(p, self.d0, self.v0, self.target_ext, self.ds)
        self.cache_identity = hashlib.sha256(_canonical_json(self._construction_spec).encode('utf-8')).hexdigest()
        self.S = self.d0-self.target_ext
        if self.S <= 0 or target_ext <= p.eps:
            raise ValueError('Profile extension must have positive travel above epsilon')
        self.alpha_lo = down(p.alpha)
        self.gamma_lo, self.eps_lo, self.M_hi = down(p.gamma), down(p.eps), up(p.M)
        n = self._construction_spec['grid']['cells']
        self.s = np.linspace(0.,self.S,n+1)
        self.ds_max = up(float(np.max(np.diff(self.s))))
        self.E_upper = np.empty(n+1)
        self.C_upper = np.empty(n)
        self.E_upper[0] = 0. if v0 == 0 else ihigh(point(.5)*point(v0)**2)
        ai, ui = parameter(p.alpha), parameter(p.U)
        def V_interval(d):
            if p.name == 'C3':
                raw=parameter(.8)*(d-parameter(.1))
                return iv.mpf([max(0.,min(1.5,ilow(raw))),max(0.,min(1.5,ihigh(raw)))])
            return iv_tanh(d)-iv_tanh(point(2.))
        self.bracket_calls = 0
        for j in range(n):
            dj = point(self.d0)-point(self.s[j])
            Cj = ihigh(ai*V_interval(dj)+ui)
            if Cj <= 0:
                raise ValueError('Constant-C enclosure requires positive upper authority')
            self.C_upper[j] = Cj
            step_i = point(self.s[j+1])-point(self.s[j])
            # The flow is monotone toward its equilibrium.  Use the side
            # of the length interval that increases its energy.
            vj_hi = ihigh(iv.sqrt(2*point(self.E_upper[j])))
            veq_lo = ilow(point(Cj)/point(self.alpha_lo))
            step = ihigh(step_i) if vj_hi <= veq_lo else max(0.,ilow(step_i))
            end = constant_c_upper(self.E_upper[j],Cj,self.alpha_lo,step)
            self.bracket_calls += 1
            self.E_upper[j+1] = min(end,self.ceiling_upper(self.s[j+1]))
        self.offline_seconds = time.perf_counter()-started
        if cache is not None:
            self.save(cache)

    def ceiling_upper(self, s):
        distance = up(up(self.d0-float(s))-self.eps_lo)
        vb = min(self.M_hi, up(distance/self.gamma_lo))
        if vb < 0:
            raise ValueError('Ceiling requested below stopped corner')
        return up(.5*up(vb*vb))

    def upper(self, s):
        s=float(s)
        if s < 0 or s > self.S:
            raise ValueError(f'Profile query {s} outside [0,{self.S}]')
        if s == 0:
            return float(self.E_upper[0])
        j=min(len(self.C_upper)-1,int(np.searchsorted(self.s,s,side='right')-1))
        dr=max(0.,up(s-float(self.s[j])))
        line=up(float(self.E_upper[j])+up(float(self.C_upper[j])*dr))
        return min(line,self.ceiling_upper(s))

    def range_upper(self, slo, shi):
        slo,shi=float(slo),float(shi)
        if shi < 0 or shi > self.S or slo > shi:
            raise ValueError(f'Profile interval [{slo},{shi}] outside domain')
        slo=max(0.,slo)
        if slo == shi:
            return self.upper(slo)
        first=max(0,int(np.searchsorted(self.s,slo,side='right')-1))
        last=min(len(self.C_upper)-1,int(np.searchsorted(self.s,shi,side='left')))
        result=0.
        for j in range(first,last+1):
            left=max(slo,float(self.s[j]))
            right=min(shi,float(self.s[j+1]))
            if right < left:
                continue
            dr=max(0.,up(right-float(self.s[j])))
            line=up(float(self.E_upper[j])+up(float(self.C_upper[j])*dr))
            result=max(result,min(line,self.ceiling_upper(left)))
        return up(result)

    def clock_lower(self, S):
        """Certified lower bound on the true optimal clock to travel S.

        On a cell E+ is at most the positive affine upper envelope. Its
        inverse-speed integral is elementary, including the initial
        square-root singularity. Ignoring the ceiling only weakens this
        lower bound. Binary square roots are enlarged before division.
        """
        S=float(S)
        if not 0 <= S <= self.S:
            raise ValueError('Clock prefix outside reference domain')
        total=0.
        for j in range(len(self.C_upper)):
            left=float(self.s[j])
            if left >= S:
                break
            right=min(S,float(self.s[j+1]))
            h_lo=max(0.,down(right-left))
            h_hi=up(right-left)
            initial=float(self.E_upper[j])
            terminal=up(initial+up(float(self.C_upper[j])*h_hi))
            v0=0. if initial == 0 else up(math.sqrt(up(2*initial)))
            v1=up(math.sqrt(up(2*terminal)))
            denominator=up(v0+v1)
            line_clock=max(0.,down((2*h_lo)/denominator))
            cap_clock=max(0.,down(h_lo/self.M_hi))
            left_gap=point(self.d0)-point(left)-point(self.eps_lo)
            right_gap=point(self.d0)-point(right)-point(self.eps_lo)
            headway_clock=max(0.,ilow(point(self.gamma_lo)*iv.log(left_gap/right_gap)))
            # Each of the three pointwise energy upper bounds gives a
            # lower clock integral; their maximum remains a lower bound.
            contribution=max(line_clock,cap_clock,headway_clock)
            total=max(0.,down(total+contribution))
        return total

    def save(self, path):
        """Atomically save a complete request-bound cache with an integrity digest."""
        current = self.cache_spec(self.p, self.d0, self.v0, self.target_ext, self.ds)
        if current != self._construction_spec:
            raise ValueError('Profile construction configuration changed before saving')
        payload = dict(s=self.s, E_upper=self.E_upper, C_upper=self.C_upper,
            d0=self.d0, v0=self.v0, target_ext=self.target_ext, ds=self.ds,
            alpha_lo=self.alpha_lo, offline_seconds=self.offline_seconds,
            version=self.version, plant=self.p.name,
            parameters=np.array([self.p.alpha, self.p.gamma, self.p.eps, self.p.M, self.p.U], dtype=np.float64),
            cache_format=self.cache_format,
            construction_spec=_canonical_json(self._construction_spec),
            cache_identity=self.cache_identity)
        payload['payload_sha256'] = _payload_sha256(payload)
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        # A failed/interrupted write must not leave a partially written target.
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=path.parent, suffix='.npz', delete=False) as handle:
                temporary = Path(handle.name)
                np.savez_compressed(handle, **payload)
            os.replace(temporary, path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    @classmethod
    def load(cls, p, path, *, d0, v0, target_ext, ds=1e-4):
        """Load only a cache for the exact requested construction.

        The request arguments are mandatory: inferring them from the file
        would repeat the original rounded-filename collision. Legacy files
        without a v3 descriptor/checksum are stale and must be recomputed.
        """
        spec = cls.cache_spec(p, d0, v0, target_ext, ds)
        canonical = _canonical_json(spec)
        identity = hashlib.sha256(canonical.encode('utf-8')).hexdigest()
        expected_fields = {'s', 'E_upper', 'C_upper', 'd0', 'v0', 'target_ext',
            'ds', 'alpha_lo', 'offline_seconds', 'version', 'plant', 'parameters',
            'cache_format', 'construction_spec', 'cache_identity', 'payload_sha256'}
        try:
            with np.load(path, allow_pickle=False) as z:
                if set(z.files) != expected_fields or len(z.files) != len(expected_fields):
                    raise ValueError('Profile cache schema mismatch; recomputation required')
                payload = {name: z[name] for name in z.files}
            def text(name):
                value = payload[name]
                if value.shape != () or value.dtype.kind != 'U':
                    raise ValueError('Invalid profile cache text field: ' + name)
                return str(value.item())
            if text('cache_format') != cls.cache_format or text('version') != cls.version:
                raise ValueError('Profile cache format/version mismatch')
            if text('construction_spec') != canonical or text('cache_identity') != identity:
                raise ValueError('Profile cache construction request mismatch')
            checksum = text('payload_sha256')
            if checksum != _payload_sha256({k: v for k, v in payload.items() if k != 'payload_sha256'}):
                raise ValueError('Profile cache payload checksum mismatch')
            if text('plant') != str(p.name):
                raise ValueError('Profile cache plant mismatch')
            def scalar(name):
                value = payload[name]
                if value.shape != () or value.dtype != np.dtype('float64'):
                    raise ValueError('Invalid profile cache scalar: ' + name)
                return float(value)
            for name, requested in [('d0', d0), ('v0', v0), ('target_ext', target_ext), ('ds', ds)]:
                if _finite_hex(scalar(name)) != _finite_hex(requested):
                    raise ValueError('Profile cache initial/grid value mismatch: ' + name)
            parameters = np.asarray([p.alpha, p.gamma, p.eps, p.M, p.U], dtype=np.float64)
            stored = payload['parameters']
            if stored.dtype != parameters.dtype or stored.shape != parameters.shape or stored.tobytes() != parameters.tobytes():
                raise ValueError('Profile cache plant parameters mismatch')
            if _finite_hex(scalar('alpha_lo')) != _finite_hex(down(p.alpha)):
                raise ValueError('Profile cache outward alpha mismatch')
            seconds = scalar('offline_seconds')
            if not math.isfinite(seconds) or seconds < 0:
                raise ValueError('Invalid profile cache construction duration')
            n = spec['grid']['cells']
            S = float(d0)-float(target_ext)
            s, energy, authority = [payload[name] for name in ('s', 'E_upper', 'C_upper')]
            for name, values, shape in [('s', s, (n+1,)), ('E_upper', energy, (n+1,)), ('C_upper', authority, (n,))]:
                if values.dtype != np.dtype('float64') or values.shape != shape or not np.all(np.isfinite(values)):
                    raise ValueError('Invalid profile cache array: ' + name)
            expected_grid = np.linspace(0., S, n+1)
            if s.tobytes() != expected_grid.tobytes() or np.any(np.diff(s) <= 0):
                raise ValueError('Profile cache grid mismatch')
            initial = 0. if float(v0) == 0 else ihigh(point(.5)*point(v0)**2)
            if _finite_hex(energy[0]) != _finite_hex(initial) or np.any(energy < 0) or np.any(authority <= 0):
                raise ValueError('Profile cache initial energy/array bounds mismatch')
        except (KeyError, TypeError, OverflowError, UnicodeError, EOFError, zipfile.BadZipFile, zlib.error) as error:
            raise ValueError('Malformed profile cache; recomputation required') from error
        obj = cls.__new__(cls)
        obj.p, obj.d0, obj.v0 = p, float(d0), float(v0)
        obj.target_ext, obj.ds, obj.S = float(target_ext), float(ds), S
        obj._construction_spec, obj.cache_identity = spec, identity
        obj.alpha_lo = down(p.alpha)
        obj.gamma_lo, obj.eps_lo, obj.M_hi = down(p.gamma), down(p.eps), up(p.M)
        obj.s, obj.E_upper, obj.C_upper = s, energy, authority
        obj.ds_max = up(float(np.max(np.diff(obj.s))))
        obj.offline_seconds, obj.bracket_calls = seconds, n
        return obj
