#!/usr/bin/env python3
"""Create figures, tables, and the concise V7 numerical assessment."""
from pathlib import Path
import json,math,csv,os,sys,shutil
import numpy as np
os.environ.setdefault('MPLCONFIGDIR','/tmp/ecc_v7_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import certified_zoh as c
for name in ['figures','tables']:(ROOT/name).mkdir(exist_ok=True)
js=[json.loads(p.read_text()) for p in (ROOT/'data'/'cases').glob('*.json')]
rows=[j['row'] for j in js]
if len(rows)!=360:raise RuntimeError('Main analysis requires the complete frozen 360-case experiment; use run_matrix.py without a limit/group filter.')
# Recheck naive speed cap from its held physical trajectories. Safety-domain
# violations are kept distinct from performance-floor violations.
for j in js:
 r=j['row']
 if r['method']!='naive':continue
 p=next(p for p in c.base.PLANTS if p.name==r['plant']);mv=-math.inf
 for tr in j['trace']:
  u=tr['u'];dt=tr['dt'];z=[tr['d'],tr['v']]
  sol=solve_ivp(lambda t,y:[-y[1],p.a(*y)+u],(0,dt),z,method='DOP853',rtol=2e-12,atol=2e-14,max_step=dt/8,dense_output=True)
  mv=max(mv,float(np.max(sol.sol(np.linspace(0,dt,101))[1])))
 r['v_max_diagnostic']=mv;r['speed_cap_violation']=bool(mv>p.M+1e-8)
 r['domain_violation']=bool(r['headway_violation'] or r['speed_violation'] or r['speed_cap_violation'])
 (ROOT/'data'/'cases'/f'{r["case_id"]}.json').write_text(json.dumps(j,indent=2))

def subset(group='base',method=None,theta=None):return [r for r in rows if r['group']==group and (method is None or r['method']==method) and (theta is None or r['theta']==theta)]
def stats(rr):
 return {'n':len(rr),'entered':sum(r['status']=='entered' for r in rr),
  'median_ratio':float(np.median([r['ratio'] for r in rr if r.get('ratio') is not None])),
  'max_ratio':max(r['ratio'] for r in rr if r.get('ratio') is not None),
  **{f'median_{m}':float(np.median([r[m] for r in rr])) for m in ['J10','I10_L1','I10_L2','I1_sampled10','I2_sampled10','RMS_acc10','TV_acc10','max_acc_jump']},
  'verified_detection_count':sum(r.get('verified_detection_bound',False) for r in rr),
  'fixed_requested_period':sum(r['shortened_holds']==0 for r in rr),'shortened_holds':sum(r['shortened_holds'] for r in rr),
  'analytic_fallback_holds':sum(r['analytic_fallback_holds'] for r in rr),
  'min_certified_headway':min(r['cert_min_h'] for r in rr),
  'max_state_error':max(r['max_state_error'] for r in rr),'max_tail_correction':max(r['tail_correction_max'] for r in rr)}
summary={'base':{},'sweep':{},'paired_counts':{},'protocol_cases':len(rows)}
for method in ['band','progress']:
 for theta in [.25,.5]:summary['base'][f'{method}_{theta}']=stats(subset(method=method,theta=theta))
summary['sweep']['band']=stats(subset(group='sweep',method='band'))
summary['sweep']['progress']=stats(subset(group='sweep',method='progress'))
na=subset(method='naive')
summary['naive_base']={'n':len(na),'entered':sum(r['status']=='entered' for r in na),
 'headway_violations':sum(r['headway_violation'] for r in na),'nonnegative_speed_violations':sum(r['speed_violation'] for r in na),
 'speed_cap_violations':sum(r['speed_cap_violation'] for r in na),'domain_violations':sum(r['domain_violation'] for r in na),
 'performance_floor_violations':sum(r['floor_violation'] for r in na),
 'entered_without_observed_domain_violation':sum(r['status']=='entered' and not r['domain_violation'] for r in na),
 'min_headway':min(r['h_min_diagnostic'] for r in na)}
key=lambda r:(r['plant'],r['task'],r['v0'],r['nominal'],r['theta'],r['dt'])
bd={key(r):r for r in subset(method='band')};pr={key(r):r for r in subset(method='progress')}
for metric in ['T','J10','I10_L1','I10_L2','I1_sampled10','I2_sampled10','RMS_acc10','TV_acc10','max_acc_jump']:
 diff=np.array([bd[k][metric]-pr[k][metric] for k in bd])
 summary['paired_counts'][metric]={'band_lower':int(np.sum(diff< -1e-10)),'progress_lower':int(np.sum(diff>1e-10)),'ties':int(np.sum(np.abs(diff)<=1e-10)),'n':len(diff),'median_difference':float(np.median(diff))}
summary['task_costs']={}
for task in ['gap','tracking']:
 for theta in [.25,.5,'all']:
  kk=[k for k in bd if k[1]==task and (theta=='all' or k[4]==theta)]
  summary['task_costs'][f'{task}_{theta}']={
   'n':len(kk),'median_J_band':float(np.median([bd[k]['J10'] for k in kk])),
   'median_J_progress':float(np.median([pr[k]['J10'] for k in kk])),
   'median_I1_band':float(np.median([bd[k]['I10_L1'] for k in kk])),
   'median_I1_progress':float(np.median([pr[k]['I10_L1'] for k in kk])),
   'median_paired_cost_ratio':float(np.median([bd[k]['J10']/pr[k]['J10'] for k in kk])),
   'median_paired_I1_ratio':float(np.median([bd[k]['I10_L1']/pr[k]['I10_L1'] for k in kk])),
   'band_lower_cost':sum(bd[k]['J10']<pr[k]['J10']-1e-10 for k in kk),
   'band_lower_I1':sum(bd[k]['I10_L1']<pr[k]['I10_L1']-1e-10 for k in kk)}

# Generic theorem step and uncertainty-aware analytic implementation step.
fallback=[]
for p in c.base.PLANTS:
 for v0 in [0.,.4]:
  d0=p.eps+.8+p.gamma*v0;P,Q=c.profiles(p,d0,v0,p.eps+.002)
  for theta in [.25,.5]:
   g=(1-theta)*p.B(P.target);bound=p.alpha*(max(abs(float(c.V(p,p.eps))),abs(float(c.V(p,d0))))+p.M)+p.U
   LB=p.M/p.gamma;K=bound+max(theta*max(bound,LB),LB)
   dtheorem=g/(4*K*p.M);dimplementation=g/(8*K*p.M)
   fallback.append({'plant':p.name,'v0':v0,'theta':theta,'delta_theorem':dtheorem,'delta_box_witness':dimplementation})
summary['global_fallback']={'rows':fallback,'theorem_min':min(x['delta_theorem'] for x in fallback),'theorem_max':max(x['delta_theorem'] for x in fallback),'box_min':min(x['delta_box_witness'] for x in fallback),'box_max':max(x['delta_box_witness'] for x in fallback),'used_count':sum(r.get('analytic_fallback_holds',0) for r in rows)}
summary['certification']={'band_verified_all':all(r['verified_detection_bound'] for r in rows if r['method']=='band'),
 'all_held_actuators_bounded':all(r.get('max_abs_actuator',0)<=5 for r in rows if r['method']!='naive'),
 'all_cost_horizons_within_1e_10_of_10':all(abs(r.get('cost_horizon_actual',10)-10)<1e-10 for r in rows if r['method']!='naive'),
 'positive_profile_extension_margin':min(r['profile_extension_margin'] for r in rows if r['method']=='band'),
 'no_state_projection':True,'cost_integrals_are_diagnostic_not_interval_enclosures':True}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2))
run_status={'count':len(rows),'final_after_audit':True,'status_counts':{str((g,m,st)):sum((r['group'],r['method'],r['status'])==(g,m,st) for r in rows) for g,m,st in set((r['group'],r['method'],r['status']) for r in rows)}}
(ROOT/'run_summary.json').write_text(json.dumps(run_status,indent=2));(ROOT/'data'/'run_summary.json').write_text(json.dumps(run_status,indent=2))
# Final CSV with explicit naive D and floor classifications.
fields=sorted(set().union(*(r.keys() for r in rows)))
with (ROOT/'data'/'episodes.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def f(x):return f'{x:.3f}'
lines=['\\begin{tabular}{lrrrrr}','\\toprule','Method & $\\theta$ & Med. $T/T^*$ & Max. $T/T^*$ & Med. $J_{10}$ & Med. $I_{1,10}$\\\\','\\midrule']
for method,label in [('band','Certified band'),('progress','Certified progress')]:
 for th in [.25,.5]:
  z=summary['base'][f'{method}_{th}'];lines.append(f'{label} & {th:g} & {f(z["median_ratio"])} & {f(z["max_ratio"])} & {f(z["median_J10"])} & {f(z["median_I10_L1"])}\\\\')
lines+=['\\bottomrule','\\end{tabular}']
(ROOT/'tables'/'main_summary.tex').write_text('\n'.join(lines)+'\n')
lines=['\\begin{tabular}{lrrrr}','\\toprule','Method & $\\theta$ & $N$ & Med. $T/T^*$ & Max. $T/T^*$\\\\','\\midrule']
for method,label in [('band','Certified band'),('progress','Certified progress')]:
 for th in [.25,.5]:
  z=summary['base'][f'{method}_{th}'];lines.append(f'{label} & {th:g} & {z["n"]} & {f(z["median_ratio"])} & {f(z["max_ratio"])}\\\\')
lines+=['\\bottomrule','\\end{tabular}']
(ROOT/'tables'/'rate_summary.tex').write_text('\n'.join(lines)+'\n')
lines=['\\begin{tabular}{lrr}','\\toprule','Metric & Band lower & Progress lower\\\\','\\midrule']
for metric,label in [('T','Entry time'),('J10','$J_{10}$'),('I10_L1','$I_{1,10}$'),('I10_L2','$I_{2,10}$'),('RMS_acc10','Acceleration RMS'),('TV_acc10','Acceleration TV')]:
 z=summary['paired_counts'][metric];lines.append(f'{label} & {z["band_lower"]}/96 & {z["progress_lower"]}/96\\\\')
lines+=['\\bottomrule','\\end{tabular}']
(ROOT/'tables'/'paired_counts.tex').write_text('\n'.join(lines)+'\n')
lines=['\\begin{tabular}{lrrrr}','\\toprule','Controller & $N$ & Entry & Domain exits & Floor exits\\\\','\\midrule',
 'Naive ZOH & 96 & 70 & '+str(summary['naive_base']['domain_violations'])+' & '+str(summary['naive_base']['performance_floor_violations'])+'\\\\',
 'Certified band & 96 & 96 & 0 & 0\\\\','Certified progress & 96 & 96 & 0 & --\\\\','\\bottomrule','\\end{tabular}']
(ROOT/'tables'/'safety_summary.tex').write_text('\n'.join(lines)+'\n')
# Figures.
plt.rcParams.update({'font.size':8,'axes.labelsize':8,'legend.fontsize':7,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42})
colors={'band':'#005A9C','progress':'#168C6D','naive':'#B33A3A'}

def findcase(method,theta=.25):
 return next(j for j in js if j['row']['plant']=='C3' and j['row']['task']=='gap' and j['row']['v0']==.4 and j['row']['nominal']=='hjb' and j['row']['theta']==theta and j['row']['dt']==.05 and j['row']['method']==method)
def dense(j):
 r=j['row'];p=next(p for p in c.base.PLANTS if p.name==r['plant']);out=[]
 end=r['T_detected'] if r.get('T_detected') else r['T']
 for tr in j['trace']:
  if tr['t']>end+1e-10:break
  dt=min(tr['dt'],end-tr['t']);u=tr['u'];z=[tr['d'],tr['v']]
  if dt<=0:continue
  sol=solve_ivp(lambda t,y:[-y[1],p.a(*y)+u],(0,dt),z,method='DOP853',rtol=2e-12,atol=2e-14,dense_output=True)
  ts=np.linspace(0,dt,21);ys=sol.sol(ts)
  for t,d,v in zip(ts,*ys):out.append([tr['t']+t,d,v,d-p.gamma*v-p.eps,u,p.a(d,v)+u])
 return np.array(out)
fig,ax=plt.subplots(1,2,figsize=(7.05,2.5))
p=c.base.PLANTS[2];d0=.96;P,Q=c.profiles(p,d0,.4,p.eps+.002)
d=np.linspace(.03,d0,1200);s=d0-d;vmax=np.array([p.ceiling_v(x) for x in d]);floor=np.sqrt(.5*np.array([P.E(x) for x in s]))
ax[0].fill_between(d,floor,vmax,color='#E5EFF5',label=r'$\sqrt{\theta}\,v^+\leq v\leq\bar v$')
ax[0].plot(d,vmax,color='black',lw=.8);ax[0].plot(d,floor,color='black',ls=':',lw=.8)
for method,label in [('naive','Naive ZOH'),('band','Certified band'),('progress','Certified progress')]:
 z=dense(findcase(method));ax[0].plot(z[:,1],z[:,2],color=colors[method],lw=1.2,label=label)
 ax[1].plot(z[:,0],z[:,3],color=colors[method],lw=1.2,label=label)
ax[0].set(xlabel='Gap $d$',ylabel='Speed $v$',xlim=(.96,.02));ax[0].legend(loc='upper left',frameon=False,fontsize=6.5)
ax[1].axhline(0,color='black',lw=.8);ax[1].set(xlabel='Time',ylabel='Headway residual $h$',xlim=(.25,1.8),ylim=(-.125,.12))
ax[1].text(.98,.04,'Boundary-contact detail',ha='right',transform=ax[1].transAxes,fontsize=7)
for a in ax:a.grid(alpha=.18)
fig.tight_layout(pad=.7);fig.savefig(ROOT/'figures'/'sample_hold_failure_and_repair.pdf');fig.savefig(ROOT/'figures'/'sample_hold_failure_and_repair.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(7.05,2.55))
for theta,ls in [(.25,'-'),(.5,'--')]:
 for method in ['band','progress']:
  vv=np.sort([r['ratio'] for r in subset(method=method,theta=theta)])
  ax[0].step(vv,np.arange(1,len(vv)+1)/len(vv),where='post',color=colors[method],ls=ls,lw=1.2,label=f'{method}, $\\theta={theta:g}$')
ax[0].axvline(2,color='0.6',ls=':',lw=.8);ax[0].axvline(math.sqrt(2),color='0.6',ls=':',lw=.8)
ax[0].set(xlabel='$T/T^*$',ylabel='Fraction of cases',xlim=(.98,2.03),ylim=(0,1.03));ax[0].legend(frameon=False,fontsize=6.5,loc='lower right')
for theta,marker in [(.25,'o'),(.5,'^')]:
 kk=[k for k in bd if k[4]==theta];x=np.array([100*(bd[k]['J10']/pr[k]['J10']-1) for k in kk]);y=np.array([100*(bd[k]['I10_L1']/pr[k]['I10_L1']-1) if pr[k]['I10_L1']>1e-12 else np.nan for k in kk])
 ax[1].scatter(x,y,s=16,marker=marker,alpha=.7,color=colors['band'] if theta==.25 else '#AA6A00',label=f'$\\theta={theta:g}$')
ax[1].axhline(0,color='0.4',lw=.7);ax[1].axvline(0,color='0.4',lw=.7)
ax[1].set(xlabel='Cost change vs. progress (%)',ylabel='Nominal-deviation change (%)');ax[1].legend(frameon=False,fontsize=7)
for a in ax:a.grid(alpha=.18)
fig.tight_layout(pad=.7);fig.savefig(ROOT/'figures'/'sampled_performance_tradeoffs.pdf');fig.savefig(ROOT/'figures'/'sampled_performance_tradeoffs.png',dpi=180);plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(7.05,2.65),sharey=True)
case_defs=[('C3','gap',.4,'hjb','C3 gap, HJB, moving'),('C3','gap',0.,'opposing','C3 gap, opposing, rest'),('C1','gap',0.,'opposing','C1 gap, opposing, rest'),('C2','tracking',.4,'hjb','C2 tracking, HJB, moving')]
case_colors=['#005A9C','#B33A3A','#AA6A00','#168C6D']
for ax,th in zip(axes,[.25,.5]):
 for idx,(plant,task,v0,nom,label) in enumerate(case_defs):
  rr=[r for r in rows if r['method']=='band' and r['theta']==th and (r['plant'],r['task'],r['v0'],r['nominal'])==(plant,task,v0,nom)]
  rr=sorted(rr,key=lambda z:z['dt']);ax.plot([r['dt'] for r in rr],[r['detected_time_upper']/r['rate_bound_lower'] for r in rr],marker=['o','s','^','d'][idx],ms=3,lw=1,color=case_colors[idx],label=label)
 ax.axhline(1,color='black',ls='--',lw=.8);ax.set(xlabel='Requested sampling period',title=f'$\\theta={th:g}$',ylim=(.4,1.03));ax.grid(alpha=.18)
axes[0].set_ylabel('Verified detected time / bound')
axes[1].legend(frameon=False,fontsize=6.3,loc='lower right')
fig.tight_layout(pad=.6);fig.savefig(ROOT/'figures'/'sampling_sweep.pdf');fig.savefig(ROOT/'figures'/'sampling_sweep.png',dpi=180);plt.close(fig)
lines=['\\begin{tabular}{llrrrr}','\\toprule','Task & $\\theta$ & Med. $J_B$ & Med. $J_P$ & Med. $J_B/J_P$ & Med. $I_{1,B}/I_{1,P}$\\\\','\\midrule']
for task in ['gap','tracking']:
 for theta in [.25,.5]:
  z=summary['task_costs'][f'{task}_{theta}'];lines.append(f'{task.title()} & {theta:g} & {f(z["median_J_band"])} & {f(z["median_J_progress"])} & {f(z["median_paired_cost_ratio"])} & {f(z["median_paired_I1_ratio"])}\\\\')
lines+=['\\bottomrule','\\end{tabular}']
(ROOT/'tables'/'task_costs.tex').write_text('\n'.join(lines)+'\n')
lines=['\\begin{tabular}{lrrrrr}','\\toprule','Task & $N$ & Med. $J_B$ & Med. $J_P$ & Med. $J_B/J_P$ & Med. $I_{1,B}/I_{1,P}$\\\\','\\midrule']
for task in ['gap','tracking']:
 z=summary['task_costs'][f'{task}_all'];lines.append(f'{task.title()} & {z["n"]} & {f(z["median_J_band"])} & {f(z["median_J_progress"])} & {f(z["median_paired_cost_ratio"])} & {f(z["median_paired_I1_ratio"])}\\\\')
lines+=['\\bottomrule','\\end{tabular}']
(ROOT/'tables'/'task_costs_all_theta.tex').write_text('\n'.join(lines)+'\n')
timing_path=ROOT/'timing_summary.json'
if timing_path.exists():
 timing=json.loads(timing_path.read_text())['pooled']
 lines=['\\begin{tabular}{lrrrr}','\\toprule','Method & $N$ & Median (ms) & 95th pct. (ms) & Max. (ms)\\\\','\\midrule']
 for method,label in [('band','Certified band'),('progress','Certified progress')]:
  z=timing[method];lines.append(f'{label} & {z["count"]} & {f(z["p50_ms"])} & {f(z["p95_ms"])} & {f(z["max_ms"])}\\\\')
 lines+=['\\bottomrule','\\end{tabular}']
 (ROOT/'tables'/'runtime_summary.tex').write_text('\n'.join(lines)+'\n')
# Copy generated assets only, without modifying parent-owned LaTeX sections.
for kind in ['tables','figures']:
 dest=ROOT.parent/'manuscript'/kind/'v7';dest.mkdir(parents=True,exist_ok=True)
 for pth in (ROOT/kind).glob('*'):
  if pth.suffix in ['.tex','.pdf','.png']:shutil.copy2(pth,dest/pth.name)
print(json.dumps(summary,indent=2))
