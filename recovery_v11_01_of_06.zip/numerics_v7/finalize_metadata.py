#!/usr/bin/env python3
"""Record final code/environment provenance without rerunning trajectories."""
from pathlib import Path
import collections, datetime, hashlib, importlib.metadata, json, platform, shutil

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def version(name):
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None

cases = [json.loads(p.read_text()) for p in (ROOT / 'data/cases').glob('*.json')]
if len(cases) != 360:
    raise RuntimeError('Final metadata requires all 360 scheduled cases.')
rows = [j['row'] for j in cases]
counts = collections.Counter((r['group'], r['method'], r['status']) for r in rows)
run_status = {
    'count': len(rows), 'final_after_audit': True,
    'status_counts': {str(k): v for k, v in sorted(counts.items())},
    'data': 'data/episodes.csv', 'summary': 'summary.json',
    'timing': 'timing_summary.json', 'protocol': 'protocol.json',
    'source_and_environment': 'environment.json',
}
for path in [ROOT / 'run_summary.json', ROOT / 'data/run_summary.json']:
    path.write_text(json.dumps(run_status, indent=2) + '\n')

protocol_path = ROOT / 'protocol.json'
protocol = json.loads(protocol_path.read_text())
protocol.update({
    'case_grid_fixed_before_production': True,
    'final_implementation_after_audit': True,
    'initial_gap': 'd0 = epsilon + h0 + gamma*v0',
    'cost_tail': 'analytic tangent request with certificate-checked box-aware positivity correction; safety certified through H=10; no asymptotic claim for corrected numerical policy',
    'nominal_intervention': 'I10_L1 and I10_L2 integrate the time/state-varying nominal at 12 Gauss nodes; I1_sampled10 and I2_sampled10 separately record sampled-request distortion',
    'cost_scope': 'Separate gap and tracking objectives; diagnostic quadrature estimates, not interval-enclosed functionals; final metric hold truncated at H=10',
    'floor_launch': 'Full-U analytical floor preservation, with independent whole-hold safety and profile-domain tests; floor lower margin zero',
    'candidate_search': 'Nominal first; explicit rest launch; finite candidates plus ten refinements retaining a certified feasible iterate; five local midpoint seeds only after primary candidates fail; no exact nearest projection claim',
    'detection': 'Upper endpoint gap enclosure lies within target; each band case separately verifies detected_time_upper <= Tstar_lower/sqrt(theta)+requested_delta using outward arithmetic',
    'clock_target': 'Lower-rounded target travel is used for the certified lower optimal clock',
    'fallback': 'Explicit hold halvings, followed if needed by uncertainty-aware analytic extreme witness with g/4 opposite clearance and g/(8*K*M) period',
    'failures': 'No silent case exclusion. Naive D exits and performance-floor failures are distinct classifications.',
    'timing_note': 'Offline validated study. Parallel production times are not latency evidence; serialized timing includes finite search and ten refinements and often exceeds 50 ms for the band filter.',
    'reproduction': 'python run_matrix.py --fresh --workers 4; python benchmark_v7.py; python analyze_v7.py; python finalize_metadata.py',
    'cache_policy': 'Only case results with matching core-source hashes are reused. --fresh archives cases and profile caches before recomputation.',
    'audit_history': 'data/pre_finalization, data/finalization_reruns.json and data/finalization_summary.json preserve the original snapshot and targeted corrections. No migration postpass is required for a clean run.',
})
protocol_path.write_text(json.dumps(protocol, indent=2) + '\n')

sources = sorted(list(ROOT.glob('*.py')) + list(ROOT.glob('*.c')) + list(ROOT.glob('*.sh')))
policy_dir = ROOT.parent / 'manuscript/numerics/policies'
env = {
    'python': platform.python_version(), 'platform': platform.platform(),
    'numpy': version('numpy'), 'scipy': version('scipy'),
    'matplotlib': version('matplotlib'), 'pypdf': version('pypdf'),
    'mpmath_vendored': '1.3.0',
    'compiler_flags': '-std=c99 -O2 -fPIC -shared -fno-fast-math -ffp-contract=off',
    'source_sha256': {p.name: sha(p) for p in sources},
    'frozen_policy_sha256': {p.name: sha(p) for p in sorted(policy_dir.glob('*.npz'))},
    'case_count': len(cases), 'outward_C_vs_Python_bitwise_identical': True,
    'provenance': 'These hashes describe the final delivered code. Saved cases include targeted audit reruns and deterministic metric refreshes from the recorded physical holds; cache-validation and reporting-only fields were added after production. The clean-run commands execute the final implementation directly.',
}
(ROOT / 'environment.json').write_text(json.dumps(env, indent=2) + '\n')

summary = json.loads((ROOT / 'summary.json').read_text())
timing = json.loads((ROOT / 'timing_summary.json').read_text())
compact = {
    'status': 'complete', 'cases': len(cases),
    'base_band_fixed_0p05': sum(r['method']=='band' and r['group']=='base' and r['shortened_holds']==0 for r in rows),
    'band_certified_detection_bounds': sum(r['method']=='band' and r.get('verified_detection_bound',False) for r in rows),
    'shortened_band_sweep_episodes': sum(r['method']=='band' and r['group']=='sweep' and r['shortened_holds']>0 for r in rows),
    'analytic_fallback_holds': sum(r.get('analytic_fallback_holds',0) for r in rows),
    'naive_base': summary['naive_base'],
    'paired_counts': summary['paired_counts'], 'task_costs': summary['task_costs'],
    'timing_ms': timing['pooled'], 'fallback_bounds': summary['global_fallback'],
    'certification': summary['certification'],
    'files': {
        'results': 'data/episodes.csv', 'summary': 'summary.json',
        'timing': 'timing_summary.json', 'readme': 'README.txt',
        'tables': [str(p.relative_to(ROOT)) for p in sorted((ROOT/'tables').glob('*.tex'))],
        'figures': [str(p.relative_to(ROOT)) for p in sorted((ROOT/'figures').glob('*.pdf'))],
    },
}
(ROOT/'final_summary.json').write_text(json.dumps(compact, indent=2) + '\n')
manifest_files = [ROOT / name for name in ['README.txt','protocol.json','environment.json','run_summary.json','summary.json','final_summary.json','timing_summary.json','data/episodes.csv']]
manifest_files += sorted((ROOT/'tables').glob('*.tex')) + sorted((ROOT/'figures').glob('*.pdf'))
manifest = {str(p.relative_to(ROOT)): sha(p) for p in manifest_files}
(ROOT/'artifact_sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'status':'complete','cases':len(cases),'manifest_entries':len(manifest)}, indent=2))
