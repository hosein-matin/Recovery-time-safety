#!/usr/bin/env python3
"""Serialized end-to-end certificate timing; no deadline guarantee is claimed."""
from pathlib import Path
import sys,json,platform,time
import numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import certified_zoh as c
import scipy
stress=[('C3','gap',.4,'hjb'),('C3','gap',0.,'opposing'),('C1','gap',0.,'opposing'),('C2','tracking',.4,'hjb')]
rows=[];times={};profile=[]
for plant,task,v0,kind in stress:
 p=next(p for p in c.base.PLANTS if p.name==plant)
 d0=p.eps+.8+p.gamma*v0;P,Q=c.profiles(p,d0,v0,p.eps+.002)
 profile.append({'plant':plant,'v0':v0,'numerical_reference_seconds':P.offline_seconds,'certified_profile_seconds':Q.offline_seconds,'profile_cells':len(Q.C_upper)})
 # Force all interval transcendental lookup/cache setup before timed decisions.
 c.cr.V_range(p,.02,1.);c.cr.matrices(p,.001)
 for theta in [.25,.5]:
  for method in ['band','progress']:
   r,tr,fail=c.simulate(p,task,.8,v0,kind,theta,.05,cell=.001,method=method,tail=True)
   rows.append(r);times[f'{plant}_{task}_{v0}_{kind}_{theta}_{method}']=[z['decision_ms'] for z in tr if z['mode']!='tail']
   print(plant,task,v0,kind,theta,method,r['control_p50_ms'],r['control_p95_ms'],r['control_max_ms'],flush=True)
summary={}
for method in ['band','progress']:
 ts=np.concatenate([vals for key,vals in times.items() if key.endswith('_'+method)])
 summary[method]={'count':len(ts),'mean_ms':float(np.mean(ts)),'p50_ms':float(np.median(ts)),'p95_ms':float(np.percentile(ts,95)),'max_ms':float(max(ts)),'over_50ms_count':int(np.sum(ts>50))}
(ROOT/'timing_summary.json').write_text(json.dumps({'rows':rows,'pooled':summary,'profile_builds':profile,'decision_samples_ms':times,
 'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),
 'compiled_outward_loop':c._lib is not None,'note':'Serialized process; wall clock includes ODE proposal, continuous residual certificate, profile queries, candidate search and nominal evaluation; excludes profile precomputation and common tail. No hard real-time guarantee.'},indent=2))
print(json.dumps(summary,indent=2),flush=True)
