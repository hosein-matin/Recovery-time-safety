#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
cc -std=c99 -O2 -fPIC -shared -fno-fast-math -ffp-contract=off outward_loop.c -lm -o outward_loop.so
