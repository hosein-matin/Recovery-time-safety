/* IEEE-754 upward-enlarged nonnegative error propagation.
   Build without contraction or fast math. No global rounding-mode changes. */
#include <math.h>
#include <stddef.h>
static double up(double x) { return nextafter(x, INFINITY); }
static double mv(const double *a,const double *x) {
  return up(up(a[0]*x[0])+up(a[1]*x[1]));
}
void propagate_cells(size_t n,const double *ops,const double *res,const double *jumps,
                     const double *w0,double *tube,double *wend) {
  double w[2]={w0[0],w0[1]};
  for(size_t j=0;j<n;j++) {
    const double *F=ops+j*16,*G=F+4,*Fa=G+4,*Ga=Fa+4,*r=res+j*2;
    double ne[2];
    for(size_t i=0;i<2;i++) {
      tube[j*2+i]=up(mv(Fa+i*2,w)+mv(Ga+i*2,r));
      ne[i]=up(up(mv(F+i*2,w)+mv(G+i*2,r))+jumps[j*2+i]);
    }
    w[0]=ne[0];w[1]=ne[1];
  }
  wend[0]=w[0];wend[1]=w[1];
}
