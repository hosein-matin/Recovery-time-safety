#!/usr/bin/env python3
"""Frozen V7 sampled experiment protocol. Every scheduled case is retained."""
from pathlib import Path
import sys,json,csv,math,time,hashlib,argparse,concurrent.futures,multiprocessing,datetime,shutil
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import certified_zoh as cz
b=cz.base
SOURCE_FILES=['certified_zoh.py','certificate_rounding.py','profile_bounds.py','outward_loop.c','reference_v6.py','run_matrix.py']
def source_hashes():return {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in SOURCE_FILES}

def naive(p,task,h0,v0,nominal,theta,dt):
 d0=p.eps+h0+p.gamma*v0;target=p.eps+(.2 if task=='tracking' else 0)+.01
 P,Q=cz.profiles(p,d0,v0,p.eps+.002)
 nom=b.Nominal(p,task,nominal,ROOT.parent/'manuscript/numerics')
 t=0.;z=np.array([d0,v0]);tr=[];hm=h0;vm=v0;fm=(1-theta)*v0*v0/2;T=None;status='horizon'
 for n in range(math.ceil(20/dt)):
  d,v=z;s=max(0.,min(P.S,d0-d));E=.5*v*v;q=theta*P.E(s);pn=p.a(d,v)+nom(t,d,v);acc=pn
  mode='interior'
  if E<=q+1e-10:acc=max(acc,theta*P.derivative(s));mode='floor'
  if E>=p.B(d)-1e-10:acc=min(acc,p.Bprime(d));mode='ceiling'
  u=b.clip(acc-p.a(d,v),-p.U,p.U)
  sol=solve_ivp(lambda tt,y:[-y[1],p.a(*y)+u],(0,dt),z,method='DOP853',rtol=2e-12,atol=2e-14,max_step=dt/8,dense_output=True)
  ts=np.linspace(0,dt,201);ys=sol.sol(ts);hh=ys[0]-p.gamma*ys[1]-p.eps
  first=np.flatnonzero(ys[0]<=target)
  last_t=dt
  if len(first):
   last_t=brentq(lambda tau:sol.sol(tau)[0]-target,0,float(ts[first[0]]));T=t+last_t;status='entered'
   ts=np.linspace(0,last_t,201);ys=sol.sol(ts);hh=ys[0]-p.gamma*ys[1]-p.eps
  floor=[.5*vv*vv-theta*P.E(max(0,min(P.S,d0-dd))) for dd,vv in ys.T]
  hm=min(hm,float(hh.min()));vm=min(vm,float(ys[1].min()));fm=min(fm,min(floor))
  tr.append({'t':t,'d':float(z[0]),'v':float(z[1]),'u':float(u),'mode':mode,'dt':last_t})
  t+=last_t;z=sol.sol(last_t)
  if T is not None:break
  if vm< -1e-6:status='negative_speed';break
 Tstar=P.clock(d0-target)
 return {'plant':p.name,'task':task,'h0':h0,'v0':v0,'d0':d0,'nominal':nominal,'theta':theta,'dt':dt,'method':'naive',
   'status':status,'T':T,'Tstar':Tstar,'ratio':T/Tstar if T else None,'h_min_diagnostic':hm,'v_min_diagnostic':vm,'floor_min_diagnostic':fm,
   'headway_violation':bool(hm< -1e-8),'speed_violation':bool(vm< -1e-8),'floor_violation':bool(fm< -1e-8),'holds':len(tr)},tr,[]

def cases():
 out=[]
 for p in b.PLANTS:
  for task in ['gap','tracking']:
   for v0 in [0.,.4]:
    for nominal in b.NOMINALS:
     for theta in [.25,.5]:
      for method in ['band','progress','naive']:
       out.append(dict(plant=p.name,task=task,h0=.8,v0=v0,nominal=nominal,theta=theta,dt=.05,method=method,group='base'))
 stress=[('C3','gap',.4,'hjb'),('C3','gap',0.,'opposing'),('C1','gap',0.,'opposing'),('C2','tracking',.4,'hjb')]
 for plant,task,v0,nominal in stress:
  for theta in [.25,.5]:
   for dt in [.0125,.025,.1]:
    for method in ['band','progress','naive']:
     out.append(dict(plant=plant,task=task,h0=.8,v0=v0,nominal=nominal,theta=theta,dt=dt,method=method,group='sweep'))
 return out

def ident(c):return hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest()[:16]
def worker(c):
 p=next(p for p in b.PLANTS if p.name==c['plant'])
 fn=ROOT/'data'/'cases'/f'{ident(c)}.json'
 if fn.exists():
  j=json.loads(fn.read_text())
  if j.get('source_hashes')==source_hashes():return j['row']
 try:
  if c['method']=='naive':row,tr,fail=naive(p,c['task'],c['h0'],c['v0'],c['nominal'],c['theta'],c['dt'])
  else:row,tr,fail=cz.simulate(p,c['task'],c['h0'],c['v0'],c['nominal'],c['theta'],c['dt'],cell=.001,method=c['method'],tail=True)
  row.update(group=c['group'],case_id=ident(c))
  j={'case':c,'row':row,'trace':tr,'rejected_periods':fail,'source_hashes':source_hashes()}
 except Exception as e:
  import traceback
  j={'case':c,'row':dict(c,status='exception',exception=str(e),case_id=ident(c)),'traceback':traceback.format_exc()}
 fn.write_text(json.dumps(j,indent=2));return j['row']

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=4);ap.add_argument('--limit',type=int);ap.add_argument('--group',default='all');ap.add_argument('--fresh',action='store_true');a=ap.parse_args()
 if a.fresh:
  stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
  archive=ROOT/'data'/'archived_runs'/stamp
  for name in ['cases','profile_bounds']:
   old=ROOT/'data'/name
   if old.exists():
    archive.mkdir(parents=True,exist_ok=True);shutil.move(str(old),str(archive/name))
 (ROOT/'data'/'cases').mkdir(parents=True,exist_ok=True)
 tasks=cases();tasks=[x for x in tasks if a.group=='all' or x['group']==a.group]
 if a.limit:tasks=tasks[:a.limit]
 protocol={'case_grid_fixed_before_production':True,'final_implementation_after_audit':True,'h0':.8,'v0':[0.,.4],'theta':[.25,.5],'base_delta':.05,'profile_upper_ds':1e-4,
 'certificate_max_cell':.001,'physical_integrator':'DOP853','rtol':2e-12,'atol':2e-14,'common_cost_horizon':10,
 'cost_tail':'analytic tangent hold with certificate-checked box-aware positivity correction',
 'nominal_intervention':'I10_L1 and I10_L2 integrate the time/state-varying nominal at 12 Gauss nodes; I1_sampled10 and I2_sampled10 separately record held sampled-request distortion',
 'methods':['band','progress','naive'],'production_cases':cases(),
 'timing_note':'Parallel production elapsed times are not real-time latency measurements; serialized timing is reported separately.'}
 (ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
 start=time.perf_counter();rows=[]
 # Prewarm immutable profile bounds before fork, avoiding duplicate work and file races.
 for p in b.PLANTS:
  for v0 in [0.,.4]:
   d0=p.eps+.8+p.gamma*v0
   P,Q=cz.profiles(p,d0,v0,p.eps+.002)
   for task in ['gap','tracking']:
    target=p.eps+(.2 if task=='tracking' else 0)+.01
    cz.clock_lower(Q,d0-target)
 print('Prepared six certified profile envelopes.',flush=True)
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers,mp_context=multiprocessing.get_context('fork')) as pool:
  for i,row in enumerate(pool.map(worker,tasks)):
   rows.append(row)
   print(f'{i+1}/{len(tasks)} {row["plant"]} {row["task"]} {row["nominal"]} v{row["v0"]} th{row["theta"]} dt{row["dt"]} {row["method"]} {row["status"]}',flush=True)
 fields=sorted(set().union(*(r.keys() for r in rows)))
 with (ROOT/'data'/'episodes.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 (ROOT/'data'/'run_summary.json').write_text(json.dumps({'count':len(rows),'wall_seconds':time.perf_counter()-start,'status_counts':{s:sum(r['status']==s for r in rows) for s in set(r['status'] for r in rows)}},indent=2))
