#!/usr/bin/env python3
"""Re-run affected implementation cases; consistently compute declared metrics."""
from pathlib import Path
import sys,json,math,csv,time,concurrent.futures,multiprocessing
import numpy as np
from scipy.integrate import solve_ivp
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import certified_zoh as c
import run_matrix as run

def refresh(path):
 path=Path(path);j=json.loads(path.read_text());r=j['row']
 if r['method']=='naive' or r['status']!='entered':return r
 p=next(p for p in c.base.PLANTS if p.name==r['plant'])
 nominal=c.base.Nominal(p,r['task'],r['nominal'],ROOT.parent/'manuscript/numerics')
 gx,gw=np.polynomial.legendre.leggauss(12)
 I1=I2=Is1=Is2=0.;domain_min=math.inf;umax=0.;duration=0.
 for tr in j['trace']:
  dt=tr['dt'];u=tr['u'];z=np.array([tr['d'],tr['v']]);t=tr['t']
  if dt<=0:raise RuntimeError('Nonpositive hold')
  sol=solve_ivp(lambda tt,y:[-y[1],p.a(*y)+u],(0,dt),z,method='DOP853',rtol=2e-12,atol=2e-14,max_step=dt/4,dense_output=True)
  qt=(gx+1)*dt/2;qw=gw*dt/2;ys=sol.sol(qt)
  kn=np.array([c.base.clip(nominal(t+tt,float(dd),float(vv)),-p.U,p.U) for tt,dd,vv in zip(qt,*ys)])
  I1+=float(qw@np.abs(u-kn));I2+=float(qw@((u-kn)**2))
  ks=c.base.clip(nominal(t,*z),-p.U,p.U);Is1+=dt*abs(u-ks);Is2+=dt*(u-ks)**2
  umax=max(umax,abs(u));duration+=dt
  if tr['mode']!='tail':
   # Certified actual d is nonincreasing, so its endpoint lower bound
   # encloses the minimum actual gap throughout the hold.
   domain_min=min(domain_min,float(c.cr.lo(sol.y[0,-1]-tr['err_d']-(p.eps+.002))))
 P,Q=c.profiles(p,r['d0'],r['v0'],p.eps+.002)
 target=p.eps+(.2 if r['task']=='tracking' else 0)+.01
 S_lower=float(c.cr.lo(r['d0']-target))
 Tlo=c.clock_lower(Q,S_lower)
 r.pop('I10',None)
 r.update(I10_L1=I1,I10_L2=I2,I1_sampled10=Is1,I2_sampled10=Is2,
          cost_horizon_actual=duration,max_abs_actuator=umax,profile_extension_margin=domain_min,Tstar_lower=Tlo)
 durations=[];total=0.
 for tr in j['trace']:
  durations.append(tr['dt']);total+=tr['dt']
  if total>=r['T_detected']-1e-12:break
 det_up=np.nextafter(np.nextafter(math.fsum(durations),np.inf),np.inf)
 rhs=np.nextafter(np.nextafter(Tlo/np.nextafter(math.sqrt(r['theta']),np.inf),-np.inf)+r['dt'],-np.inf)
 r.update(detected_time_upper=float(det_up),rate_bound_lower=float(rhs),verified_detection_bound=bool(det_up<=rhs))
 j['row']=r;j['metrics_refresh']='Actual nominal L1/L2 by 12-node Gauss integration of recorded physical holds; no state/control change.'
 path.write_text(json.dumps(j,indent=2));return r

if __name__=='__main__':
 paths=sorted((ROOT/'data'/'cases').glob('*.json'));redo=[]
 for path in paths:
  j=json.loads(path.read_text());r=j['row']
  if r['method']!='naive' and (r['status']=='exception' or r.get('shortened_holds',0) or any(abs(t['u'])>5 for t in j.get('trace',[]))):
   redo.append((path,j['case']))
 audit=ROOT/'data'/'pre_finalization';audit.mkdir(exist_ok=True)
 for path,case in redo:path.replace(audit/path.name)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('fork')) as pool:
  for row in pool.map(run.worker,[case for path,case in redo]):print('Updated',row['case_id'],row['status'],row.get('shortened_holds'),flush=True)
 paths=sorted((ROOT/'data'/'cases').glob('*.json'))
 with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('fork')) as pool:
  rows=list(pool.map(refresh,paths))
 fields=sorted(set().union(*(r.keys() for r in rows)))
 with (ROOT/'data'/'episodes.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 (ROOT/'data'/'finalization_summary.json').write_text(json.dumps({'recomputed_cases':len(redo),'total':len(rows),'status_counts':{str((g,m,s)):sum((r['group'],r['method'],r['status'])==(g,m,s) for r in rows) for g,m,s in set((r['group'],r['method'],r['status']) for r in rows)}},indent=2))
 print('Finalized',len(rows),'cases',flush=True)
