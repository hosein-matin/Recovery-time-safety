"""Outward elementary bounds for the V7 a-posteriori hold certificate.

All stored binary64 polynomial coefficients and model parameters are
treated as exact data. Basic array operations below enlarge both ends by
one representable number. Transcendental constants and matrix functions
are computed by mpmath interval arithmetic, then converted outward.

For tanh, a cached dyadic lattice and a quadratic Taylor enclosure avoid
calling interval exp at every residual endpoint. The global bound
|tanh'''| <= 2 gives an explicit remainder, not an empirical tolerance.
"""
from __future__ import annotations
import math
import sys
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'))
from mpmath import iv
iv.dps=40

def lo(x): return np.nextafter(np.asarray(x,dtype=float),-np.inf)
def hi(x): return np.nextafter(np.asarray(x,dtype=float),np.inf)
def pt(x):
    x=np.asarray(x,dtype=float)
    return x,x
def add(a,b): return lo(a[0]+b[0]),hi(a[1]+b[1])
def neg(a): return -a[1],-a[0]
def sub(a,b): return add(a,neg(b))
def mul(a,b):
    p=np.stack(np.broadcast_arrays(a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]))
    return lo(np.min(p,axis=0)),hi(np.max(p,axis=0))
def divpos(a,b):
    if np.any(np.asarray(b[0])<=0): raise ValueError('Positive divisor required')
    return mul(a,(lo(1/np.asarray(b[1])),hi(1/np.asarray(b[0]))))
def scale(a,c): return mul(a,pt(c))
def square(a):
    p0=a[0]*a[0];p1=a[1]*a[1]
    lower=np.where((a[0]<=0)&(a[1]>=0),0.,lo(np.minimum(p0,p1)))
    return lower,hi(np.maximum(p0,p1))
def absolute_upper(a): return np.maximum(np.abs(a[0]),np.abs(a[1]))
def isum(a):
    ans=pt(np.zeros(np.shape(a[0])[:-1]))
    for j in range(np.shape(a[0])[-1]): ans=add(ans,(a[0][...,j],a[1][...,j]))
    return ans
def ivfloat(x):
    return float(np.nextafter(float(x.a),-np.inf)),float(np.nextafter(float(x.b),np.inf))
def ivpoint(x): return iv.mpf(float(x))
def ivtanh(x):
    t=iv.exp(2*x)
    return (t-1)/(t+1)


def brange_interval(c):
    """Bernstein convex-hull range for cubic interval power coefficients."""
    c0=(c[0][...,0],c[1][...,0]); c1=(c[0][...,1],c[1][...,1])
    c2=(c[0][...,2],c[1][...,2])
    b0=c0
    b1=add(c0,divpos(c1,pt(3.)))
    b2=add(c0,divpos(add(scale(c1,2.),c2),pt(3.)))
    b3=isum(c)
    return np.min(np.stack([x[0] for x in [b0,b1,b2,b3]]),axis=0),np.max(np.stack([x[1] for x in [b0,b1,b2,b3]]),axis=0)

def brange(c): return brange_interval(pt(c))

def derivative_coeff_interval(c,h,order=1):
    c=np.asarray(c,float);h=np.asarray(h,float)
    ol=np.zeros_like(c);ou=np.zeros_like(c)
    den=pt(np.ones_like(h))
    for _ in range(order): den=mul(den,pt(h))
    for i in range(order,4):
        fac=math.factorial(i)/math.factorial(i-order)
        z=divpos(scale(pt(c[...,i]),fac),den)
        ol[...,i-order],ou[...,i-order]=z
    return ol,ou

def derivative_range(c,h,order=1):
    return brange_interval(derivative_coeff_interval(c,h,order))


_TANH=None
_SCALE=4096
_FIRST=-2048
_LAST=10240
_CACHE=ROOT/'tanh_interval_lattice_v1.npz'

def _table():
    global _TANH
    if _TANH is not None:return _TANH
    if _CACHE.exists():
        z=np.load(_CACHE)
        if int(z['scale'])==_SCALE and int(z['first'])==_FIRST and int(z['last'])==_LAST:
            _TANH=(z['lower'],z['upper']);return _TANH
    lower=np.empty((_LAST-_FIRST+1,3));upper=np.empty_like(lower)
    for j,k in enumerate(range(_FIRST,_LAST+1)):
        x=ivpoint(k/_SCALE);t=ivtanh(x);d=1-t*t;dd=-2*t*d
        for r,value in enumerate([t,d,dd]): lower[j,r],upper[j,r]=ivfloat(value)
    np.savez_compressed(_CACHE,lower=lower,upper=upper,scale=_SCALE,first=_FIRST,last=_LAST)
    _TANH=(lower,upper);return _TANH

def tanh_point(x,order=0):
    """Enclose tanh and its first two derivatives at exact float x."""
    x=np.asarray(x,float);shape=x.shape;flat=x.reshape(-1)
    idx=np.rint(flat*_SCALE).astype(np.int64)
    inside=(idx>=_FIRST)&(idx<=_LAST)
    outlo=np.empty_like(flat);outhi=np.empty_like(flat)
    if np.any(inside):
        tab=_table();ix=idx[inside]-_FIRST
        t=(tab[0][ix,0],tab[1][ix,0]);d=(tab[0][ix,1],tab[1][ix,1]);dd=(tab[0][ix,2],tab[1][ix,2])
        delta=sub(pt(flat[inside]),pt(idx[inside]/_SCALE))
        ad=absolute_upper(delta)
        if order==0:
            val=add(add(t,mul(d,delta)),scale(mul(dd,square(delta)),.5))
            rem=hi(hi(hi(ad*ad)*ad)/3.)
        elif order==1:
            val=add(d,mul(dd,delta));rem=hi(ad*ad)
        elif order==2:
            val=dd;rem=hi(2*ad)
        else:raise ValueError(order)
        val=add(val,(-rem,rem));outlo[inside],outhi[inside]=val
    for j in np.flatnonzero(~inside):
        t=ivtanh(ivpoint(flat[j]));d=1-t*t
        val=[t,d,-2*t*d][order]
        outlo[j],outhi[j]=ivfloat(val)
    return outlo.reshape(shape),outhi.reshape(shape)

_TANH2=ivfloat(ivtanh(ivpoint(2.)))
_C3K=ivfloat(ivpoint(.1)+ivpoint(1.5)/ivpoint(.8))

def V_range(p,dl,du):
    dl,du=np.asarray(dl,float),np.asarray(du,float)
    if p.name=='C3':
        raw=scale(sub((dl,du),pt(.1)),.8)
        return np.clip(raw[0],0,1.5),np.clip(raw[1],0,1.5)
    l=tanh_point(dl)[0];u=tanh_point(du)[1]
    return sub((l,u),_TANH2)

def vp_range(p,dl,du):
    dl,du=np.asarray(dl,float),np.asarray(du,float)
    if p.name=='C3':
        low=np.where((dl>=.1)&(du<=_C3K[0]),.8,0.)
        high=np.where((du<.1)|(dl>_C3K[1]),0.,.8)
        return low,high
    a=tanh_point(dl,1);b=tanh_point(du,1)
    low=np.maximum(0.,np.minimum(a[0],b[0]))
    high=np.minimum(1.,np.maximum(a[1],b[1]))
    high=np.where((dl<=0)&(du>=0),1.,high)
    return low,high

def vpp_range(p,dl,du):
    if p.name=='C3': raise ValueError('C3 second derivative has kinks; use affine branch bounds')
    dl,du=np.asarray(dl,float),np.asarray(du,float)
    mid=dl+(du-dl)/2
    radius=hi(np.maximum(np.abs(mid-dl),np.abs(du-mid)))
    val=tanh_point(mid,2);r=hi(2*radius)
    return add(val,(-r,r))


_MATRIX={}
def matrices(p,h):
    """Upper endpoint and whole-cell error operators, in existing API order."""
    alpha=float(p.alpha);L=.8 if p.name=='C3' else 1.;h=float(h)
    key=(alpha,L,h)
    if key in _MATRIX:return _MATRIX[key]
    ai=ivpoint(alpha);li=ivpoint(L);ti=ivpoint(h)
    # Increasing the off-diagonal coefficient gives a componentwise majorant.
    c=ivpoint(ivfloat(ai*li)[1]);out=[]
    for di in [-ai,ai]:
        r=di/2;mu=iv.sqrt(r*r+c)
        ex=iv.exp(r*ti);eh=iv.exp(mu*ti);em=iv.exp(-mu*ti)
        co=(eh+em)/2;sn=(eh-em)/(2*mu)
        p00=ex*(co-r*sn);p01=ex*sn;p10=c*p01;p11=ex*(co+r*sn)
        g01=(p00-1)/c;g00=p01-di*g01;g10=p00-1;g11=p01
        P=np.array([[ivfloat(p00)[1],ivfloat(p01)[1]],[ivfloat(p10)[1],ivfloat(p11)[1]]])
        G=np.array([[ivfloat(g00)[1],ivfloat(g01)[1]],[ivfloat(g10)[1],ivfloat(g11)[1]]])
        out.extend([np.maximum(0.,P),np.maximum(0.,G)])
    _MATRIX[key]=out
    return out

def matvec_upper(M,v):
    M=np.asarray(M,float);v=np.asarray(v,float)
    return hi(hi(M[...,0]*v[0])+hi(M[...,1]*v[1]))

def propagate_upper(F,G,w,r):
    return hi(matvec_upper(F,w)+matvec_upper(G,r))

def polynomial_jumps(c,end):
    """Radius to add after each cell, relative to next c0 or final center."""
    c=np.asarray(c,float);target=np.concatenate([c[1:,:,0],np.asarray(end,float)[None,:]],axis=0)
    endpoints=isum(pt(c))
    return absolute_upper(sub(endpoints,pt(target)))

def position_defect_bounds(c,h):
    c=np.asarray(c,float)
    dc=derivative_coeff_interval(c[:,0],h)
    return absolute_upper(brange_interval(add(dc,pt(c[:,1]))))

def endpoint_residual_bounds(p,c,h,u):
    """Maximum endpoint |r_v| of each exact stored polynomial piece."""
    c=np.asarray(c,float);dv=derivative_coeff_interval(c[:,1],h)
    vals=[]
    for endpoint in [0,1]:
        if endpoint==0:
            d=pt(c[:,0,0]);v=pt(c[:,1,0]);vp=(dv[0][:,0],dv[1][:,0])
        else:
            d=isum(pt(c[:,0]));v=isum(pt(c[:,1]));vp=isum(dv)
        acceleration=add(scale(sub(V_range(p,*d),v),p.alpha),pt(u))
        vals.append(absolute_upper(sub(vp,acceleration)))
    return np.maximum(*vals)

def c3_velocity_defect_bounds(p,c,h,u):
    c=np.asarray(c,float);dv=derivative_coeff_interval(c[:,1],h)
    dr=brange(c[:,0]);out=np.zeros(len(c))
    base=add(dv,scale(pt(c[:,1]),p.alpha))
    branches=[
        (0.,pt(0.),dr[0]<=.1),
        (.8,neg(mul(pt(.8),pt(.1))),(dr[1]>=.1)&(dr[0]<=_C3K[1])),
        (0.,pt(1.5),dr[1]>=_C3K[0])]
    for m,offset,active in branches:
        if not np.any(active):continue
        q=sub(base,scale(scale(pt(c[:,0]),m),p.alpha))
        shift=add(pt(u),scale(offset,p.alpha))
        q=(q[0].copy(),q[1].copy())
        q[0][:,0],q[1][:,0]=sub((q[0][:,0],q[1][:,0]),shift)
        values=absolute_upper(brange_interval(q))
        out=np.where(active,np.maximum(out,values),out)
    return out

