#!/usr/bin/env python3
"""Analytic residual-tube certification for physical actuator zero-order holds.

The interpolation is only an approximate curve; a continuous residual bound,
not a finite set of constraint samples, encloses its exact held-input flow.
"""
from __future__ import annotations
import os,sys,json,math,time,csv,argparse
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import reference_v6 as base
from profile_bounds import ProfileUpper
import certificate_rounding as cr

def V(p,d):
    return np.clip(.8*(np.asarray(d)-.1),0,1.5) if p.name=='C3' else np.tanh(d)-math.tanh(2.)

# The optional C loop evaluates the same nextafter-enlarged scalar operations
# as the Python interval code. It changes speed, not the certificate.
import ctypes
try:
    _lib=ctypes.CDLL(str(ROOT/'outward_loop.so'))
    _arr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    _lib.propagate_cells.argtypes=[ctypes.c_size_t,_arr,_arr,_arr,_arr,_arr,_arr]
    _lib.propagate_cells.restype=None
except OSError:
    _lib=None

def propagate_all(p,hs,res,jumps,w0):
    ops=np.ascontiguousarray([cr.matrices(p,float(h)) for h in hs],dtype=float)
    res=np.ascontiguousarray(res,float);jumps=np.ascontiguousarray(jumps,float)
    w0=np.ascontiguousarray(w0,float)
    if _lib is not None:
        tube=np.empty_like(res);end=np.empty(2)
        _lib.propagate_cells(len(hs),ops,res,jumps,w0,tube,end)
        return tube,end
    tube=[];w=w0.copy()
    for j,r in enumerate(res):
        F,G,Fa,Ga=ops[j]
        tube.append(cr.propagate_upper(Fa,Ga,w,r))
        w=cr.hi(cr.propagate_upper(F,G,w,r)+jumps[j])
    return np.array(tube),w

class Hold:
  def __init__(self,p,z,u,dt,cell=.001):
    u=base.clip(float(u),-p.U,p.U)
    self.p,self.z,self.u,self.dt=p,np.asarray(z,float),u,float(dt)
    self.n=max(2,int(math.ceil(dt/cell)));self.h=dt/self.n
    self.ts=np.linspace(0,dt,self.n+1);self.hs=np.diff(self.ts)
    self.sol=solve_ivp(lambda t,y:[-y[1],p.a(y[0],y[1])+u],(0,dt),z,
      method='DOP853',rtol=2e-12,atol=2e-14,max_step=dt/4,dense_output=True)
    if not self.sol.success:raise RuntimeError(self.sol.message)
    ys=self.sol.sol(self.ts).T
    fs=np.column_stack((-ys[:,1],p.alpha*(V(p,ys[:,0])-ys[:,1])+u))
    h=self.hs;y0=ys[:-1];y1=ys[1:];f0=fs[:-1];f1=fs[1:]
    self.c=np.stack((y0,h[:,None]*f0,3*(y1-y0)-h[:,None]*(2*f0+f1),2*(y0-y1)+h[:,None]*(f0+f1)),axis=-1)
    self.end=np.sum(self.c[-1],axis=-1)
    d=self.c[:,0];v=self.c[:,1]
    self.dr=cr.brange(d);self.vr=cr.brange(v)
    rdmax=cr.position_defect_bounds(self.c,h)
    if p.name!='C3':
      dp=cr.derivative_range(d,h,1);dpp=cr.derivative_range(d,h,2)
      vpp=cr.derivative_range(v,h,2);vppp=cr.derivative_range(v,h,3)
      t1=cr.mul(cr.vpp_range(p,*self.dr),cr.square(dp))
      t2=cr.mul(cr.vp_range(p,*self.dr),dpp)
      r2=cr.add(cr.sub(vppp,cr.scale(cr.add(t1,t2),p.alpha)),cr.scale(vpp,p.alpha))
      endres=cr.endpoint_residual_bounds(p,self.c,h,u)
      remainder=cr.mul(cr.scale(cr.square(cr.pt(h)),.125),cr.pt(cr.absolute_upper(r2)))[1]
      rmax=cr.hi(endres+remainder)
    else:
      rmax=cr.c3_velocity_defect_bounds(p,self.c,h,u)
    self.residual=np.column_stack((rdmax,rmax))
    self.jumps=cr.polynomial_jumps(self.c,self.end)
    hc=cr.sub(cr.pt(d),cr.scale(cr.pt(v),p.gamma))
    hc=(hc[0].copy(),hc[1].copy())
    hc[0][:,0],hc[1][:,0]=cr.sub((hc[0][:,0],hc[1][:,0]),cr.pt(p.eps))
    self.hrange=cr.brange_interval(hc)
    self.last=None

  def certify(self,P,Q,theta,w0,skipfloor=False,safety_only=False):
    p=self.p
    initial_jump=cr.absolute_upper(cr.sub(cr.pt(self.c[0,:,0]),cr.pt(self.z)))
    w_initial=cr.hi(np.asarray(w0,float)+initial_jump)
    wm,w=propagate_all(p,self.hs,self.residual,self.jumps,w_initial)
    wd,wv=wm[:,0],wm[:,1]
    vmin=cr.lo(self.vr[0]-wv);vmax=cr.hi(self.vr[1]+wv)
    hmin=cr.sub(cr.sub(self.hrange,cr.pt(wd)),cr.scale(cr.pt(wv),p.gamma))[0]
    mins=[float(np.min(hmin)),float(np.min(vmin)),float(np.min(cr.lo(p.M-vmax)))]
    # Full throttle preserves nonnegative velocity analytically under A+(d,0)>0.
    if self.u==p.U:mins[1]=max(0.,mins[1])
    elif float(np.min(cr.add(cr.scale(cr.V_range(p,cr.lo(self.dr[0]-wd),cr.hi(self.dr[1]+wd)),p.alpha),cr.pt(self.u))[0]))>=0:
      # First-exit comparison: v'=c(t)-alpha*v with c(t)>=0.
      mins[1]=max(0.,mins[1])
    floor_min=0. if skipfloor and not safety_only else math.inf
    if not skipfloor and not safety_only:
      r=float(cr.hi(math.sqrt(theta)))
      rg=float(cr.divpos(cr.pt(r),cr.pt(p.gamma))[1])
      # Each is a sufficient lower bound because E+ <= B <= either ceiling branch.
      dc=cr.pt(self.c[:,0]);dc=(dc[0].copy(),dc[1].copy())
      dc[0][:,0],dc[1][:,0]=cr.sub((dc[0][:,0],dc[1][:,0]),cr.pt(p.eps))
      gl=cr.sub(cr.pt(self.c[:,1]),cr.scale(dc,rg))
      linear_floor=cr.sub(cr.sub(cr.brange_interval(gl),cr.pt(wv)),cr.scale(cr.pt(wd),rg))[0]
      cap_floor=cr.sub(cr.sub(self.vr,cr.pt(wv)),cr.scale(cr.pt(p.M),r))[0]
      floor_marg=[]
      for j in range(self.n):
        dlo=float(cr.lo(self.dr[0][j]-wd[j]));dhi=float(cr.hi(self.dr[1][j]+wd[j]))
        slo=max(0.,float(cr.lo(P.d0-dhi)));shi=float(cr.hi(P.d0-dlo))
        if shi>Q.S or shi<0 or slo>shi:
          floor_marg.append(-math.inf);continue
        qu=Q.range_upper(slo,shi)
        energy=float(cr.sub(cr.scale(cr.square(cr.pt(max(0.,vmin[j]))),.5),cr.scale(cr.pt(qu),theta))[0])
        # Compare velocity-unit margins. Each nonnegative branch certifies E>=theta E+.
        e_vel=float(cr.lo(energy/max(1.,abs(vmax[j])+math.sqrt(max(0.,2*theta*qu)))))
        floor_marg.append(max(e_vel,linear_floor[j],cap_floor[j]))
      floor_min=float(min(floor_marg))
    self.tube_dmin=float(np.min(cr.lo(self.dr[0]-wd)))
    domain_margin=math.inf if safety_only else float(cr.lo(Q.S-cr.hi(P.d0-self.tube_dmin)))
    vals=mins+[floor_min,domain_margin]
    ok=all(x>=0 for x in vals)
    self.last={'ok':ok,'h_margin':mins[0],'v_margin':mins[1],'M_margin':mins[2],
      'floor_margin':floor_min,'domain_margin':domain_margin,'endpoint_error_d':float(w[0]),'endpoint_error_v':float(w[1]),
      'max_defect_d':float(self.residual[:,0].max()),'max_defect_v':float(self.residual[:,1].max()),
      'cells':self.n}
    return ok,w,self.last

def select(p,z,t,dt,nom,P,Q,theta,w,cell=.001,method='band'):
    k=base.clip(float(nom(t,*z)),-p.U,p.U);count=0;records=[]
    if method=='progress':
      cname='progress_r0500' if theta==.25 else 'progress_r0707'
      k=base.clip(base.controller(p,nom.task,cname,nom,t,*z)[1],-p.U,p.U)
    def test(u):
      nonlocal count
      count+=1;H=Hold(p,z,u,dt,cell)
      ok,we,info=H.certify(P,Q,theta,w,skipfloor=(u==p.U),safety_only=(method in ['safety','progress']))
      records.append((u,ok,info))
      return (H,we,info) if ok else None
    # Every arbitrary candidate must pass its complete-hold certificate.
    if z[1]==0 and t==0 and method=='band':
      ans=test(p.U)
      return ans,count,records,'launch'
    ans=test(k)
    if ans:return ans,count,records,'nominal'
    # Interior-band target gives a useful deterministic seed; every value is certified.
    s=P.d0-z[0];q=theta*P.E(s);B=p.B(z[0]);goal=math.sqrt(max(0.,2*(.65*q+.35*B)))
    u_center=base.clip((goal-z[1])/max(dt,.02)-p.a(*z),-p.U,p.U)
    candidates=[u_center,p.U,-p.U]
    # Coarse candidates are an explicit finite search, not a claim of global projection.
    candidates+=sorted(np.linspace(-p.U,p.U,21),key=lambda u:abs(u-k))
    good=None
    for u in candidates:
      ans=test(float(u))
      if ans:good=ans;uf=float(u);break
    if good is None:
      # A narrowly feasible interval may be missed by the coarse input grid.
      # Additional local-dynamics seeds are used only if that original search fails.
      s0=P.d0-z[0];sf=min(P.S,max(0.,s0+z[1]*dt))
      ef=theta*P.E(sf);bf=p.B(P.d0-sf)
      for eta in [.15,.35,.5,.65,.85]:
        vf=math.sqrt(max(0.,2*((1-eta)*ef+eta*bf)))
        midpoint_d=z[0]-.25*(z[1]+vf)*dt
        seed=(vf-z[1])/dt-p.a(midpoint_d,.5*(z[1]+vf))
        uf=base.clip(seed,-p.U,p.U);ans=test(uf)
        if ans:good=ans;break
    if good is None:return None,count,records,'failed'
    bad=k
    # Retain a strictly feasible tested iterate; no interval/convexity premise is used.
    for _ in range(10):
      u=.5*(bad+uf);ans=test(u)
      if ans:good=ans;uf=u
      else:bad=u
    return good,count,records,'filtered'

def analytic_fallback(p,z,w,dt,P,Q,theta,method,target,cell):
    """Extreme-input short-hold witness; tube retains numerical state errors."""
    th=theta if method=='band' else 0.
    def B_lower(d):
      distance=cr.sub(cr.pt(d),cr.pt(p.eps))
      vbar=cr.divpos(distance,cr.pt(p.gamma))[0]
      vbar=min(p.M,float(vbar))
      return float(cr.scale(cr.square(cr.pt(max(0.,vbar))),.5)[0])
    d_ext_lower=float(cr.sub(cr.pt(P.d0),cr.pt(Q.S))[0])
    g=float(cr.mul(cr.sub(cr.pt(1.),cr.pt(th)),cr.pt(B_lower(d_ext_lower)))[0])
    vr=cr.V_range(p,p.eps,P.d0);vmaxV=float(cr.absolute_upper(vr))
    bound=float(cr.add(cr.scale(cr.add(cr.pt(vmaxV),cr.pt(p.M)),p.alpha),cr.pt(p.U))[1])
    LB=float(cr.divpos(cr.pt(p.M),cr.pt(p.gamma))[1])
    Lq=float(cr.scale(cr.pt(max(bound,LB)),th)[1])
    K=float(cr.add(cr.pt(bound),cr.pt(max(Lq,LB)))[1])
    dlower=float(cr.lo(z[0]-w[0]))
    current_s_upper=float(cr.sub(cr.pt(P.d0),cr.pt(dlower))[1])
    room=float(cr.divpos(cr.sub(cr.pt(Q.S),cr.pt(current_s_upper)),cr.pt(p.M))[0])
    denom=cr.scale(cr.mul(cr.pt(K),cr.pt(p.M)),8.)
    safe_delta=float(cr.divpos(cr.pt(g),denom)[0])
    delta=min(dt,room,safe_delta)
    if delta<=0:raise RuntimeError('No certified positive fallback extension.')
    vu=float(cr.hi(z[1]+w[1]));vl=max(0.,float(cr.lo(z[1]-w[1])))
    upper_clear=float(cr.sub(cr.pt(B_lower(dlower)),cr.scale(cr.square(cr.pt(max(0.,vu))),.5))[0])
    slo=max(0.,float(cr.lo(cr.lo(P.d0-z[0])-w[0])))
    shi=float(cr.hi(cr.hi(P.d0-z[0])+w[0]))
    lower_clear=float(cr.sub(cr.scale(cr.square(cr.pt(vl)),.5),cr.scale(cr.pt(Q.range_upper(slo,shi)),th))[0])
    threshold=float(cr.scale(cr.pt(g),.25)[1])
    if upper_clear>=threshold:u=p.U
    elif lower_clear>=threshold:u=-p.U
    else:raise RuntimeError('Numerical state/profile enclosure too wide for analytic fallback; refine it.')
    H=Hold(p,z,u,delta,cell);_,we,info=H.certify(P,Q,theta,w,skipfloor=True,safety_only=True)
    info.update(ok=True,h_margin=0.,v_margin=0.,M_margin=0.,floor_margin=0. if th else math.inf,
                analytic_fallback=True,delta_bound=delta,opposite_clearance=max(upper_clear,lower_clear))
    return (H,we,info),delta

_PROFILES={}
_CLOCK_LOWER={}
def profiles(p,d0,v0,ext,*,ds=1e-4,cache_dir=None):
    # One exact construction identity for both memory and disk. It includes
    # every plant parameter, initial datum, grid/precision and source version.
    key=ProfileUpper.cache_key(p,d0,v0,ext,ds)
    if key not in _PROFILES:
      P=base.Profile(p,d0,v0,ext,fine=True)
      directory=Path(cache_dir) if cache_dir is not None else ROOT/'data'/'profile_bounds'
      directory.mkdir(parents=True,exist_ok=True)
      fn=directory/f'profile_{key}.npz'
      try:
        Q=ProfileUpper.load(p,fn,d0=d0,v0=v0,target_ext=ext,ds=ds)
      except (OSError,ValueError):
        # Missing, legacy, corrupt, or mismatched data cannot be a safety
        # oracle. Recompute and atomically replace only this exact-key file.
        Q=ProfileUpper(p,d0,v0,ext,ds=ds,cache=fn)
      _PROFILES[key]=(P,Q)
    return _PROFILES[key]

def clock_lower(Q,S):
    key=(Q.cache_identity,float(S).hex())
    if key not in _CLOCK_LOWER:_CLOCK_LOWER[key]=Q.clock_lower(S)
    return _CLOCK_LOWER[key]

def simulate(p,task,h0,v0,kind,theta,dt,cell=.001,tmax=20.,method='band',tail=False):
    d0=p.eps+h0+p.gamma*v0;target=p.eps+(.2 if task=='tracking' else 0)+.01
    ext=p.eps+.002
    P,Q=profiles(p,d0,v0,ext)
    targetS=d0-target
    Tstar=P.clock(targetS)
    nom=base.Nominal(p,task,kind,ROOT.parent/'manuscript/numerics')
    t=0.;z=np.array([d0,v0]);w=np.zeros(2);trace=[];allrecords=[]
    start=time.perf_counter();hmin=h0;vmin=v0;minfloor=0.;calls=0;steps=0;entries=None;Tdet=None
    status='horizon';mins=[math.inf]*4;maxerr=0.;tail_correction_max=0.;tail_correction_holds=0
    J=I=I1sample=I1actual=I2actual=A2=TVA=TVU=0.;maxjump=0.;prev_acc=None;prev_u=None;control_ms=[];active=0;entry_holds=0
    durations=[];shortened_holds=0;fallback_holds=0;extension_margin=math.inf
    gx,gw=np.polynomial.legendre.leggauss(12)
    while t<tmax-1e-12:
      if steps>=5000:
        status='hold_budget';break
      useddt=dt
      if Tdet is not None and not tail:break
      if Tdet is not None:
        useddt=min(dt,10.-t)
        if useddt<=1e-10:break
        u0=-p.alpha*float(V(p,z[0]))+(p.alpha-1/p.gamma)*z[1]
        u=u0;ncall=0
        for _ in range(12):
          H=Hold(p,z,u,useddt,cell);ncall+=1
          ok,we,info=H.certify(P,Q,theta,w,safety_only=True)
          if ok:break
          needed=float(cr.hi(-cr.scale(cr.V_range(p,H.tube_dmin,H.tube_dmin),p.alpha)[0]+1e-10))
          u=max(u,needed)
        if not ok:status='tail_certificate_failed';break
        if abs(u)>p.U:status='tail_input_failed';break
        tail_correction_max=max(tail_correction_max,abs(u-u0))
        tail_correction_holds+=int(abs(u-u0)>1e-12)
        ans=(H,we,info);mode='tail';recs=[]
      else:
        select_start=time.perf_counter()
        ans,ncall,recs,mode=select(p,z,t,useddt,nom,P,Q,theta,w,cell,method)
        if ans is None:
          allrecords.append({'t':t,'z':z.tolist(),'w':w.tolist(),'rejected_dt':useddt})
          for halving in range(1,7):
            useddt=dt/(2**halving)
            ans,n2,recs,mode=select(p,z,t,useddt,nom,P,Q,theta,w,cell,method);ncall+=n2
            if ans is not None:break
          if ans is None:
            ans,useddt=analytic_fallback(p,z,w,dt,P,Q,theta,method,target,cell)
            fallback_holds+=1;mode='analytic_fallback'
        shortened_holds+=int(useddt<dt-1e-15)
        control_ms.append((time.perf_counter()-select_start)*1000)
      H,we,info=ans;calls+=ncall;durations.append(useddt)
      before_entry=Tdet is None
      if before_entry:
        extension_margin=min(extension_margin,float(cr.lo(cr.lo(H.end[0]-we[0])-(p.eps+.002))))
        entry_holds+=1;active+=int(abs(H.u-nom(t,*z))>1e-8)
      qt=(gx+1)*useddt/2;qw=gw*useddt/2;qz=H.sol.sol(qt);qd,qv=qz
      qa=p.alpha*(V(p,qd)-qv)+H.u;qh=qd-p.gamma*qv-p.eps
      running=.2*H.u**2+50*qd**2 if task=='gap' else .2*H.u**2+qv**2+5*(qh-.2)**2
      J+=float(np.dot(qw,running));ks=base.clip(nom(t,*z),-p.U,p.U)
      I+=useddt*(H.u-ks)**2;I1sample+=useddt*abs(H.u-ks)
      kn=np.array([base.clip(nom(t+tt,float(dd),float(vv)),-p.U,p.U) for tt,dd,vv in zip(qt,qd,qv)])
      I1actual+=float(np.dot(qw,np.abs(H.u-kn)));I2actual+=float(np.dot(qw,(H.u-kn)**2))
      A2+=float(np.dot(qw,qa*qa))
      qvp=.8*((qd>.1)&(qd<1.975)) if p.name=='C3' else 1-np.tanh(qd)**2
      ap=-p.alpha*qvp*qv-p.alpha*qa;TVA+=float(np.dot(qw,np.abs(ap)))
      astart=p.a(*z)+H.u;aend=p.a(*H.end)+H.u
      if prev_acc is not None:
        jump=abs(astart-prev_acc);TVA+=jump;maxjump=max(maxjump,jump);TVU+=abs(H.u-prev_u)
      prev_acc=aend;prev_u=H.u
      ts=np.linspace(0,useddt,101);ys=H.sol.sol(ts);hs=ys[0]-p.gamma*ys[1]-p.eps
      fs=[]
      if Tdet is None:
        for d,v in ys.T:
          ss=min(P.S,max(0.,d0-d));fs.append(.5*v*v-theta*P.E(ss))
        minfloor=min(minfloor,min(fs))
        if entries is None and ys[0,-1]<=target:
          from scipy.optimize import brentq
          ti=brentq(lambda tau:H.sol.sol(tau)[0]-target,0,useddt)
          entries=t+ti
        if float(cr.hi(H.end[0]+we[0]))<=target:
          Tdet=t+useddt;status='entered'
      hmin=min(hmin,float(hs.min()));vmin=min(vmin,float(ys[1].min()));maxerr=max(maxerr,float(max(we)))
      trace.append({'t':t,'d':float(z[0]),'v':float(z[1]),'u':H.u,'mode':mode,'dt':useddt,
       'cert_h':info['h_margin'],'cert_v':info['v_margin'],'cert_floor':info['floor_margin'],
       'err_d':float(we[0]),'err_v':float(we[1]),'calls':ncall,'decision_ms':control_ms[-1] if before_entry else None})
      for j,key in enumerate(['h_margin','v_margin','M_margin','floor_margin']):mins[j]=min(mins[j],info[key])
      z=H.end;w=we;t+=useddt;steps+=1
      if tail and Tdet is not None and t>=10-1e-10:break
    row={'plant':p.name,'task':task,'h0':h0,'v0':v0,'d0':d0,'nominal':kind,'theta':theta,'dt':dt,'method':method,
     'status':status,'T':entries,'T_detected':Tdet,'Tstar':Tstar,'Tstar_lower':clock_lower(Q,float(cr.lo(targetS))),'ratio':entries/Tstar if entries else None,
     'h_min_diagnostic':hmin,'v_min_diagnostic':vmin,'floor_min_diagnostic':minfloor,
     'cert_min_h':mins[0],'cert_min_v':mins[1],'cert_min_M':mins[2],'cert_min_floor':mins[3],
     'max_state_error':maxerr,'J10':J if t>=10-1e-8 else None,'I2_sampled10':I if t>=10-1e-8 else None,'I1_sampled10':I1sample if t>=10-1e-8 else None,'I10_L1':I1actual if t>=10-1e-8 else None,'I10_L2':I2actual if t>=10-1e-8 else None,'RMS_acc10':math.sqrt(A2/10) if t>=10-1e-8 else None,'TV_acc10':TVA if t>=10-1e-8 else None,'TV_u10':TVU if t>=10-1e-8 else None,'max_acc_jump':maxjump,'intervention_fraction':active/max(entry_holds,1),'control_mean_ms':float(np.mean(control_ms)),'control_p50_ms':float(np.median(control_ms)),'control_p95_ms':float(np.percentile(control_ms,95)),'control_max_ms':max(control_ms),'cost_horizon_actual':math.fsum(durations),'max_abs_actuator':max(abs(x['u']) for x in trace),'profile_extension_margin':extension_margin,'requested_dt':dt,'min_actual_dt':min(x['dt'] for x in trace if x['mode']!='tail'),'max_actual_dt':max(x['dt'] for x in trace if x['mode']!='tail'),'shortened_holds':shortened_holds,'analytic_fallback_holds':fallback_holds,'tail_correction_max':tail_correction_max,'tail_correction_holds':tail_correction_holds,'holds':steps,'cert_calls':calls,'wall_seconds':time.perf_counter()-start,'cell':cell}
    if Tdet is not None:
      detected_durations=[];ss=0.
      for dd in durations:
        detected_durations.append(dd);ss+=dd
        if ss>=Tdet-1e-12:break
      det_up=np.nextafter(np.nextafter(math.fsum(detected_durations),np.inf),np.inf)
      rhs=np.nextafter(np.nextafter(row['Tstar_lower']/np.nextafter(math.sqrt(theta),np.inf),-np.inf)+dt,-np.inf)
      row.update(detected_time_upper=float(det_up),rate_bound_lower=float(rhs),verified_detection_bound=bool(det_up<=rhs))
    return row,trace,allrecords

if __name__=='__main__':
  ap=argparse.ArgumentParser();ap.add_argument('--plant',default='C3');ap.add_argument('--nominal',default='hjb');ap.add_argument('--task',default='gap');ap.add_argument('--v0',type=float,default=.4);ap.add_argument('--dt',type=float,default=.05);ap.add_argument('--theta',type=float,default=.25);ap.add_argument('--cell',type=float,default=.001);ap.add_argument('--tail',action='store_true');ap.add_argument('--method',default='band');a=ap.parse_args()
  p=next(p for p in base.PLANTS if p.name==a.plant)
  r,tr,err=simulate(p,a.task,.8,a.v0,a.nominal,a.theta,a.dt,cell=a.cell,tail=a.tail,method=a.method)
  print(json.dumps(r,indent=2),flush=True)
  fn=ROOT/f'probe_{a.plant}_{a.task}_{a.nominal}_v{a.v0}_dt{a.dt}.json'
  fn.write_text(json.dumps({'row':r,'trace':tr,'failures':err},indent=2));print(fn)
